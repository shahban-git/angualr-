// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
   production: false,

  //apiUrl: 'http://192.168.37.106:8081/',
  //http://192.168.1.6:8081/
  //apiUrl: 'http://192.168.83.107:8082/rbac-service/',
  // apiUrl: 'http://localhost:8082/',
   // apiUrl: 'http://192.168.88.239:8082/',

   Base_url :'https://isgmv.co.in:9024/',
   //Base_url :'http://192.168.83.208:8018/',
   //Base_url :'http://localhost:8018/',
   key : 'asdfghjkl1234567890!@#$%^&*()zxc',
   Bank_id : 'x7fIMAZRAatRqaEZwoWkwA==',
   apiUrl : "",
  refreshTime : 720000,
  idleTimeout : 1200000
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI