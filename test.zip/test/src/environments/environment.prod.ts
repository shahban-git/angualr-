export const environment = {
  production: true,
  //apiUrl: 'http://localhost:8081//',
  apiUrl : "",
  refreshTime : 720000,
  idleTimeout : 1200000
};
