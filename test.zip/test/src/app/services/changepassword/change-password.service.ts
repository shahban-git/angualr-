import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import * as sha512 from 'js-sha512';
import { ChangePassword } from 'src/app/models/changepassword/changepassword';
import { environment } from 'src/environments/environment';
import { HttpDataServiceService } from '../common/http-data-service.service';

@Injectable({
  providedIn: 'root'
})
export class ChangePasswordService {

  
  constructor(private http: HttpDataServiceService,
    private httpClient: HttpClient) { }
  readonly APIUrl = environment.apiUrl;

  changePassword(changePassword: ChangePassword, userName: string) {

    let d1 = "old=" + changePassword.currentPassword + "&new=" + changePassword.newPassword + "&userName=" + userName

    changePassword.currentPassword = sha512.sha512(changePassword.currentPassword.toString().concat(userName.toUpperCase()));
    changePassword.newPassword = sha512.sha512(changePassword.newPassword.toString().concat(userName.toUpperCase()));

    let data = "oldPassword=" + changePassword.currentPassword + "&newPassword=" + changePassword.newPassword + "&userName=" + userName

    return this.httpClient.post("http://192.168.83.107:8082/rbac-service/" + 'users/changepass?' + data, {})
    

  }

 

}
