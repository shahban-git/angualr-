import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { BankView } from 'src/app/models/bank/bank-view';
import { environment } from 'src/environments/environment';
import { HttpDataServiceService } from '../common/http-data-service.service';
import { BranchCreate } from 'src/app/models/branch/branch-create';

@Injectable({
  providedIn: 'root'
})
export class LinkService {

  branchList: any;
  private _listners = new Subject<any>();
  constructor(
    private http: HttpDataServiceService,
    private httpClient: HttpClient
  ) { }

  readonly APIUrl = environment.apiUrl;

  fetchProductList() {
    return this.http.get(this.APIUrl + 'product/dropdown', '');
  }

  fetchSubProductList(id) {
    return this.http.get(this.APIUrl + 'product/sub/dropdown?product='+id, '');
  }

  saveLink(data) {
    return this.httpClient.post(this.APIUrl + 'link/add', data);
  }

  getLinkList(filterParams): Observable<any[]> {
    return this.httpClient.get<any[]>(this.APIUrl + 'link', {params : filterParams});
  }

  viewSubListLink(bankName: string, filterParams): Observable<any[]> {
    return this.httpClient.get<any[]>(
      this.APIUrl + 'link/sub/dropdown?link=' + bankName
      // {params : filterParams}
    );
  }

}
