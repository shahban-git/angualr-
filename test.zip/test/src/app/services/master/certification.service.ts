import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BankView } from 'src/app/models/bank/bank-view';
import { CertificationView } from 'src/app/models/certification/certification-view';
import { ConfigurationCreate } from 'src/app/models/config-user/config-create';
import { environment } from 'src/environments/environment';
import { HttpDataServiceService } from '../common/http-data-service.service';

@Injectable({
  providedIn: 'root',
})
export class CertificationService {

  constructor(
    private http: HttpDataServiceService,
    private httpClient: HttpClient
  ) {}

  readonly APIUrl = environment.apiUrl;

  getBankList(bankName: String, pageFilter): Observable<CertificationView[]> {
    return this.httpClient.get<CertificationView[]>(this.APIUrl + 'certification/sub-list?bank=' + bankName, {params : pageFilter});
  }
}
