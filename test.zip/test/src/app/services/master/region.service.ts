import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { environment } from 'src/environments/environment';
import { HttpDataServiceService } from '../common/http-data-service.service';
import { RegionCreate } from 'src/app/models/region/region-create';
import { RegionView } from 'src/app/models/region/region-view';

@Injectable({
  providedIn: 'root'
})
export class RegionService {

  regionList: any;
  private _listners = new Subject<any>();
  readonly APIUrl = environment.apiUrl;

  constructor(private http: HttpDataServiceService,private httpClient: HttpClient){ }

  createRegion(region: RegionCreate) {
    return this.httpClient.post(this.APIUrl + 'region', region);
  }

  updteRegion(region: RegionCreate) {
    return this.http.post(this.APIUrl + 'region/update', region);
  }

  getRegionList(filterParams): Observable<RegionView[]> {
    return this.httpClient.get<RegionView[]>(this.APIUrl + 'region', { params: filterParams });
  }

  fetchBankList() {
    return this.http.get(this.APIUrl + 'bank/dropdown', '');
  }

  fetchZoneList(bankId) {
    return this.http.get(this.APIUrl + 'zone/dropdown?bank='+bankId, '');
  }

  fetchCountryList() {
    return this.http.get(this.APIUrl + 'country/dropdown', '');
  }
 
  listen(): Observable<any> {
    return this._listners.asObservable();
  }

  filter(filterBy: string) {
    this._listners.next(filterBy);
  }

  viewSubListRegion(bankName: string, filterParams): Observable<any> {
    return this.httpClient.get<any>(
      this.APIUrl + 'region/sub-list?bank=' + bankName,
      {params : filterParams}
    );
  }

  getRegionId(id) {
    return this.http.get(this.APIUrl + 'region/'+id, '');
  }
}
