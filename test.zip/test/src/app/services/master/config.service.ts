import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BankView } from 'src/app/models/bank/bank-view';
import { ConfigurationCreate } from 'src/app/models/config-user/config-create';
import { environment } from 'src/environments/environment';
import { HttpDataServiceService } from '../common/http-data-service.service';

@Injectable({
  providedIn: 'root',
})
export class ConfigService {

  constructor(
    private http: HttpDataServiceService,
    private httpClient: HttpClient
  ) {}

  readonly APIUrl = environment.apiUrl;

  getConfigList(pageFilter): Observable<BankView[]> {
    return this.httpClient.get<BankView[]>(this.APIUrl + 'config/list', {params : pageFilter});
  }

  saveConfig(config: ConfigurationCreate) {
    return this.http.post(this.APIUrl + 'config/create', config);
  }

  updateConfig(config: ConfigurationCreate) {
    return this.http.post(this.APIUrl + 'config/update', config);
  }

  fetchBankList() {
    return this.http.get(this.APIUrl + 'bank/dropdown', '');
  }

}
