import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { environment } from 'src/environments/environment';
import { HttpDataServiceService } from '../common/http-data-service.service';
import { ZoneView } from 'src/app/models/zone/zone-view';
import { ZoneCreate } from 'src/app/models/zone/zone-create';

@Injectable({
  providedIn: 'root'
})
export class ZoneService {

  zoneList: any;
  private _listners = new Subject<any>();
  constructor(
    private http: HttpDataServiceService,
    private httpClient: HttpClient
  ) { }

  readonly APIUrl = environment.apiUrl;

  createZone(zone: ZoneCreate) {
    return this.httpClient.post(this.APIUrl + 'zone', zone);
  }

  updateZone(zone: ZoneCreate) {
    return this.http.post(this.APIUrl + 'zone/update', zone);
  }

  getZoneList(filterParams): Observable<ZoneView[]> {
    return this.httpClient.get<ZoneView[]>(this.APIUrl + 'zone', { params: filterParams });
  }

  fetchBankList() {
    return this.http.get(this.APIUrl + 'bank/dropdown', '');
  }

  fetchCountryList() {
    return this.http.get(this.APIUrl + 'country/dropdown', '');
  }

  getZoneId(id) {
    return this.http.get(this.APIUrl + 'zone/'+id, '');
  }
 
  listen(): Observable<any> {
    return this._listners.asObservable();
  }

  filter(filterBy: string) {
    this._listners.next(filterBy);
  }

  viewSubListZone(bankName: string, filterParams): Observable<any> {
    return this.httpClient.get<any>(
      this.APIUrl + 'zone/sub-list?bank=' + bankName,
      {params : filterParams}
    );
  }

}
