import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { BankView } from 'src/app/models/bank/bank-view';
import { environment } from 'src/environments/environment';
import { HttpDataServiceService } from '../common/http-data-service.service';

@Injectable({
  providedIn: 'root',
})
export class DesignationService {
  readonly APIUrl = environment.apiUrl;

  deptList: any;
  private _listners = new Subject<any>();
  constructor(
    private http: HttpDataServiceService, private httpClient: HttpClient
  ) {}

  getDesigList(filterParams): Observable<BankView[]> {
    return this.httpClient.get<BankView[]>(this.APIUrl + 'designation', {params : filterParams});
  }
  viewSubListDesig(bankName: string, filterParams): Observable<BankView[]> {
    return this.httpClient.get<BankView[]>(
      this.APIUrl + 'designation/sub-list?bank=' + bankName,
      {params : filterParams}
    );
  }

  listen(): Observable<any> {
    return this._listners.asObservable();
  }

  filter(filterBy: string) {
    this._listners.next(filterBy);
  }
}
