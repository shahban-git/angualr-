import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { BankView } from 'src/app/models/bank/bank-view';
import { environment } from 'src/environments/environment';
import { HttpDataServiceService } from '../common/http-data-service.service';
import { BranchCreate } from 'src/app/models/branch/branch-create';

@Injectable({
  providedIn: 'root',
})
export class BranchService {
  branchList: any;
  private _listners = new Subject<any>();
  constructor(
    private http: HttpDataServiceService,
    private httpClient: HttpClient
  ) { }

  readonly APIUrl = environment.apiUrl;

  createBranch(branch: BranchCreate) {
    return this.httpClient.post(this.APIUrl + 'branch', branch);
  }

  updateBranch(branch: BranchCreate) {
    return this.http.post(this.APIUrl + 'branch/update', branch);
  }

  viewBranch(bankName: string, branchName: string) {

    let param = "bank="+bankName+"&branch="+branchName;
    return this.http.get(this.APIUrl + 'branch/fetch?'+param, '');

  }

  getBranchList(filterParams): Observable<BankView[]> {
    return this.httpClient.get<BankView[]>(this.APIUrl + 'branch', { params: filterParams });
  }
  viewSubListBranch(bankName: string, filterParams): Observable<BankView[]> {
    return this.httpClient.get<BankView[]>(
      this.APIUrl + 'branch/sub-list?bank=' + bankName,
      { params: filterParams }
    );
  }

  fetchBankList() {
    return this.http.get(this.APIUrl + 'bank/dropdown', '');
  }

  fetchZoneList(bankId) {
    return this.http.get(this.APIUrl + 'zone/dropdown?bank='+bankId, '');
  }

  fetchRegionList(bankId,zoneId) {
    return this.http.get(this.APIUrl + 'region/bank-zone?bankId='+bankId+'&'+'zoneId='+zoneId, '');
  }

  getBranchId(branchId) {
    return this.http.get(this.APIUrl + 'branch/'+branchId, '');
  }

  fetchCountryList() {
    return this.http.get(this.APIUrl + 'country/dropdown', '');
  }
  fetchStateList(cntName: String) {
    return this.http.get(
      this.APIUrl + 'state/dropdown?country=' + cntName,
      ''
    );
  }

  fetchCityList(cntName: String, stateName: String) {
    return this.http.get(
      this.APIUrl + 'city/dropdown?country=' + cntName + '&state=' + stateName,
      ''
    );
  }

  listen(): Observable<any> {
    return this._listners.asObservable();
  }

  filter(filterBy: string) {
    this._listners.next(filterBy);
  }
}
