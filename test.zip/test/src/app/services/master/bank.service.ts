import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { BankCreate } from 'src/app/models/bank/bank-create';
import { BankUpdate } from 'src/app/models/bank/bank-update';
import { BankView } from 'src/app/models/bank/bank-view';
import { ProductView } from 'src/app/models/product/product';
import { environment } from 'src/environments/environment';
import { HttpDataServiceService } from '../common/http-data-service.service';

@Injectable({
  providedIn: 'root',
})
export class BankService {
  bankList: any;

  constructor(
    private http: HttpDataServiceService,
    private httpClient: HttpClient
  ) {}

  //readonly APIUrl =  "http://localhost:8081/bank";
  readonly APIUrl = environment.apiUrl;

  getBankList(filterParams): Observable<BankView[]> {
    return this.httpClient.get<BankView[]>(this.APIUrl + 'bank', {params : filterParams});
  }
  viewSubListBank(bankName: string, pageParams): Observable<BankView[]> {
    return this.httpClient.get<BankView[]>(
      this.APIUrl + 'bank/sub-list?bank=' + bankName,
      {params : pageParams}
    );
  }

  fetchBankById(bankName: string)
  {
    let  pageParams = {
      name : bankName
    }
    return this.httpClient.get<BankUpdate>(
      this.APIUrl + 'bank/fetch', {params : pageParams}
    );
  }

  fetchCountryList() {
    return this.http.get(this.APIUrl + 'country/dropdown', '');
  }
  fetchProductList() {
    return this.http.get(this.APIUrl + 'product/dropdown', '');
  }

  fetchSubProductList(product) {
    return this.http.get(this.APIUrl + 'product/sub/dropdown?product=' + product, '');
  }
  fetchStateList(cntName: String) {
    return this.http.get(
      this.APIUrl + 'state/dropdown?country=' + cntName,
      ''
    );
  }

  fetchCityList(cntName: String, stateName: String) {
    return this.http.get(
      this.APIUrl + 'city/dropdown?country=' + cntName + '&state=' + stateName,
      ''
    );
  }
  getProductList(productName): Observable<any> {
    return this.http.get<any>(this.APIUrl + 'product?name=' + productName, '');
  }

  saveBank(bank: BankCreate) {
    return this.httpClient.post(this.APIUrl + 'bank/add', bank);
  }

  updateBank(bank : BankUpdate) {
    return this.http.post(this.APIUrl + 'bank/update', bank);
  }
  private _listners = new Subject<any>();

  listen(): Observable<any> {
    return this._listners.asObservable();
  }

  filter(filterBy: string) {
    this._listners.next(filterBy);
  }
}
