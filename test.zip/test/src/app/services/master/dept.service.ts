import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { filter } from 'rxjs/operators';
import { BankView } from 'src/app/models/bank/bank-view';
import { DeptDesigDTO } from 'src/app/models/department/DeptDesigDTO';
import { FilterModel } from 'src/app/models/filter';
import { environment } from 'src/environments/environment';
import { HttpDataServiceService } from '../common/http-data-service.service';

@Injectable({
  providedIn: 'root',
})
export class DepartmentService {
  deptList: any;
  private _listners = new Subject<any>();
  constructor(
    private http: HttpDataServiceService,
    private httpClient: HttpClient
  ) {}

  readonly APIUrl = environment.apiUrl;

  getDeptList(filterParams): Observable<BankView[]> {
    return this.httpClient.get<BankView[]>(this.APIUrl + 'department', {params : filterParams});
  }
  viewSubListDept(bankName: string, filterParams): Observable<BankView[]> {
    return this.httpClient.get<BankView[]>(
      this.APIUrl + 'department/sub-list?bank=' + bankName,
      {params : filterParams}
    );
  }
  createDeptDesig(model: DeptDesigDTO) {
    return this.httpClient.post(this.APIUrl + 'department/dept-desig', model);
  }
  // getProductList(productName): Observable<any> {
  //   return this.http.get<any>(this.APIUrl + 'product?name=' + productName, '');
  // }

  // saveBank(bank: BankCreate) {
  //   return this.http.post(this.APIUrl + 'bank/add', bank);
  // }

  fetchBankList() {
    return this.http.get(this.APIUrl + 'bank/dropdown', '');
  }
  listen(): Observable<any> {
    return this._listners.asObservable();
  }

  filter(filterBy: string) {
    this._listners.next(filterBy);
  }
}
