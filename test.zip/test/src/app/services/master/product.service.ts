import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { filter } from 'rxjs/operators';
import { BankView } from 'src/app/models/bank/bank-view';
import { DeptDesigDTO } from 'src/app/models/department/DeptDesigDTO';
import { FilterModel } from 'src/app/models/filter';
import { ProductView } from 'src/app/models/product/product';
import { environment } from 'src/environments/environment';
import { HttpDataServiceService } from '../common/http-data-service.service';

@Injectable({
  providedIn: 'root',
})
export class ProductService {

    productList: any;
    private _listners = new Subject<any>();
    constructor(
      private http: HttpDataServiceService,
      private httpClient: HttpClient
    ) {}
  
    readonly APIUrl = environment.apiUrl;

    getProductList(filterParams): Observable<BankView[]> {
        return this.httpClient.get<BankView[]>(this.APIUrl + 'product', {params : filterParams});
      }

    // getProductList(): Observable<BankView[]> {
    //   return this.httpClient.get<BankView[]>("http://192.168.83.107:8082/rbac-service/" + 'product/dropdown');
    // }

      viewSubListProduct(bankName: string, filterParams): Observable<ProductView[]> {
        return this.httpClient.get<ProductView[]>(
          this.APIUrl + 'product/sub/dropdown?product=' + bankName
          // {params : filterParams}
        );
      }

      saveProduct(data) {
        return this.httpClient.post(this.APIUrl + 'product', data);
      }

      updateProduct(data) {
        return this.http.post(this.APIUrl + 'product/update', data);
      }
    
}
    