import { Injectable } from '@angular/core';
import { UserView } from '../models/user/userView';
import { HttpDataServiceService } from './common/http-data-service.service';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { UserCreate } from '../models/user/user-create';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  constructor(private http: HttpDataServiceService, private httpClient : HttpClient) {}
  readonly APIUrl = environment.apiUrl;
  viewListUsers(pageParms): Observable<UserView[]> {
    return this.httpClient.get<UserView[]>(this.APIUrl + 'users/list', {params : pageParms});
  }

  getUserById(userId: number) {
    return this.http.get(this.APIUrl + 'users/get-user?id=' + userId, '');
  }

  viewSubListUsers(bankId: number,  pageParms): Observable<UserView[]> {
    return this.httpClient.get<UserView[]>(
      this.APIUrl + 'users/sub-list?bank=' + bankId ,
      {params : pageParms}
    );
  }

  createUser(user: UserCreate) {

    console.log(user)
    return this.httpClient.post(this.APIUrl + 'user/create', user);
  }

  updateUser(user: UserCreate) {
    return this.http.post(this.APIUrl + 'user/update', user);
  }

  fetchBankList() {
    return this.http.get(this.APIUrl + 'bank/dropdown', '');
  }

  fetchRoleList(bankId: number) {
    return this.http.get(this.APIUrl + 'role/get-role?id='+bankId, '');
  }

  fetchZoneList(bankId) {
    return this.http.get(this.APIUrl + 'zone/dropdown?bank='+bankId, '');
  }

  fetchRegionList(bankId,zoneId) {
    return this.http.get(this.APIUrl + 'region/bank-zone?bankId='+bankId+'&'+'zoneId='+zoneId, '');
  }

  fetchBranchList(bankId: number) {
    return this.http.get(this.APIUrl + 'branch/dropdown?bank=' + bankId, '');
  }

  fetchDeptList(bankId: number) {
    return this.http.get(
      this.APIUrl + 'department/dropdown?bank=' + bankId,
      ''
    );
  }

  fetchDesigList(bankId: number) {
    return this.http.get(
      this.APIUrl + 'designation/dropdown?bank=' + bankId,
      ''
    );
  }
}
