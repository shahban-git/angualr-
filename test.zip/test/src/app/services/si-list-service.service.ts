import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';

import { Router } from '@angular/router';
import { SiListingRequest } from '../layouts/modules/model/si-listing-request';
import { environment } from 'src/environments/environment';
import { SiListingCancelledDateRequest } from '../layouts/modules/model/si-listing-cancelled-date-request';



@Injectable({
  providedIn: 'root'
})
export class SiListServiceService {
  Base_url
  Bank_id
  constructor(private http:HttpClient,private router:Router) {
      this.Base_url = environment.Base_url;
      this.Bank_id = environment.Bank_id;
  }

  GenerateOtp(req)
  {
    let headers = new HttpHeaders({
      'Content-Type' : 'application/json',
    })

   let url = `${this.Base_url}si_user_service/user_service/si/generateOtp`
    return this.http.post<any>(url,req,{
      headers:headers,
      observe:'response'
    })
  }

  ValidateOtp(req)
  {
    let headers = new HttpHeaders({
      'Content-Type' : 'application/json'
    })
    let url = `${this.Base_url}si_user_service/user_service/si/validateOtp`
    return this.http.post<any>(url,req,{
      headers : headers,
      observe:'response'
    })
  }

  siListing(req: SiListingRequest) {       
    
    //let headers = new HttpHeaders({
    //  'Content-Type' : 'application/json',
    //  "Authorization":'Bearer'+' '+localStorage.getItem('authorizationToken'),
    //  "bankId": this.Bank_id
    //});
    console.log("In seeeeeerrrviiiii")
    let url = this.Base_url+'si_portal/report/siReport';    
    
    console.log("si url :::"+url);
    
    console.log("Token 3 :::"+    sessionStorage.getItem('Token'));
    

    let headers = new HttpHeaders({
      'Content-Type' : 'application/json',
      "Authorization":'Bearer'+' '+sessionStorage.getItem('Token'),
      //"bankId": this.Bank_id
    });
    
    return this.http.post<any>(url,req,{
      headers : headers,
      observe:'response'
    });
  }


  siCancelledRangeListing(req: SiListingRequest) {       
    
    //let headers = new HttpHeaders({
    //  'Content-Type' : 'application/json',
    //  "Authorization":'Bearer'+' '+localStorage.getItem('authorizationToken'),
    //  "bankId": this.Bank_id
    //});
    console.log("In seeeeeerrrviiiii")
    let url = this.Base_url+'si_portal/report/siCancellBetweenDateRange';    
    
    console.log("si url :::"+url);
    
    console.log("Token 3 :::"+    sessionStorage.getItem('Token'));
    

    let headers = new HttpHeaders({
      'Content-Type' : 'application/json',
      "Authorization":'Bearer'+' '+sessionStorage.getItem('Token'),
      //"bankId": this.Bank_id
    });
    
    return this.http.post<any>(url,req,{
      headers : headers,
      observe:'response'
    });
  }

  siCancelledSpecificDateListing(req: SiListingCancelledDateRequest) {       
    
    //let headers = new HttpHeaders({
    //  'Content-Type' : 'application/json',
    //  "Authorization":'Bearer'+' '+localStorage.getItem('authorizationToken'),
    //  "bankId": this.Bank_id
    //});
    console.log("In seeeeeerrrviiiii")
    let url = this.Base_url+'si_portal/report/siCancelSpecificDate';    
    
    console.log("si url :::"+url);
    
    console.log("Token 3 :::"+    sessionStorage.getItem('Token'));
    

    let headers = new HttpHeaders({
      'Content-Type' : 'application/json',
      "Authorization":'Bearer'+' '+sessionStorage.getItem('Token'),
      //"bankId": this.Bank_id
    });
    
    return this.http.post<any>(url,req,{
      headers : headers,
      observe:'response'
    });
  }



  siModifiedRangeListing(req: SiListingRequest) {       
    
    //let headers = new HttpHeaders({
    //  'Content-Type' : 'application/json',
    //  "Authorization":'Bearer'+' '+localStorage.getItem('authorizationToken'),
    //  "bankId": this.Bank_id
    //});
    console.log("In seeeeeerrrviiiii")
    let url = this.Base_url+'si_portal/report/siModificationReport';    
    
    console.log("si url :::"+url);
    
    console.log("Token 3 :::"+    sessionStorage.getItem('Token'));
    

    let headers = new HttpHeaders({
      'Content-Type' : 'application/json',
      "Authorization":'Bearer'+' '+sessionStorage.getItem('Token'),
      //"bankId": this.Bank_id
    });
    
    return this.http.post<any>(url,req,{
      headers : headers,
      observe:'response'
    });
  }


  siCancelledAllTxnRangeListing(req: SiListingRequest) {       
    
    //let headers = new HttpHeaders({
    //  'Content-Type' : 'application/json',
    //  "Authorization":'Bearer'+' '+localStorage.getItem('authorizationToken'),
    //  "bankId": this.Bank_id
    //});
    console.log("In seeeeeerrrviiiii")
    let url = this.Base_url+'si_portal/report/siCancelAll';    
    
    console.log("si url :::"+url);
    
    console.log("Token 3 :::"+    sessionStorage.getItem('Token'));
    

    let headers = new HttpHeaders({
      'Content-Type' : 'application/json',
      "Authorization":'Bearer'+' '+sessionStorage.getItem('Token'),
      //"bankId": this.Bank_id
    });
    
    return this.http.post<any>(url,req,{
      headers : headers,
      observe:'response'
    });
  }

  siCancelledNextTxnRangeListing(req: SiListingRequest) {       
    
    //let headers = new HttpHeaders({
    //  'Content-Type' : 'application/json',
    //  "Authorization":'Bearer'+' '+localStorage.getItem('authorizationToken'),
    //  "bankId": this.Bank_id
    //});
    console.log("In seeeeeerrrviiiii")
    let url = this.Base_url+'si_portal/report/siCancelAll';    
    
    console.log("si url :::"+url);
    
    console.log("Token 3 :::"+    sessionStorage.getItem('Token'));
    

    let headers = new HttpHeaders({
      'Content-Type' : 'application/json',
      "Authorization":'Bearer'+' '+sessionStorage.getItem('Token'),
      //"bankId": this.Bank_id
    });
    
    return this.http.post<any>(url,req,{
      headers : headers,
      observe:'response'
    });
  }


  logoutUser(){
    let headers = new HttpHeaders({
      'Content-Type' : 'application/json',
      "Authorization":'Bearer'+' '+localStorage.getItem('authorizationToken')
    });
    let url = this.Base_url+'si_user_service/user_service/si/logout'; 
    return this.http.post<any>(url,{},{
      headers : headers,
      observe : 'response' 
    })
  }

  cancelPayment(req){
    let headers = new HttpHeaders({
      'Content-Type' : 'application/json',
      'bankId': this.Bank_id,
      "Authorization":'Bearer'+' '+localStorage.getItem('authorizationToken'),
    });
    let url = `${this.Base_url}si_user_service/user_service/si/cancelSI`;
    return this.http.post<any>(url,req,{
      headers : headers,
      observe:'response'
    })
  }
  fetchTransaction(req)
  {
    let headers = new HttpHeaders({
      'Content-Type' : 'application/json',
      "Authorization":'Bearer'+' '+localStorage.getItem('authorizationToken'),
      "bankId": this.Bank_id
    });
    let url = this.Base_url+'si_user_service/user_service/si/siTransactionListing';
    return this.http.post<any>(url,req,{
      headers :headers,
      observe : 'response'
    });
  }
}
