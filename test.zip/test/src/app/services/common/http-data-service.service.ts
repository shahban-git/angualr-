import { HttpCoreService } from './http-core.service';
import { Injectable } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Observable, Subject } from 'rxjs';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';

// import swal from 'sweetalert';

@Injectable({
  providedIn: 'root'
})

export class HttpDataServiceService {
  constructor( private httpCore: HttpCoreService,private http: HttpClient) { }
  /*----------- post method --------------*/
   

  post<T>(url: string, body: any, formObj?: FormGroup): Observable<T>{
   
    let resData: Subject<T> = new Subject<T>();
    let headers = new HttpHeaders();
    headers.set('Content-Type', 'application/json; charset=utf-8');  
    headers.set('Authorization', 'Srushti');
    this.httpCore.post(url, body,{headers: headers}).subscribe((res : any) => {
      if (res.data != null) {
        //swal("Good job!", "You clicked the button!", "success",{timer: 2000});
        resData.next((res as any) as T);
      } else {
        resData.next((res as any) as T);
      }
      
      if (res.validationError != null) {
          if (res.validationError.actionError != null) {
            resData.next((res as any) as T);
          }
          else{
          }
      }
    },
    err => {      
      if(err != null){
        resData.next((err as any) as T);
      }

    });

    return resData.asObservable();
  }

  get<T>(url: string, body: any, formObj?: FormGroup): Observable<T> {
    let resData: Subject<T> = new Subject<T>();
    let headers = new HttpHeaders();
    headers = headers.set('Content-Type', 'application/json; charset=utf-8');  
    
    this.httpCore.get(url).subscribe((res:any) => {
      
      // if (res.msg != null) {
        // console.log("data get response",res.msg);
      // }

      // if (res.validationError != null) {
        
        // if (res.validationError.actionError != null) {
          
        // } else {
         
        // }
      // }

      // if (res.data != null) {
        
        resData.next((res as any) as T);
      // }      
    },
    err => {      
      if(err != null){
        resData.next((err as any) as T);
      }

    });
    return resData.asObservable();
  }

  put<T>(url: string, body: any, formObj?: FormGroup): Observable<T> {
    let resData: Subject<T> = new Subject<T>();
    let headers = new HttpHeaders();
    headers = headers.set('Content-Type', 'application/json; charset=utf-8');  
    headers = headers.set('Authorization', 'Srushti');
    this.httpCore.put(url, body,{headers: headers}).subscribe((res:any) => {
      if (res.msg != null) {
       
      }

      if (res.validationError != null) {
        if (res.validationError.actionError != null) {
         
        } else {
          
        }
      }

      if (res.data != null) {
        resData.next((res.data as any) as T);
      }      
    },
    err => {      
      if(err != null){
        resData.next((err as any) as T);
      }

    });
    return resData.asObservable();
  }
}
