import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable()
export class ConfigService {
  private appConfig;
  jsonProperty

  constructor(private httpClient: HttpClient) { }
  loadConfig(){
           return this.httpClient.get<any>("assets/domainProperty.json").
           toPromise().then(res=>{
             console.log("configggggggresssppp",res)
              this.jsonProperty = res.filter(domainName => {        
          environment.apiUrl= domainName.apiUrl1;})
    console.log("envvvvvvvvvvvvvvvvvvvvvvvv",environment.apiUrl)

             this.appConfig=res;
           })
  }
  getConfig(){
    return this.appConfig;
  }
}
