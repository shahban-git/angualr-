import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpErrorResponse } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';
import { LoginService } from './login.service';

@Injectable({
  providedIn: 'root'
})
export class BasicAuthInterceptorService {

  constructor(private authService: LoginService) { }

  /**
   * Intecepts the request to add authorization header if the user is logged in by cloning the request.
   * And logs out the user if its an unauthorized request
   *
   * @param req
   *        - http request
   * @param next
   *          - next request
   */
  intercept(req: HttpRequest<any>, next: HttpHandler) {
    if (this.authService.isUserLoggedIn()) {
      req = req.clone({
        setHeaders: {
          Authorization: sessionStorage.getItem("Token")
        }
      });
    }
    return next.handle(req).pipe(
      catchError(error => {
        // capturing 401
        if (error.status === 401 || error.status === 403) {
          this.authService.logout();
        }
        return throwError(error);
      }));
  }
}
