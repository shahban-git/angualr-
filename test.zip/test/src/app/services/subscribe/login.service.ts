import { Injectable } from '@angular/core';
import { HttpDataServiceService } from '../common/http-data-service.service';
import { Login } from '../../models/user/login';
import { Subject, Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { catchError, map } from 'rxjs/operators';
import { throwError } from 'rxjs';
import * as sha512 from 'js-sha512';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class LoginService {
  linkValues: number[];
  crudPerms: number;
  jsonProperty

  private intervalId: any;
  //readonly APIUrl =  "http://localhost:8765/user";
   APIUrl = environment.apiUrl;

  constructor(private http: HttpDataServiceService,private httpClient: HttpClient) {
  }

  api(){
    this.httpClient.get<any>("assets/domainProperty.json").subscribe(jsonData =>{

      this.jsonProperty = jsonData.filter(domainName => {        
          environment.apiUrl= domainName.apiUrl1;
          
          //environment.apiUrl.replace(domainName.apiUrl1,environment.apiUrl);
    })
    console.log("$$$$$$$$$$$$",environment.apiUrl)
    localStorage.setItem("jsonDomainProperty", JSON.stringify(this.jsonProperty));
  })
    console.log("logggggiinnnserviceeeeeeeee",environment.apiUrl)
  }

  onLogin(login: Login): Observable<any> {
    login.password=sha512.sha512(login.password.toString().concat(login.userName.toUpperCase()));

    return this.httpClient.post<any>(environment.apiUrl + 'auth/slt', login);
  }

  afterLoginView(token) {
    return this.http.post<any>(environment.apiUrl + 'user/login', token);
  }

  private _listners = new Subject<any>();

  listen(): Observable<any> {
    return this._listners.asObservable();
  }

  filter(filterBy: string) {
    this._listners.next(filterBy);
  }
  public get loggedIn(): boolean {
    return localStorage.getItem('currentUser') !== null;
  }

  /**
   * Checks if the user is logged in the system by getting the token
   */
  public isUserLoggedIn() {
    let token = sessionStorage.getItem('Token');
    const isLoggedIn = !(token === null);
    if (isLoggedIn && this.intervalId === undefined) {
      this.startTimer();
    }
    return isLoggedIn;
  }

  public startTimer() {
    console.log("starttttimer")
    this.intervalId = setInterval(() => {
      let rt: number = +sessionStorage.getItem('rt');
      let now = new Date().getTime();
      console.log("rtttttttttt",rt,now)
      if (rt <= now) {
        this.refreshToken().subscribe();
      }
    }, 60000);
  }

  public refreshToken() {
    console.log("refreshhhhhhhhh")
    let request: any = {};
    return this.http.post<any>(environment.apiUrl + 'auth/refreshToken', request).pipe(
      map((data) => {
        console.log("uuuuuuuuuuu",data)
        return this.storeDataInSession(data['Refresh Token']);
      }),
      catchError((err) => {
        this.logout();
        return throwError(err);
      })
    );
  }

  /**
   * Stroes the data in session.
   * @param data - data which needs to be set
   */
  public storeDataInSession(data) {
    let tokenStr = data.token;
    sessionStorage.setItem('Token', tokenStr);
    let now: number = new Date().getTime();
    now = now + environment.refreshTime;
    sessionStorage.setItem('rt', now + '');
    return data;
  }

  /**
   * Logs the user out of the system by removing the token and reloading the location.
   */
  public logout() {    
    let httpOptions = {
      headers: new HttpHeaders({
        'Authorization': 'Bearer ' + sessionStorage.getItem('Token')
      })
    };

    return this.http.post<any>(environment.apiUrl + 'user/logout', httpOptions);
  }  
  stopTimer() {
    clearInterval(this.intervalId);
  }

  getCurrentUser()
  {
    let request: any = {
    };
    console.log("valiiiiiiiiiiiiiiiiiiiiii",environment.apiUrl,this.APIUrl)
    return this.http.post<any>(environment.apiUrl+ 'users/validate', request);
  }
  forgot_password(data): Observable<any>{
    let url = environment.apiUrl +'users/forgot-password?userName=${data.userName}'
    let dataa = "userName=" + data.userName;
    return this.httpClient.post<any>(environment.apiUrl + 'users/forgot-password?' + dataa,{})
  }
}
