import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { filter } from 'rxjs/operators';
import { RoleNew } from 'src/app/models/roles/role-new';
import { RoleView } from 'src/app/models/roles/role-view';
import { environment } from 'src/environments/environment';
import { HttpDataServiceService } from '../common/http-data-service.service';

@Injectable({
  providedIn: 'root',
})
export class RoleServiceService {
  constructor(private http: HttpDataServiceService, private httpClient: HttpClient) {}
  readonly APIUrl = environment.apiUrl;
  viewListRole(filterParams): Observable<RoleView[]> {
    return this.httpClient.get<RoleView[]>(this.APIUrl + 'role/list', {params : filterParams});
  }
  createRole(role: RoleNew) {
    return this.httpClient.post(this.APIUrl + 'role/create', role);
  }
  getRoleById(bankId: number) {
    return this.http.get(this.APIUrl + 'role/get-role?id=' + bankId, '');
  }

  fetchBankList() {
    return this.http.get(this.APIUrl + 'bank/dropdown', '');
  }

  fetchLinkList() {
    return this.http.get(this.APIUrl + 'link/dropdown', '');
  }

  viewSubListRoles(bankName,filterParams): Observable<RoleView[]> {
    return this.httpClient.get<RoleView[]>(
      this.APIUrl + 'role/sub-list?bank=' + bankName,
      {params : filterParams}
    );
  }
}
