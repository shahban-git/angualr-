import { TestBed } from '@angular/core/testing';

import { SiTxnListServiceService } from './si-txn-list-service.service';

describe('SiTxnListServiceService', () => {
  let service: SiTxnListServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SiTxnListServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
