import { TestBed } from '@angular/core/testing';

import { SiListServiceService } from './si-list-service.service';

describe('SiListServiceService', () => {
  let service: SiListServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SiListServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
