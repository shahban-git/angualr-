import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { filter } from 'rxjs/operators';
import { CertificationViewComponent } from 'src/app/layouts/modules/certification-home/certification-view/certification-view.component';
import { BankView } from 'src/app/models/bank/bank-view';
import { CertificationView } from 'src/app/models/certification/certification-view';
import { Certify } from 'src/app/models/certification/certify';
import { DeptDesigDTO } from 'src/app/models/department/DeptDesigDTO';
import { FilterModel } from 'src/app/models/filter';
import { ProductView } from 'src/app/models/product/product';
import { environment } from 'src/environments/environment';
import { HttpDataServiceService } from '../common/http-data-service.service';

@Injectable({
  providedIn: 'root',
})
export class CertificationService {
    certList: any;
    private _listners = new Subject<any>();
    constructor(
      private http: HttpDataServiceService,
      private httpClient: HttpClient
    ) {}
  
    readonly APIUrl = environment.apiUrl;

    getCertList(filterParams): Observable<BankView[]> {
        return this.httpClient.get<BankView[]>(this.APIUrl + 'certification', {params : filterParams});
      }

    
      viewSubListCert(bankName: string, filterParams): Observable<CertificationView[]> {
        return this.httpClient.get<CertificationView[]>(
          this.APIUrl + 'certification/sub-list?bank=' + bankName,
          {params : filterParams}
        );
      }

      doCertify( certify : Certify[])
      {
        this.http.post(this.APIUrl + 'certification/do/certify', certify);
      }
}