import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';

import { Router } from '@angular/router';
// import { SiListingRequest } from '../layouts/modules/model/si-listing-request';
import { SiListingRequest } from '../layouts/modules/model/si-daily-mis-listing-request';
import { environment } from 'src/environments/environment';



@Injectable({
  providedIn: 'root'
})
export class SiTxnListServiceService {
  Base_url
  Bank_id
  constructor(private http:HttpClient, private router:Router) {
      this.Base_url = environment.Base_url;
      this.Bank_id = environment.Bank_id;
  }

  siTxnListing(req: SiListingRequest) {       
    console.log("In SiTxnListServiceService")
    // let url = this.Base_url+'si_portal/report/siTransactionReport';   
    let url = "https://isgmv.co.in:9024/si_portal/report/siDailyReports";   
    console.log("Token 3 :::"+ sessionStorage.getItem('Token'));
    let headers = new HttpHeaders({
      'Content-Type' : 'application/json',
      "Authorization":'Bearer'+' '+sessionStorage.getItem('Token'),
    });
    return this.http.post<any>(url,req,{
      headers : headers,
      observe:'response'
    });
  }

  

  siDeclinedTxnListing(req: SiListingRequest) {       
  console.log("In seeeeeerrrviiiii")
  let url = this.Base_url+'si_portal/report/declinedTransactionReport';    
  console.log("Token 3 :::"+    sessionStorage.getItem('Token'));
  let headers = new HttpHeaders({
    'Content-Type' : 'application/json',
    "Authorization":'Bearer'+' '+sessionStorage.getItem('Token'),
  });
  return this.http.post<any>(url,req,{
    headers : headers,
    observe:'response'
  });
}

  
  fetchTransaction(req)
  {
    let headers = new HttpHeaders({
      'Content-Type' : 'application/json',
      "Authorization":'Bearer'+' '+localStorage.getItem('authorizationToken'),
      "bankId": this.Bank_id
    });
    let url = this.Base_url+'si_user_service/user_service/si/siTransactionListing';
    return this.http.post<any>(url,req,{
      headers :headers,
      observe : 'response'
    });
  }

  
}
