import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IssbinComponent } from './issbin.component';

describe('IssbinComponent', () => {
  let component: IssbinComponent;
  let fixture: ComponentFixture<IssbinComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IssbinComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IssbinComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
