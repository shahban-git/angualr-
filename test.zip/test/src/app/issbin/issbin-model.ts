import { Injectable } from '@angular/core';
@Injectable({
    providedIn: 'root'
  })

export class IssBinModel{

    enId:string;
    issBinHigh:string;
    issBinId:string;
    issCrdTyp:string;
    issCrdVrt:string;
    issDmnUge:string;
    issPanLgh:string;
    issPrdTyp:string[];
    issPrdTyp1:string;
    issSchNme:string;
    issSetlBin:string;
    issSetlCurr:string;
    issSetlTyp:string;
    issbinLow:string;
    orgId:string;
    pid:string;
    procBin:string;
    productId:string;
    userId:string;
    ica: string;





}


