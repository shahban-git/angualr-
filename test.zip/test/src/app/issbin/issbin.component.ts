import { Component, OnInit, ViewChild } from '@angular/core';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import {IcmgenComponent} from '../icmgen/icmgen.component'
import { Router, ActivatedRoute } from '@angular/router';
import { NgForm,FormGroup,FormControl,Validators } from '@angular/forms';
import { IssBinModel } from './issbin-model';
import {MatTableDataSource} from '@angular/material/table';

import { map } from 'rxjs/operators';
import Swal from 'sweetalert2'; 
@Component({
  selector: 'app-issbin',
  templateUrl: './issbin.component.html',
  styleUrls: ['./issbin.component.css']
})
export class IssbinComponent implements OnInit {
  
  constructor(private router: Router,private route: ActivatedRoute,private modalService: NgbModal,public icmgenservice: IcmgenComponent) { }
  issBinList=[];
  isEnable:boolean=false;
  displayedColumns: string[] = ['Bin Id', 'Bin Low','Bin High','Proc Bin','Settlement Currency','Card Variance','Card Type','Action'];
  dataSource:MatTableDataSource<IssBinModel>;
  dynamicForm: FormGroup;
  productTypes: string[] =['POS','ECOM','ATM'];
  settlementTypes = ['SMS','DMS'];
  cardTypes = ['CREDIT','DEBIT','PREPAID'];
  cardVariances = ['CLASSIC','GOLD','PLATINUM','BUSINESS','INFINITE','SIGNATURE', 'CORPORATE','CONSUMER'];
  productTypes1: string[] =['PREMIUM','CONSUMER','BUSINESS','SUPER PREMIUM'];
  enId='';
  issBinHigh='';
  issBinId='';
  issCrdTyp='';
  issCrdVrt='';
  issDmnUge='';
  issPanLgh='';
  issPrdTyp='';
  issPrdTyp1='';
  issSchNme='';
  issSetlBin='';
  issSetlCurr='';
  issSetlTyp='';
  issbinLow='';
  orgId='';
  pid='';
  procBin='';
  productId='';
  userId='';
  ica= '';

  mode='';
  index=0;
  signupForm: FormGroup;

  ngOnInit(): void {
    if(this.icmgenservice.prddetail.schemeType=='MasterCard')
    {
      this.displayedColumns =['Bin Id', 'Bin Low','Bin High','ICA','Settlement Currency','Card Variance','Card Type','Action'];
    }
    if(this.icmgenservice.prddetail.schemeType=='RuPay')
    {
      this.displayedColumns =['Bin Id', 'Bin Low','Bin High','PID','Settlement Currency','Card Variance','Card Type','Action'];
    }
    this.issBinList=this.icmgenservice.getBinList();
    this.dataSource= new MatTableDataSource(this.issBinList);
    console.log('issBinList:::::::::::'+this.issBinList);
    if(this.icmgenservice.mode=='view')
    {
      this.isEnable=true;
    }
    this.productId = this.icmgenservice.prddetail.productId;
    

  }

  open(content) {

    if(this.icmgenservice.prddetail.bussinessType==='ACQUIRER')
    {
      Swal.fire('Error', 'This option is not applicatable for the selected business type', 'error');
      return false;
    }
    this.modalService.open(content, {
      centered: true,
      backdrop: 'static'
      
     });
     
    /*this.enId='';
    this.issBinHigh='';
    this.issBinId='';
    this.issCrdTyp='';
    this.issCrdVrt='';
    this.issDmnUge='';
    this.issPanLgh='';
    this.issPrdTyp='';
    this.issSchNme='';
    this.issSetlBin='';
    this.issSetlCurr='';
    this.issSetlTyp='';
    this.issbinLow='';
    this.orgId='';
    this.pid='';
    this.procBin='';
    //this.productId='';
    this.userId='';
    this.ica='';*/
    let numericRegex = /^[a-zA-Z0-9]+$/;
    this.dynamicForm = new FormGroup({
     
      productId : new FormControl(this.productId),
      issBinId : new FormControl(null,[Validators.required,Validators.pattern(numericRegex),Validators.minLength(6),Validators.maxLength(20)]),
      issBinHigh : new FormControl(null,[Validators.required,Validators.pattern(numericRegex),Validators.minLength(6),Validators.maxLength(20)]),
      issbinLow : new FormControl(null,[Validators.required,Validators.pattern(numericRegex),Validators.minLength(6),Validators.maxLength(20)]),
      issCrdTyp : new FormControl(null,[Validators.required]),
      issCrdVrt : new FormControl(null,[Validators.required]),
      issDmnUge : new FormControl(null,[Validators.required]),
      issPanLgh : new FormControl(null,[Validators.required]),
      issPrdTyp :  new FormControl(null,[Validators.required]),
      
      issSetlBin : new FormControl(null,[Validators.pattern(numericRegex),Validators.minLength(8),Validators.maxLength(8)]),
      issSetlCurr : new FormControl(null,[Validators.required,Validators.pattern(numericRegex),Validators.minLength(3),Validators.maxLength(3)]),
      issSetlTyp : new FormControl(null),
      pid : new FormControl(null,[this.icmgenservice.prddetail.schemeType=='RuPay'?Validators.required:Validators.pattern(numericRegex)]),
      procBin : new FormControl(null,[this.icmgenservice.prddetail.schemeType=='VISA'?Validators.required:Validators.pattern(numericRegex)]),
      ica : new FormControl(null,[this.icmgenservice.prddetail.schemeType=='MasterCard'?Validators.required:Validators.pattern(numericRegex)]),
      productid : new FormControl(null) ,
      issPrdTyp1 :  new FormControl(null,[Validators.required])

    }

    )



    this.mode='add';
   
  }

  /*selectProduct(item,dynamicForm){
    dynamicForm.patchValue({
      'issPrdTyp': item
     
    });

  }*/

  openModalNew(targetModal, issBin,i) {
    this.modalService.open(targetModal, {
     centered: true,
     backdrop: 'static'
    });
    this.enId=issBin.enId;
    let numericRegex = /^[a-zA-Z0-9]+$/;
    this.dynamicForm = new FormGroup({
     
      productId : new FormControl(this.productId),
      issBinId : new FormControl(null,[Validators.required,Validators.pattern(numericRegex),Validators.minLength(6),Validators.maxLength(20)]),
      issBinHigh : new FormControl(null,[Validators.required,Validators.pattern(numericRegex),Validators.minLength(6),Validators.maxLength(20)]),
      issbinLow : new FormControl(null,[Validators.required,Validators.pattern(numericRegex),Validators.minLength(6),Validators.maxLength(20)]),
      issCrdTyp : new FormControl(null,[Validators.required]),
      issCrdVrt : new FormControl(null,[Validators.required]),
      issDmnUge : new FormControl(null,[Validators.required]),
      issPanLgh : new FormControl(null,[Validators.required]),
      issPrdTyp :  new FormControl(null,[Validators.required]),
      
      issSetlBin : new FormControl(null,[Validators.pattern(numericRegex),Validators.minLength(8),Validators.maxLength(8)]),
      issSetlCurr : new FormControl(null,[Validators.required,Validators.pattern(numericRegex),Validators.minLength(3),Validators.maxLength(3)]),
      issSetlTyp : new FormControl(null),
      pid : new FormControl(null,[this.icmgenservice.prddetail.schemeType=='RuPay'?Validators.required:Validators.pattern(numericRegex)]),
      procBin : new FormControl(null,[this.icmgenservice.prddetail.schemeType=='VISA'?Validators.required:Validators.pattern(numericRegex)]),
      
      ica : new FormControl(null,[this.icmgenservice.prddetail.schemeType=='MasterCard'?Validators.required:Validators.pattern(numericRegex)]),
      
      productid : new FormControl(null) ,
      issPrdTyp1 :  new FormControl(null)

    }

    )
    //alert(typeof issBin.issPrdTyp);
    let prdType = typeof issBin.issPrdTyp=== "string" ? issBin.issPrdTyp.split(',') : issBin.issPrdTyp;
    this.dynamicForm.patchValue({
      'issBinHigh': issBin.issBinHigh,
      'issBinId' : issBin.issBinId,
      'issCrdTyp': issBin.issCrdTyp,
      'issCrdVrt': issBin.issCrdVrt,
      'issDmnUge': issBin.issDmnUge,
      'issPanLgh': issBin.issPanLgh,
      'issPrdTyp': prdType,//issBin.issPrdTyp.split(','),
      'issPrdTyp1': issBin.issPrdTyp1,
      'issSetlBin': issBin.issSetlBin,
      'issSetlCurr' : issBin.issSetlCurr,
      'issSetlTyp' : issBin.issSetlTyp,
      'procBin' : issBin.procBin,
      'pid' : issBin.pid,
      'issbinLow' : issBin.issbinLow,
      'ica' : issBin.ica
      
    });
    this.index=i;
    console.log('index::::::::::::::::::'+i);
    
    
   
      
    this.enId=issBin.enId;
    this.issBinHigh=issBin.issBinHigh;
    this.issBinId=issBin.issBinId;
    this.issCrdTyp=issBin.issCrdTyp;
    this.issCrdVrt=issBin.issCrdVrt;
    this.issDmnUge=issBin.issDmnUge;
    this.issPanLgh=issBin.issPanLgh;
    this.issPrdTyp=issBin.issPrdTyp;
    this.issPrdTyp1=issBin.issPrdTyp1;
    this.issSchNme=issBin.issSchNme;
    this.issSetlBin=issBin.issSetlBin;
    this.issSetlCurr=issBin.issSetlCurr;
    this.issSetlTyp=issBin.issSetlTyp;
    this.issbinLow=issBin.issbinLow;
    this.orgId='';
    this.pid=issBin.pid;
    this.procBin=issBin.procBin;
    //this.productId=issBin.productId;
    this.userId='';
    
      
      this.ica=issBin.ica;
      this.mode='edit';
      this.index=i;

      
    
   }

  /*onSubmit() {
    
    console.log(this.signupForm.value.messageType);
  }
*/
  onSubmit(signupForm: FormGroup){
    this.signupForm=signupForm;
    console.log("adding form values "+signupForm.value.binId);
    if(this.mode=='add'){
      /*this.issBinList.push({
        binId:signupForm.value.binId,
        binLow:signupForm.value.binLow,
        binHigh:signupForm.value.binHigh,
        schemeName:signupForm.value.binId,
        setlBin:signupForm.value.setlBin,
        procBin:signupForm.value.binId,
        ica:signupForm.value.ica
      });*/
      this.icmgenservice.addBin(signupForm).subscribe(
        response=>{
          console.log('response after adding '+response);
          this.issBinList.push({
            issBinHigh:signupForm.value.issBinHigh,
            issBinId:signupForm.value.issBinId,
            issCrdTyp:signupForm.value.issCrdTyp,
            issCrdVrt:signupForm.value.issCrdVrt,
            issDmnUge:signupForm.value.issDmnUge,
            issPanLgh:signupForm.value.issPanLgh,
            issPrdTyp:signupForm.value.issPrdTyp,
            issPrdTyp1:signupForm.value.issPrdTyp1,
            issSchNme:signupForm.value.issSchNme,
            issSetlBin:signupForm.value.issSetlBin,
            issSetlCurr:signupForm.value.issSetlCurr,
            issSetlTyp:signupForm.value.issSetlTyp,
            issbinLow:signupForm.value.issbinLow,
            ica:signupForm.value.ica,
            pid:signupForm.value.pid,
            procBin:signupForm.value.procBin,
            productId:signupForm.value.productId
            
            
           
          });
          this.dataSource= new MatTableDataSource(this.issBinList);
        },error=>{

          alert("Error in adding Bin");
        }


      );
      
      
    }
    else{
      /*this.issBinList.splice(this.index);
      this.issBinList.push({
        binId:signupForm.value.binId,
        binLow:signupForm.value.binLow,
        binHigh:signupForm.value.binHigh,
        schemeName:signupForm.value.binId,
        setlBin:signupForm.value.setlBin,
        procBin:signupForm.value.binId,
        ica:signupForm.value.ica
      });*/
      this.icmgenservice.issBinList.splice(0, this.icmgenservice.issBinList.length);
      this.icmgenservice.updateBin(signupForm,this.index).subscribe(
        response=>{
          console.log('response after adding '+response);
          this.icmgenservice.getAsynBinList().pipe(
            map((responsedata:{[key:number]:IssBinModel})=>{
              for(const key in responsedata)
              {
                this.icmgenservice.issBinList.push(responsedata[key]);
    
    
              }
              console.log('ssss'+this.icmgenservice.issBinList.length);
              this.issBinList = this.icmgenservice.getBinList();
              this.dataSource= new MatTableDataSource(this.icmgenservice.issBinList);
            }
    
            )
    
            
    
        )
        .subscribe(
          result =>{
            console.log(result);
            //this.result1 = result;
          
    
          }
        
        );
        }
      );
      

      
      console.log('In Edit');
      console.log('this.issBinList:::::::::::::::'+this.issBinList);
      

    

    }

    
    this.modalService.dismissAll();
    
}

closeWindow(){

  this.modalService.dismissAll();
  
}
goNext(){

  this.router.navigate(['dashboard/product-setup/gen/acqbin']);
}

getBinDetails()
{
  //alert("Get Details Called...");
  //alert("Get Details Called..."+this.dynamicForm.get('issBinHigh').value);
  try{
  if(this.icmgenservice.prddetail.schemeType=='MasterCard')
  {
  this.icmgenservice.getBinDtls(this.icmgenservice.prddetail.schemeType,this.dynamicForm.get('issbinLow').value,this.dynamicForm.get('issBinHigh').value).
  subscribe(
    response=>{
      
      console.log('Response is :::::::::::::'+response);
      try{
        if(!Object.keys(response).length)
      {
        Swal.fire('Warning', 'Bin Details not Present in the System. ', 'error');
       
        
      }
      else{
        
      this.dynamicForm.patchValue({
        'issCrdTyp': response[0][1],
        'issDmnUge': response[0][3],
        'issSetlCurr': response[0][0],
        'issCrdVrt': response[0][4],
        'ica' : response[0][5],
        'issPrdTyp1' : response[0][6],
        'issPanLgh': '16'
        
        

      });
    }
  }
catch(e)
{

  Swal.fire('Warning', 'Bin Details not Present in the System. ', 'warning');

  }

    },
    error=>{

      console.log('Response is :::::::::::::'+error);
    }

  )


  }else if(this.icmgenservice.prddetail.schemeType=='RuPay'){


    this.icmgenservice.getBinDtls('RUPAY',this.dynamicForm.get('issbinLow').value,this.dynamicForm.get('issBinHigh').value).
  subscribe(
    response=>{
      
      console.log('Response is :::::::::::::'+response);
      try{
        if(!Object.keys(response).length)
      {
        Swal.fire('Warning', 'Bin Details not Present in the System. ', 'error');

      }
      else {
        
      this.dynamicForm.patchValue({
        'issCrdTyp': response[0][2],
        'issDmnUge': response[0][3],
        'issSetlCurr': response[0][1],
        'issCrdVrt': response[0][5],
        'issPanLgh': response[0][0],
        
        'pid': response[0][6],
        'issPrdTyp1' : response[0][7],
        'issSetlTyp' : response[0][8]

        

      });
    }
  }
  catch(e)
  {
      alert('Bin Details not Present in the System. ');
  
    }
    },
    error=>{

      console.log('Response is :::::::::::::'+error);
    }

  )

  

  }else if(this.icmgenservice.prddetail.schemeType=='VISA'){


    this.icmgenservice.getBinDtls('VISA',this.dynamicForm.get('issbinLow').value,this.dynamicForm.get('issBinHigh').value).
  subscribe(
    response=>{
      
      console.log('Response is :::::::::::::'+response);
      try{
        if(!Object.keys(response).length)
      {
        Swal.fire('Warning', 'Bin Details not Present in the System. ', 'error');

      }
      else {
       
      this.dynamicForm.patchValue({
        'issCrdTyp': response[0][1],
        'issDmnUge': response[0][3],
        'issSetlCurr': response[0][0],
        'issCrdVrt': response[0][4],
        'issPanLgh': '16',
        
        'procBin' : response[0][5],
        'issPrdTyp1' : response[0][6]
        
        

      });
    }
  }
  catch(e)
  {
      alert('Bin Details not Present in the System. ');
  
    }
    },
    error=>{

      console.log('Response is :::::::::::::'+error);
    }

  )

  }
  
  }catch(e)
  {
    alert("Bin Details not present");
  }

}
  remove(i,issid)
  {
    //this.issBinList.splice(i);
    this.icmgenservice.issBinList.splice(0, this.icmgenservice.issBinList.length);
      this.icmgenservice.deleteIssBinAsyn(issid).subscribe(
        response=>{
          console.log('response after adding '+response);
          this.icmgenservice.getAsynBinList().pipe(
            map((responsedata:{[key:number]:IssBinModel})=>{
              for(const key in responsedata)
              {
                this.icmgenservice.issBinList.push(responsedata[key]);
    
    
              }
              console.log('ssss'+this.icmgenservice.issBinList.length);
              this.issBinList = this.icmgenservice.getBinList();
              this.dataSource= new MatTableDataSource(this.icmgenservice.issBinList);
            }
    
            )
    
            
    
        )
        .subscribe(
          result =>{
            console.log(result);
            //this.result1 = result;
          
    
          }
        
        );
        }
      );
    
  }

  
}
