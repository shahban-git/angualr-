import { BrowserModule } from '@angular/platform-browser';
import { NgModule ,CUSTOM_ELEMENTS_SCHEMA, APP_INITIALIZER, forwardRef} from '@angular/core';
import {DefaultModule} from 'src/app/layouts/default/default.module';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BasicAuthInterceptorService } from './services/subscribe/basic-auth-interceptor.service';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import {ErrorInterceptor} from '../app/layouts/_helpers/error.interceptor';
import { ConfigService } from './services/configfile/config.service';
import { SiReportComponent } from './layouts/modules/report/si-report/si-report.component';
import { FormsModule, NG_VALUE_ACCESSOR, ReactiveFormsModule } from '@angular/forms';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MaterialFileInputModule } from 'ngx-material-file-input';
import { MatNativeDateModule } from '@angular/material/core';
import { MatTableExporterModule } from 'mat-table-exporter';
import { DatePipe } from '@angular/common';
//import { SiCancelledAllTxnRangeReportComponent } from './layouts/modules/report/si-cancelled-all-txn-range-report/si-cancelled-all-txn-range-report.component';
//import { SiCancelledNextTxnRangeReportComponent } from './layouts/modules/report/si-cancelled-next-txn-range-report/si-cancelled-next-txn-range-report.component';
//import { SiDeclinedTxnRangeReportComponent } from './layouts/modules/report/si-declined-txn-range-report/si-declined-txn-range-report.component';
//import { SiModifiedRangeReportComponent } from './layouts/modules/report/si-modified-range-report/si-modified-range-report.component';
//import { SiCancelledSpecificDateReportComponent } from './layouts/modules/report/si-cancelled-specific-date-report/si-cancelled-specific-date-report.component';
//import { SiCancelledRangeReportComponent } from './layouts/modules/report/si-cancelled-range-report/si-cancelled-range-report.component';
//import { SiTransactionReportComponent } from './layouts/modules/report/si-transaction-report/si-transaction-report.component';

const appConfig=(config:ConfigService)=>{
  return()=>{
    return config.loadConfig()
  }
}

@NgModule({
  declarations: [
    AppComponent,
    //SiCancelledAllTxnRangeReportComponent,
    //SiCancelledNextTxnRangeReportComponent,
    //SiDeclinedTxnRangeReportComponent,
    //SiModifiedRangeReportComponent,
    //SiCancelledSpecificDateReportComponent,
    //SiCancelledRangeReportComponent,
    //SiTransactionReportComponent,
    //SiReportComponent,
    
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    DefaultModule,
    NgbModule,
    HttpClientModule,
    ReactiveFormsModule,
    MatSortModule,
    MatTableModule,
    MatDatepickerModule,
    MaterialFileInputModule, 
    FormsModule,           // <----- this module will be deprecated in the future version.
    
    MatNativeDateModule,        // <----- import for date formating(optional)
    
    MatTableExporterModule,
    // ErrorInterceptor

  ],
  providers: [ConfigService, { provide: HTTP_INTERCEPTORS ,
     useClass:BasicAuthInterceptorService, multi:true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
    {provide:APP_INITIALIZER,useFactory:appConfig,multi:true,deps:[ConfigService]},
    { 
      provide: NG_VALUE_ACCESSOR,
      multi: true,
      useExisting: forwardRef(() => SiReportComponent),
    },[DatePipe]
  ],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }
