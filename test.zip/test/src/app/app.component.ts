import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from './services/subscribe/login.service';
import { environment } from 'src/environments/environment';
import { OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'RBAC';
  jsonProperty;
  loader: boolean = false;
  idleTimerInterval: any;
  idleTimer: number = 0;

  constructor(private service: LoginService,
     public router: Router,private httpClient: HttpClient) {
  //  this.service.api()

  //       this.httpClient.get<any>("assets/domainProperty.json").subscribe(jsonData =>{

  //     this.jsonProperty = jsonData.filter(domainName => {        
  //         environment.apiUrl= domainName.apiUrl1;
          
  //         //environment.apiUrl.replace(domainName.apiUrl1,environment.apiUrl);
  //   })
  //   console.log("$$$$$$$$$$$$",environment.apiUrl)
  //   localStorage.setItem("jsonDomainProperty", JSON.stringify(this.jsonProperty));
  // })
    this.checkIdle();
    }
  ngOnInit(): void {
    // this.getCurrentUser()
   
}


  checkIdle() {
    document.addEventListener("mousemove", () => {
      if (this.idleTimer > environment.idleTimeout) {
        if(window.location.pathname.search("auth") === -1){
          this.service.logout();
        }
        this.idleTimer = 0;
      } else {
        this.idleTimer = 0;
      }
    });
    this.idleTimerInterval = setInterval(() => this.idleTimer += 1000, 1000);
  }
  ngOnDestroy() {
    clearInterval(this.idleTimerInterval);
  }
}
