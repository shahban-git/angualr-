import { TestBed } from '@angular/core/testing';

import { IcmgenServiceService } from './icmgen-service.service';

describe('IcmgenServiceService', () => {
  let service: IcmgenServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(IcmgenServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
