import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IcmgenComponent } from './icmgen.component';

describe('IcmgenComponent', () => {
  let component: IcmgenComponent;
  let fixture: ComponentFixture<IcmgenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IcmgenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IcmgenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
