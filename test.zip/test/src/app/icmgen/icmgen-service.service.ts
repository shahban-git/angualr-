import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { AcqBinModel } from '../acqbin/acqbin-model';
import { map } from 'rxjs/operators';
import { IssBinModel } from '../issbin/issbin-model';
import { ProductModel } from '../prd/prd-model';
import {Observable} from 'rxjs';
import {environment} from '../icm/environment/environment.prod'

@Injectable({
  providedIn: 'root'
})
export class IcmgenServiceService {

  readonly APIUrl = environment.apiUrl;
  constructor(private http:HttpClient,private acqnodel : AcqBinModel,private issmodel:IssBinModel) { }
  result1:AcqBinModel[] =[];
  prdModel:ProductModel;
  issBinLst:IssBinModel[] = [];
  loaddate="loading";
  getAcqBinList(productId){
    this.result1.splice(0, this.result1.length);
    

      this.http.get<{[key:number]:AcqBinModel}>(this.APIUrl+'global-onboarding/getAcqBinListByProductId/'+productId)
      .pipe(
          map((responsedata:{[key:number]:AcqBinModel})=>{
            for(const key in responsedata)
            {
              this.result1.push(responsedata[key]);
            }
          }

          )

      )
      .subscribe(
        result =>{
          console.log(result);
          //this.result1 = result;
        }
      
      );

      

      

  }

  getAcqBinListAsyn(productId){
    this.result1.splice(0, this.result1.length);
    

      return this.http.get<{[key:number]:AcqBinModel}>(this.APIUrl+'global-onboarding/getAcqBinListByProductId/'+productId);
      

      

      

  }

  getProductById(productId) : Observable<ProductModel>
    {
        console.log('URl::::::::::'+this.APIUrl+'global-onboarding/getProduct/'+productId);
        this.loaddate="loading";
        return this.http.get<{[key:number]:ProductModel}>(this.APIUrl+'global-onboarding/getProduct/'+productId)
        .pipe(
          map((responsedata:{[key:number]:ProductModel})=>{
            for(const key in responsedata)
            {
              this.prdModel = responsedata[key];
              console.log('this.result::::: '+this.prdModel);
              return this.prdModel; 
             
            }
            
          }

          )

      );

     


    }

  addAcqBin(signupForm){

      this.acqnodel.enId ='' ;
      this.acqnodel.acqBinId = signupForm.value.acqBinId;
      this.acqnodel.acqSetlBin =signupForm.value.acqSetlBin;
      this.acqnodel.acqSetlCurr =signupForm.value.acqSetlCurr;
      this.acqnodel.pid = signupForm.value.pid;
      this.acqnodel.procBin =signupForm.value.procBin;
      this.acqnodel.ica=signupForm.value.ica;
      this.acqnodel.productId=signupForm.value.productId;
      this.acqnodel.userId='';
      this.acqnodel.acqProdTyp=signupForm.value.acqProdTyp.toString();

      console.log(this.acqnodel);

      this.http.post(this.APIUrl+'global-onboarding/acqbin/addAcqbin',this.acqnodel).subscribe(
        response=>{
          console.log('response after adding '+response);
        }
      )

  }

  deleteAcqBin(acqid)
  {
    this.http.delete(this.APIUrl+'global-onboarding/acqbin/deleteAcqbin/'+acqid).subscribe(
      response=>{
        console.log('response after adding '+response);
      }
    )
  }

  deleteAcqBinAsyn(acqid)
  {
    return this.http.delete(this.APIUrl+'global-onboarding/acqbin/deleteAcqbin/'+acqid);
  }

  updateAcqBin(signupForm)
  {
      this.acqnodel.enId ='' ;
      this.acqnodel.acqBinId = signupForm.value.acqBinId;
      this.acqnodel.acqSetlBin =signupForm.value.acqSetlBin;
      this.acqnodel.acqSetlCurr =signupForm.value.acqSetlCurr;
      this.acqnodel.pid = signupForm.value.pid;
      this.acqnodel.procBin =signupForm.value.procBin;
      this.acqnodel.ica=signupForm.value.ica;
      this.acqnodel.productId='';
      this.acqnodel.userId='';
      this.acqnodel.acqProdTyp='';

      console.log(this.acqnodel);

      this.http.put(this.APIUrl+'global-onboarding/acqbin/updateAcqbin/'+this.acqnodel.acqBinId,this.acqnodel).subscribe(
        response=>{
          console.log('response after adding '+response);
        }
      )

  }

  updateAcqBinAsyn(signupForm)
  {
      this.acqnodel.enId ='' ;
      this.acqnodel.acqBinId = signupForm.value.acqBinId;
      this.acqnodel.acqSetlBin =signupForm.value.acqSetlBin;
      this.acqnodel.acqSetlCurr =signupForm.value.acqSetlCurr;
      this.acqnodel.pid = signupForm.value.pid;
      this.acqnodel.procBin =signupForm.value.procBin;
      this.acqnodel.ica=signupForm.value.ica;
      this.acqnodel.productId='';
      this.acqnodel.userId='';
      this.acqnodel.acqProdTyp=signupForm.value.acqProdTyp.toString();

      console.log(this.acqnodel);

      return this.http.put(this.APIUrl+'global-onboarding/acqbin/updateAcqbin/'+this.acqnodel.acqBinId,this.acqnodel);/*.subscribe(
        response=>{
          console.log('response after adding '+response);
        }
      )*/

  }

  getIssBinList(productId){
    this.issBinLst.splice(0, this.issBinLst.length);
    

    this.http.get<{[key:number]:IssBinModel}>(this.APIUrl+'global-onboarding/getIssBinListByProductId/'+productId)
    .pipe(
        map((responsedata:{[key:number]:IssBinModel})=>{
          for(const key in responsedata)
          {
            this.issBinLst.push(responsedata[key]);
          }
        }

        )

    )
    .subscribe(
      result =>{
        console.log(result);
        //this.result1 = result;
      }
    
    );

    

}

getIssBinListAsyn(productId){

    return this.http.get<{[key:number]:IssBinModel}>(this.APIUrl+'global-onboarding/getIssBinListByProductId/'+productId);

}

getBinDtls(network,binlow,binhigh){
  if (network=='MasterCard')
  {

    network= 'MASTER';

  }
  console.log(this.APIUrl+'global-onboarding/getBinListByBinRange/'+binlow+'/'+binhigh+'/'+network);
  return this.http.get<{String}>(this.APIUrl+'global-onboarding/getBinListByBinRange/'+binlow+'/'+binhigh+'/'+network);
}

getAcqBinDtls(network,bin){
  if (network=='MasterCard')
  {

    network= 'MASTER';

  }
  return this.http.get<{String}>(this.APIUrl+'global-onboarding/getAcqBindetailsbyBinLow/'+bin+'/'+network);
}

addIssBin(signupForm){

  this.issmodel.issBinHigh=signupForm.value.issBinHigh;
  this.issmodel.issBinId=signupForm.value.issBinId;
  this.issmodel.issCrdTyp=signupForm.value.issCrdTyp;
  this.issmodel.issCrdVrt=signupForm.value.issCrdVrt;
  this.issmodel.issDmnUge=signupForm.value.issDmnUge;
  this.issmodel.issPanLgh=signupForm.value.issPanLgh;
  this.issmodel.issPrdTyp=signupForm.value.issPrdTyp.toString();
  this.issmodel.issPrdTyp1=signupForm.value.issPrdTyp1;
  this.issmodel.issSchNme=signupForm.value.issSchNme;
  this.issmodel.issSetlBin=signupForm.value.issSetlBin;
  this.issmodel.issSetlCurr=signupForm.value.issSetlCurr;
  this.issmodel.issSetlTyp=signupForm.value.issSetlTyp;
  this.issmodel.issbinLow=signupForm.value.issbinLow;

  this.issmodel.pid=signupForm.value.pid;
  this.issmodel.procBin=signupForm.value.procBin;
  this.issmodel.productId=signupForm.value.productId;
  this.issmodel.ica=signupForm.value.ica;
  console.log(this.issmodel);

  return this.http.post(this.APIUrl+'global-onboarding/issbin/addIssbin',this.issmodel);

}

deleteIssBin(issid)
{
this.http.delete(this.APIUrl+'global-onboarding/issbin/deleteIssbin/'+issid).subscribe(
  response=>{
    console.log('response after adding '+response);
  }
)
}

deleteIssBinAsyn(issid)
{
  return this.http.delete(this.APIUrl+'global-onboarding/issbin/deleteIssbin/'+issid);/*.subscribe(
  response=>{
    console.log('response after adding '+response);
  }
)*/
}

updateIssBin(signupForm)
{
  this.issmodel.issBinHigh=signupForm.value.issBinHigh;
  this.issmodel.issBinId=signupForm.value.issBinId;
  this.issmodel.issCrdTyp=signupForm.value.issCrdTyp;
  this.issmodel.issCrdVrt=signupForm.value.issCrdVrt;
  this.issmodel.issDmnUge=signupForm.value.issDmnUge;
  this.issmodel.issPanLgh=signupForm.value.issPanLgh;
  this.issmodel.issPrdTyp=signupForm.value.issPrdTyp;
  this.issmodel.issSchNme=signupForm.value.issSchNme;
  this.issmodel.issSetlBin=signupForm.value.issSetlBin;
  this.issmodel.issSetlCurr=signupForm.value.issSetlCurr;
  this.issmodel.issSetlTyp=signupForm.value.issSetlTyp;
  this.issmodel.issbinLow=signupForm.value.issbinLow;

  this.issmodel.pid=signupForm.value.pid;
  this.issmodel.procBin=signupForm.value.procBin;
  this.issmodel.productId=signupForm.value.productId;
  this.issmodel.ica=signupForm.value.ica;
  console.log(this.issmodel);

  this.http.put(this.APIUrl+'global-onboarding/issbin/updateIssbin/'+this.issmodel.issBinId,this.issmodel).subscribe(
    response=>{
      console.log('response after adding '+response);
    }
  )

}

updateIssBinAsyn(signupForm)
{
  this.issmodel.issBinHigh=signupForm.value.issBinHigh;
  this.issmodel.issBinId=signupForm.value.issBinId;
  this.issmodel.issCrdTyp=signupForm.value.issCrdTyp;
  this.issmodel.issCrdVrt=signupForm.value.issCrdVrt;
  this.issmodel.issDmnUge=signupForm.value.issDmnUge;
  this.issmodel.issPanLgh=signupForm.value.issPanLgh;
  this.issmodel.issPrdTyp=signupForm.value.issPrdTyp.toString();
  this.issmodel.issSchNme=signupForm.value.issSchNme;
  this.issmodel.issSetlBin=signupForm.value.issSetlBin;
  this.issmodel.issSetlCurr=signupForm.value.issSetlCurr;
  this.issmodel.issSetlTyp=signupForm.value.issSetlTyp;
  this.issmodel.issbinLow=signupForm.value.issbinLow;

  this.issmodel.pid=signupForm.value.pid;
  this.issmodel.procBin=signupForm.value.procBin;
  this.issmodel.productId=signupForm.value.productId;
  this.issmodel.ica=signupForm.value.ica;
  console.log(this.issmodel);

  return this.http.put(this.APIUrl+'global-onboarding/issbin/updateIssbin/'+this.issmodel.issBinId,this.issmodel);/*.subscribe(
    response=>{
      console.log('response after adding '+response);
    }
  )*/

}

}
