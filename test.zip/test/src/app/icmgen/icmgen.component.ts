import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AppComponent } from '../app.component';
import { ProductService } from '../prd/prd-service';
import {ProductModel} from '../prd/prd-model';
import { IcmgenServiceService } from './icmgen-service.service';
@Component({
  selector: 'app-icmgen',
  templateUrl: './icmgen.component.html',
  styleUrls: ['./icmgen.component.css'],
  providers: []
})
export class IcmgenComponent implements OnInit {

  constructor(private prodService:ProductService,private app: AppComponent,private router: Router,private route: ActivatedRoute,private icmgenservice: IcmgenServiceService) { }
  issBinList=[];
  acqBinList=[];
  mode:string='';
  mem={
    memid:'',
    details:'',
    moddate:new Date(),
    frmstatus:'',
    prddetail:{
      bussinessType: '',
      enId: '',
      orgId: '',
      productId: '',
      schemeType: '',
      status: '',
      userId: ''
    },
    issBinList:[],
    acqBinList:[]

  };
  memList=[];
  entid='';
  productId='';
  prddetail:ProductModel={
    
    bussinessType: '',
    enId: '',
    orgId: '',
    productId: '',
    schemeType: '',
    status: '',
    userId: ''
  }
  loaddate="loading";
  ngOnInit(): void {
    console.log('NG Init Called');
    /*if(this.app.getMemList()[0]!=undefined)
    {
    console.log(this.app.getMemList()[0].prddetail.prdid);
    this.prddetail=this.app.getMemList()[0].prddetail;
    console.log('NG Init Called::'+this.prddetail.prdid);
    if(this.app.getMemList()[0].issBinList!=undefined)
    {
      this.issBinList=this.app.getMemList()[0].issBinList;
    }
    if(this.app.getMemList()[0].acqBinList!=undefined)
    {
      this.acqBinList=this.app.getMemList()[0].acqBinList;
    }
    }*/

    this.productId = this.route.snapshot.queryParams.productId;
    console.log('productId:::::::::::::'+this.productId);
    if(this.productId!=undefined)
    {
      this.icmgenservice.getProductById(this.productId).subscribe(
        result=>{
          this.prddetail=result;
        }
      );
    }
    
      
      

    
    

    console.log('in query mode::::::::'+this.route.snapshot.queryParams.mode);

    if(this.route.snapshot.queryParams.mode!=undefined)
    {

      this.mode=this.route.snapshot.queryParams.mode;
      console.log('Mode:::::::::::::'+this.mode);
    }
    if(this.route.snapshot.queryParams.entid!=undefined)
    {

      this.entid=this.route.snapshot.queryParams.entid;
    }

    if(this.productId!=undefined)
    {
      this.icmgenservice.getAcqBinList(this.productId);
      this.acqBinList=this.icmgenservice.result1;

      console.log('Acq list size is::::::::::::::'+this.acqBinList);
      this.icmgenservice.getIssBinList(this.productId);
      this.issBinList=this.icmgenservice.issBinLst;
      console.log('Iss list size is::::::::::::::'+this.issBinList);
    }
    
    
  }

  getBinList()
  {
    return this.issBinList;
  }

  getAcqBinList()
  {
    return this.acqBinList;
  }

  addBin(signupForm)
  {
    
    return this.icmgenservice.addIssBin(signupForm);
  }

  addAcqBin(signupForm)
  {
    this.acqBinList.push({
      entId:'',
      acqBinId:signupForm.value.acqBinId,
      acqSetlBin:signupForm.value.acqSetlBin,
      acqSetlCurr:signupForm.value.acqSetlCurr,
      pid:signupForm.value.pid,
      procBin:signupForm.value.procBin,
      ica:signupForm.value.ica,
      productId:signupForm.value.productId,
      acqProdTyp:signupForm.value.acqProdTyp,
      userId:''
    });

    this.icmgenservice.addAcqBin(signupForm);

  }

  getProduct()
  {
    //this.prddetail = this.icmgenservice.prdModel;
    console.log('this.prddetail:::::::::'+this.prddetail);

      

    console.log('this.prddetail:::::::::'+this.prddetail);
    console.log('getProduct Called:::::::::::::'+this.prddetail);
    //console.log('getProduct Called'+this.mem.prddetail);
    return this.prddetail;
  }

  setProduct(signupForm)
  {
    this.prddetail.enId=this.entid;
    this.prddetail.productId=this.prddetail.productId;
    this.prddetail.schemeType=signupForm.value.schemeType;
    this.prddetail.bussinessType=signupForm.value.bussinessType;
    console.log('In Gen:::::::'+this.prddetail.productId);
    console.log(this.entid);
    if(this.mode='add')
    {
      
      this.prodService.addProduct(signupForm,this.entid,this.prddetail.productId).subscribe(
        (response:string) => {
          this.prddetail.productId = response;
        }
      )
      

    }else{
      this.prodService.editProduct(signupForm,this.entid);
    }
    //this.prddetail = this.prodService.result1;
  }


  updateBin(signupForm,index)
  {
    console.log('index:::::::::::'+index);
    //this.issBinList.splice(index);
      /*this.issBinList.push({
      issBinHigh:signupForm.value.issBinHigh,
      issBinId:signupForm.value.issBinId,
      issCrdTyp:signupForm.value.issCrdTyp,
      issCrdVrt:signupForm.value.issCrdVrt,
      issDmnUge:signupForm.value.issDmnUge,
      issPanLgh:signupForm.value.issPanLgh,
      issPrdTyp:signupForm.value.issPrdTyp,
      issSchNme:signupForm.value.issSchNme,
      issSetlBin:signupForm.value.issSetlBin,
      issSetlCurr:signupForm.value.issSetlCurr,
      issSetlTyp:signupForm.value.issSetlTyp,
      issbinLow:signupForm.value.issbinLow,
      
      pid:signupForm.value.pid,
      procBin:signupForm.value.procBin,
      productId:signupForm.value.productId
      });*/
      console.log('size is::::::::::::'+this.issBinList.length);
      return this.icmgenservice.updateIssBinAsyn(signupForm);
      
  }


  getAsynBinList()
  {
    return this.icmgenservice.getIssBinListAsyn(this.prddetail.productId);

  }

  getBinDtls(schemeType,issBinLow,issBinHigh)
  {

    return this.icmgenservice.getBinDtls(schemeType,issBinLow,issBinHigh);

  }

  getAcqBinDtls(schemeType,acqBin)
  {

    return this.icmgenservice.getAcqBinDtls(schemeType,acqBin);

  }

  getAsynAcqBinList()
  {
    return this.icmgenservice.getAcqBinListAsyn(this.prddetail.productId);

  }

  updateAcqBin(signupForm,index)
  {
    return this.icmgenservice.updateAcqBinAsyn(signupForm);
    /*this.acqBinList.splice(index);
    this.acqBinList.push({
      acqBinId:signupForm.value.acqBinId,
      acqSetlBin:signupForm.value.acqSetlBin,
      acqSetlCurr:signupForm.value.acqSetlCurr,
      pid:signupForm.value.pid,
      procBin:signupForm.value.procBin,
      ica:signupForm.value.ica,
      productId:'',
      userId:'',
      acqProdTyp:''
    });*/
  }

  saveClick()
  {
    

    /*this.mem.memid=this.prddetail.prdid;
    this.mem.details=this.prddetail.busstyp;
    this.mem.moddate=new Date();
    this.mem.frmstatus='Saved';
    this.mem.prddetail=this.prddetail;
    this.mem.acqBinList=this.acqBinList;
    this.mem.issBinList=this.issBinList;
    console.log('saveClick Called'+this.mem.prddetail);
    this.app.addMemList(this.mem);*/

    if(this.issBinList.length==0 && this.acqBinList.length==0)
    {
      alert("Need to add Issuer Bin or Acquirer Bin before Submitting");
    }else{
    this.prodService.submitProductDetails(this.prddetail).subscribe(
      response=>{
        console.log('response after adding '+response);

        this.router.navigate(['dashboard/product-setup/icm-page'],{queryParams:{entid:this.entid}});
      },
      error=>{
        console.log('response after adding '+error);
        alert("SomeThing Went Wrong!!");
      }
    )
    
    }

  }

  closeClick(){
    this.router.navigate(['dashboard/product-setup/icm-page'],{queryParams:{entid:this.entid}});

  }

  certify(){

    this.prodService.certifyProductDetails(this.prddetail).subscribe(
      response=>{
        console.log('response after adding '+response);
        this.router.navigate(['dashboard/product-setup/icm-page'],{queryParams:{entid:this.entid}});
      },
      error=>{
        console.log('response after adding '+error);
        alert("SomeThing Went Wrong!!");
      }
    );

    


  }

  reject(){

    this.prodService.rejectProductDetails(this.prddetail).subscribe(
      response=>{
        console.log('response after adding '+response);
        this.router.navigate(['dashboard/product-setup/icm-page'],{queryParams:{entid:this.entid}});
      },
      error=>{
        console.log('response after adding '+error);
        alert("SomeThing Went Wrong!!");
      }
    )

    


  }

  deleteAcqBin(acqid)
  {
    return this.icmgenservice.deleteAcqBinAsyn(acqid);
  }

  deleteIssBinAsyn(issid)
  {
    return this.icmgenservice.deleteIssBinAsyn(issid);
  }


}
