// import { EntityUpdate } from '../entity/entity-update': ;
// import { AddressUpdate } from '../address/address-update': ;
// import { AddressCreate } from '../address/address-create': ;

import { Address } from '../address/address';
import { ProductView } from '../product/product';

export class BankCreate {
  memberName: String;

  memberDesc: String;

  orgName: String;

  bankUrl: String;

  products: ProductView[];

  address : Address

  designation: String;


}
