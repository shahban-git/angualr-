import { Address } from "../address/address";
import { ProductView } from "../product/product";

export class BankUpdate {

     memberId   : Number; 

     memberName: String;

  memberDesc: String;

  orgName: String;

  bankUrl: String;

  products: ProductView[];

  address : Address

  designation: String;

}