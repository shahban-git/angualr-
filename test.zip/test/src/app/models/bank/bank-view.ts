export class BankView {

    bankName : String;

    bankCreationDate : String;

    bankStatus : string;

    bankProductName : string ;

    masterCount : number

}
