export class CertificationView {


	 bankName : String ;
	 
	 trailId : number;
	
	 masterProdcutName : String ;
	
	 makerName : String ;
	
	 makerRemark : String ;
	
	 makerDate : String ;
	
	 previousState : String ;
	
	 currentState : String ;
	
     checkerDate : String ;
	
	 checkerRemark : String ;

}