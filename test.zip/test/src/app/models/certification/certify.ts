export class Certify 
{
   trailId  : Number;
    
   accept  : Number;
	
	reject  : Number;
	
   remarks : String;
   
   masterName : String
}