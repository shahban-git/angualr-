import { Bank } from '../user/user-create';
import { RoleCreate } from './role-create';

export class RoleNew{

    roleBank : Bank;
    roles : RoleCreate[]
}