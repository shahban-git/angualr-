export class RoleView {

    roleId: number;

    roleName: String;

    bankName: String;

    roleCount: number;

    roleStatus: number;

    roleCreation: Date;
}