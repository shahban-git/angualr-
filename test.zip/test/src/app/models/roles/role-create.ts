import { Bank } from '../user/user-create';

export class RoleCreate {
    roleName : String;

    roleType: String;

    roleBank : Bank;

    roleDescription: String;

    roleCategory: String;

    roleValidFromDate: Date;

    roleValidToDate: Date;

    rolePrivRead: number;

    rolePrivWrite: number;

    rolePrivEdit: number;

    rolePrivDelete: number;

}