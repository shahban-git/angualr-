export class DesignationView {

  bankName : string;

  desigCreationDate : string;

  desigStatus : string;

  desigName : string ;

}
