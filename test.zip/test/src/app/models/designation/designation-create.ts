import { Bank, EntityBean } from '../user/user-create';

export class DesignationCreate {
 bank : Bank;

entityBean : EntityBean;

desigName : string;
}
