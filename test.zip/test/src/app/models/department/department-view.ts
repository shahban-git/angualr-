export class DepartmentView {

    bankName : string;

    deptCreationDate : string;

    deptStatus : string;

    deptName : string ;

}
