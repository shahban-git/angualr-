import { DesignationCreate } from '../designation/designation-create';
import { Bank } from '../user/user-create';
import { DepartmentCreate } from './department-create';

export class DeptDesigDTO {

  
  deptDesigBank: Bank;

  designationList : DesignationCreate[];

  departmentList : DepartmentCreate[];
}
