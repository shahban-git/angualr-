import {Bank, EntityBean } from '../user/user-create';

export class DepartmentCreate {

    bank : Bank;

deptEntity : EntityBean;

deptName : string;
}
