export class ChangePassword {
    currentPassword: String;
    userName : String;
    newPassword : String;

}
