export class Address {

  primaryPhoneNo: String;

  primaryMobileNo: String;

  secondaryPhoneNo: String;

  secondaryMobileNo: String;

  primaryEmail: String;

  secondaryEmail: String;

  legalAddress: String;

  conLegalAddr : String;

  addrCity: String;

  addrState: String;

  addrCountry: String;

  addrContactPerson: String;

  conEmail :  String;

  designation : String;

  mobileNo: String;

  contactNo: String;

  addrPin: String;

  addrFax: String;

  addressType: String;

}
