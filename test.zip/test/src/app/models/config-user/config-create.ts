import { Bank, EntityBean } from '../user/user-create';

export class ConfigurationCreate {
  
  configBank: Bank;

  configEntity: EntityBean;

  configHostIP: String;

  configHostPort: number;

  configUsername: String;

  configPassword: String;

  configPasswordTrackCount: number;

  configPasswordExpiry: number;

  configLockCounter: number;

  configRecordPerPage: number;

  configMailAddress: String;

  configCaptchaEnabled: String;
}
