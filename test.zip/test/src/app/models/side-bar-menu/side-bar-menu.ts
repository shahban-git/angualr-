export class SideBarModel {

    menuId : number;
    displayName: String;
    iconName:  String;
    iconUrl: String;
    iconUrlActive: String;
    route:  String;
}