export class FilterModel {

  name : String;

  page : Number;

  size : Number ;
 }
