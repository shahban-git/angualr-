export class RegionCreate {
}
