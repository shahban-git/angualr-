export class RegionView {
}
