export class ZoneView {
    bankName: string;

    branchCreationDate: string;
  
    branchStatus: number;
  
    branchName: string;
  
    branchCode: string;
}
