import { Bank, EntityBean } from '../user/user-create';
export class ZoneCreate {
    bank: {};

    zoneEntity: {};

    zoneName: {};

    country: {};

}
