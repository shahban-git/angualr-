export class BranchView {
  bankName: string;

  branchCreationDate: string;

  branchStatus: number;

  branchName: string;

  branchCode: string;
}
