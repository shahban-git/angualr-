import { Bank, EntityBean } from '../user/user-create';

export class BranchUpdate {
  branchBank: Bank;

  branchEntity: EntityBean;

  branchCode: String;

  branchMasterAop: String;

  branchAddress: String;

  branchPin: String;

  branchCity: String;

  branchState: String;

  branchCoutry: String;

  branchPhone: String;

  branchAbbreviation: String;

  branchDesc: String;
}
