export class UserView {

    userId: number;

    userName: String;

    bankName: String;

    branchName: String;

    usercount: number;

    userStatus: number;

    userCreation: Date;
}