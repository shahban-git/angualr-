export interface Bank {
        bankId : number
}
export interface Role {
    roleId : number
}

export interface EntityBean {
  entityId : number
}
export class UserCreate {

    userId : number;
    userName: String;
    userFirstName: String;
    userEmail: String;
    userEmployeeId: String;
    userRole: Role ;
    userPhone: String;
    userFromDate: String;
    userToDate: String;
    userStatus: String;
    userBank: Bank ;
    userBranch: number;
    userZone: number;
    userRegion:number;
    userDesignationId : number;
    userDepartmentId : number;
    reportingOfficer : String;
    userValidFrom : Date;
	userValidTo : Date;
    isMask: String;

    // To Fix
    userBankName : String
    userBranchName : String
    userLock: String
    

}
