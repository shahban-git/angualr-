export class ProductView{

    productCreationDate : String;

    productStatus : string;

    productName : string ;

    businessType : String;

    subProductName : String[];

    entityId : Number;
}
