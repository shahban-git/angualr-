import { Component, OnInit,ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import {IcmgenComponent} from '../icmgen/icmgen.component'
import { ProductModel } from './prd-model';
import { ProductService } from './prd-service';
import Swal from 'sweetalert2'; 

@Component({
  selector: 'app-prd',
  templateUrl: './prd.component.html',
  styleUrls: ['./prd.component.css']
})

export class PrdComponent implements OnInit {
  @ViewChild('f', { static: false }) signupForm: NgForm;
  schemes=['VISA','MasterCard','RuPay','Diners'];
  businesses=['ACQUIRER','ISSUER','FINTECH','ALL'];
  isEnable=false;
  loaddate="loading";
  constructor(private router: Router,private route: ActivatedRoute,public icmgenservice: IcmgenComponent,private prdservice:ProductService) { }
  prddetail:ProductModel={
    
    bussinessType: '',
    enId: '',
    orgId: '',
    productId: '',
    schemeType: '',
    status: '',
    userId: ''
  }

  ngAfterContentInit() {
    console.log('ngAfterViewChecked called!');
    
  }


  ngOnInit(): void {
    console.log(this.icmgenservice.prddetail);
    this.loaddate=this.icmgenservice.loaddate;
    let productId = this.icmgenservice.productId;
    console.log('product_id============'+productId);
    if(productId!=undefined)
    {
      this.prdservice.getProductById(productId).subscribe(
        result=>{
          this.prddetail=result;
        }
      );
    }
    this.prddetail=this.icmgenservice.prddetail;
    console.log('rrrrrrrrrrrrrrrr'+this.prddetail);
    console.log(this.route.snapshot.queryParams.mode);
    console.log('this.icmgenservice.mode'+this.icmgenservice.mode);
    if(this.icmgenservice.mode=='view')
    {
      this.isEnable=true;
    }
  }
  onSubmit(){
    console.log('Submit');

  }

  saveProduct(){

    this.icmgenservice.setProduct(this.signupForm);
    Swal.fire('Success', 'Product Saved', 'success');

  }

  getNext()
  {
    
    


    this.router.navigate(['dashboard/product-setup/gen/issbin']);
  }
}
