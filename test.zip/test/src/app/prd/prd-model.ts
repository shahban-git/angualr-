import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
  })

export class ProductModel{

    bussinessType: string;
    enId: string;
    orgId: string;
    productId: string;
    schemeType: string;
    status: string;
    userId: string

}