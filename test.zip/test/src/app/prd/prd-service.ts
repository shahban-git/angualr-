import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { ProductModel } from './prd-model';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import {environment} from '../icm/environment/environment.prod'
@Injectable({
    providedIn: 'root'
  })

export class ProductService{

  readonly APIUrl = environment.apiUrl;

    constructor(private http:HttpClient,private prddetail:ProductModel){

    }

    result1:ProductModel;

    getProductById(productId): Observable<ProductModel>
    {

        return this.http.get<{[key:number]:ProductModel}>(this.APIUrl+'global-onboarding/getProduct/'+productId)
      .pipe(
          map((responsedata:{[key:number]:ProductModel})=>{
            for(const key in responsedata)
            {
              this.result1 = responsedata[key];
              console.log('this.result::::: '+this.result1);
             return this.result1; 
             
            }
          }

          )

      );

     


    }

    addProduct(signupForm,entityId,productId): Observable<any>
    {
        //this.prddetail.productId=signupForm.value.memid;
        this.prddetail.schemeType=signupForm.value.schemeType;
        this.prddetail.bussinessType=signupForm.value.bussinessType;
        this.prddetail.enId=entityId;
        this.prddetail.productId=productId;
        this.prddetail.status='Saved';
         return this.http.post(this.APIUrl+'global-onboarding/addProduct',this.prddetail);

        
      


        
    }

    editProduct(signupForm,entityId)
    {
        this.prddetail.productId=signupForm.value.memid;
        this.prddetail.schemeType=signupForm.value.schemeType;
        this.prddetail.bussinessType=signupForm.value.bussinessType;
        this.prddetail.enId=entityId;
        this.prddetail.status='Saved';
        console.log('prd id:::::::::'+this.prddetail.productId);
        console.log('bussinessType id:::::::::'+this.prddetail.bussinessType);
        console.log('schemeType id:::::::::'+this.prddetail.schemeType);
        console.log('enId id:::::::::'+this.prddetail.enId);
        console.log('prd :::::::::'+this.prddetail);

        this.http.post(this.APIUrl+'global-onboarding/updateProduct/'+this.prddetail.productId,this.prddetail).subscribe(
        response=>{
          console.log('response after adding '+response);
        }
      )

    }

    submitProductDetails(prd)
    {
        
        this.prddetail.productId=prd.productId;
        this.prddetail.schemeType=prd.schemeType;
        this.prddetail.bussinessType=prd.bussinessType;
        this.prddetail.enId=prd.enId;
        this.prddetail.status='Pending';

        console.log('prd id:::::::::'+this.prddetail.productId);
        console.log('bussinessType id:::::::::'+this.prddetail.bussinessType);
        console.log('schemeType id:::::::::'+this.prddetail.schemeType);
        console.log('enId id:::::::::'+this.prddetail.enId);
        console.log('prd :::::::::'+this.prddetail);

        return this.http.post(this.APIUrl+'global-onboarding/addProduct',this.prddetail);

    }

    certifyProductDetails(prd)
    {
        
        this.prddetail.productId=prd.productId;
        this.prddetail.schemeType=prd.schemeType;
        this.prddetail.bussinessType=prd.bussinessType;
        this.prddetail.enId=prd.enId;
        this.prddetail.status='Approved';

        console.log('prd id:::::::::'+this.prddetail.productId);
        console.log('bussinessType id:::::::::'+this.prddetail.bussinessType);
        console.log('schemeType id:::::::::'+this.prddetail.schemeType);
        console.log('enId id:::::::::'+this.prddetail.enId);
        console.log('prd :::::::::'+this.prddetail);

        return this.http.post(this.APIUrl+'global-onboarding/addProduct',this.prddetail);

    }

    rejectProductDetails(prd)
    {
        
        this.prddetail.productId=prd.productId;
        this.prddetail.schemeType=prd.schemeType;
        this.prddetail.bussinessType=prd.bussinessType;
        this.prddetail.enId=prd.enId;
        this.prddetail.status='Rejected';

        console.log('prd id:::::::::'+this.prddetail.productId);
        console.log('bussinessType id:::::::::'+this.prddetail.bussinessType);
        console.log('schemeType id:::::::::'+this.prddetail.schemeType);
        console.log('enId id:::::::::'+this.prddetail.enId);
        console.log('prd :::::::::'+this.prddetail);

        return this.http.post(this.APIUrl+'global-onboarding/addProduct',this.prddetail);

    }



}

