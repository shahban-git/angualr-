import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AcqbinComponent } from './acqbin/acqbin.component';
import { IcmComponent } from './icm/icm.component';
import { IcmgenComponent } from './icmgen/icmgen.component';
import { IssbinComponent } from './issbin/issbin.component';
import { DashboardComponent } from './layouts/dashboard/dashboard.component';
import { DefaultComponent } from './layouts/default/default.component';
import { CertificationViewComponent } from './layouts/modules/certification-home/certification-view/certification-view.component';
import { ChangePasswordComponent } from './layouts/modules/change-password/change-password.component';
import { DashboardViewComponent } from './layouts/modules/dashboard-view/dashboard-view.component';
import { LoginComponent } from './layouts/modules/login/login.component';
import { MasterSetupComponent } from './layouts/modules/master-setup/master-setup.component';
import { AddLinkComponent } from './layouts/modules/product-menu-setup/add-link/add-link.component';
import { LinkListComponent } from './layouts/modules/product-menu-setup/link-list/link-list.component';
import { AddProductComponent } from './layouts/modules/product-setup/add-product/add-product.component';
import { ProductsListComponent } from './layouts/modules/product-setup/products-list/products-list.component';
import { ReportComponent } from './layouts/modules/report/report.component';
import { SiCancelledAllTxnRangeReportComponent } from './layouts/modules/report/si-cancelled-all-txn-range-report/si-cancelled-all-txn-range-report.component';
import { SiCancelledNextTxnRangeReportComponent } from './layouts/modules/report/si-cancelled-next-txn-range-report/si-cancelled-next-txn-range-report.component';
// import { SiDailyMISReportComponent } from '../../backup/si-daily-mis-report/si-daily-mis-report.component';
import { SiDailyMISReportComponent } from "./layouts/modules/report/si-daily-mis-report/si-daily-mis-report.component";
import { SiCancelledRangeReportComponent } from './layouts/modules/report/si-cancelled-range-report/si-cancelled-range-report.component';
import { SiCancelledSpecificDateReportComponent } from './layouts/modules/report/si-cancelled-specific-date-report/si-cancelled-specific-date-report.component';
import { SiDeclinedTxnRangeReportComponent } from './layouts/modules/report/si-declined-txn-range-report/si-declined-txn-range-report.component';
import { SiModifiedRangeReportComponent } from './layouts/modules/report/si-modified-range-report/si-modified-range-report.component';
import { SiReportComponent } from './layouts/modules/report/si-report/si-report.component';
import { SiTransactionReportComponent } from './layouts/modules/report/si-transaction-report/si-transaction-report.component';
import { AddUserComponent } from './layouts/modules/users/add-user/add-user.component';
import { PrdComponent } from './prd/prd.component';
// import { SiReportComponent } from './reports/si-report/si-report.component';
import { AuthGuardService } from './services/subscribe/auth-guard.service';

const routes: Routes = [{
  path:'',
  component:DefaultComponent
},
{
  path:'login',
  component:LoginComponent
},

{
  path:'changePassword',
  component:ChangePasswordComponent
},

{path:'dashboard',
canActivate: [AuthGuardService],
component:DashboardComponent,
children:[
  {
    path:'',
    canActivate: [AuthGuardService],
    component:DashboardViewComponent
  },
  {
    path:'master',
    canActivate: [AuthGuardService],
    component:MasterSetupComponent
  },
  // {
  //   path:'changePassword',
  //   canActivate: [AuthGuardService],
  //   component:ChangePasswordComponent
  // },
  {
    path:'user',
    canActivate: [AuthGuardService],
    component:AddUserComponent,
  },
  {
    path:'certification',
    component:CertificationViewComponent,
    canActivate: [AuthGuardService],
  },
  {
    path:'report',
    canActivate: [AuthGuardService],
    component:ReportComponent
  },

  //{
  //  path:'si_report',
  //  canActivate: [AuthGuardService],
  //  component:SiReportComponent,
  //},
  {
    path:'product-setup',
    canActivate: [AuthGuardService],
    component:ProductsListComponent,
    children: [
  { path:'icm-page' ,component:IcmComponent},
  { path:'gen',component:IcmgenComponent, children: [
  { path:'network' ,component:PrdComponent},
  { path:'issbin', component:IssbinComponent} ,
  { path:'acqbin', component:AcqbinComponent}
]}
  ]
  },
  {
    path:'product-menu-setup',
    canActivate: [AuthGuardService],
    component:LinkListComponent,
  },
  {
    path:'add_product',
    canActivate: [AuthGuardService],
    component:AddProductComponent,
  },
  {
    path:'add_link',
    canActivate: [AuthGuardService],
    component:AddLinkComponent,
  },

  {
    path:'si_report',
    canActivate: [AuthGuardService],
    component:SiReportComponent,
  },
  {
    path:'si_cancelled_range_report',
    canActivate: [AuthGuardService],
    component:SiCancelledRangeReportComponent,
  },
  {
    path:'si_cancelled_specific_date_report',
    canActivate: [AuthGuardService],
    component:SiCancelledSpecificDateReportComponent,
  },
  {
    path:'si_modified_range_report',
    canActivate: [AuthGuardService],
    component:SiModifiedRangeReportComponent,
  },
  {
    path:'si_transaction_report',
    canActivate: [AuthGuardService],
    component:SiTransactionReportComponent,
  },
  {
    path:'si_declined_txn_range_report',
    canActivate: [AuthGuardService],
    component:SiDeclinedTxnRangeReportComponent,
  },
  {
    path:'si_cancelled_all_txn_range_report',
    canActivate: [AuthGuardService],
    component:SiCancelledAllTxnRangeReportComponent,
  },
  {
    path:'si_cancelled_next_txn_range_report',
    canActivate: [AuthGuardService],
    component:SiCancelledNextTxnRangeReportComponent,
  },
  {
    path:'si_daily_mis_report',
    canActivate: [AuthGuardService],
    component:SiDailyMISReportComponent,
  }
]
},
{
  path: '**', redirectTo: 'login'
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
