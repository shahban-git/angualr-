import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IcmComponent } from './icm.component';

describe('IcmComponent', () => {
  let component: IcmComponent;
  let fixture: ComponentFixture<IcmComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IcmComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IcmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
