import { Component, OnInit } from '@angular/core';
import {MatTableDataSource} from '@angular/material/table';
import {MatDatepickerModule} from '@angular/material/datepicker'; 
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { Router, ActivatedRoute } from '@angular/router';
import { AppComponent } from '../app.component';
import { IcmService } from './icm-service';
import { ProductModel } from '../prd/prd-model'
import { query } from '@angular/animations';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-icm',
  templateUrl: './icm.component.html',
  styleUrls: ['./icm.component.css']
})
export class IcmComponent implements OnInit {

  constructor(private app: AppComponent,private icmservive : IcmService,private modalService: NgbModal,private router: Router,private route: ActivatedRoute) { }
  closeResult = '';
  entid='';
  status='';
  displayedColumns: string[] = ['Entity Id', 'Product Id','Product Details', 'Scheme Details','Form Status','Action'];
  memList:ProductModel[]=[];
  dataSource:MatTableDataSource<ProductModel>;
  prddetail:ProductModel={
    
    bussinessType: '',
    enId: '',
    orgId: '',
    productId: '',
    schemeType: '',
    status: '',
    userId: ''
  }

  ngOnInit(): void {
    this.memList.splice(0, this.memList.length);
    console.log('init called'+this.memList.length);
    //this.memList=this.app.getMemList();
    //console.log('sssssssssssssssssssss'+this.memList[0].details);
    if(this.route.snapshot.queryParams.entid!=undefined)
    {

      this.entid=this.route.snapshot.queryParams.entid;
      console.log('this.route.snapshot.queryParams.status::'+this.route.snapshot.queryParams.status);
      
      this.status = this.route.snapshot.queryParams.status;
      
      console.log('status::::::::::::::'+this.status);
      if(this.status==undefined)
      {
        this.icmservive.getIssProductList(this.entid).pipe(
          map((responsedata:{[key:number]:ProductModel})=>{
            for(const key in responsedata)
            {
              this.memList.push(responsedata[key]);
            }
            this.dataSource = new MatTableDataSource(this.memList);
            console.log('memList:::::::::::::::'+this.memList);
            
          }

          )

      )
      .subscribe(
        result =>{
          console.log(result);
          
        }
      
      );

      }else{
        this.icmservive.getIssProductStatusList(this.entid,this.status).pipe(
          map((responsedata:{[key:number]:ProductModel})=>{
            for(const key in responsedata)
            {
              this.memList.push(responsedata[key]);
            }
            this.dataSource = new MatTableDataSource(this.memList);
            console.log('memList:::::::::::::::'+this.memList);
          }

          )

      )
      .subscribe(
        result =>{
          console.log(result);
          this.dataSource = new MatTableDataSource(this.memList);
          console.log('memList:::::::::::::::'+this.memList);
          
        }
      
      );
      }
      
    }
    console.log('entid:::::::::::::::'+this.entid);
    this.refreshBankList();
  }

  refreshBankList()
 {
   //this.memList.push(this.prddetail);
  
 

 }
  addMemList(mList)
  {
    /*console.log('melist:::::b4::::::'+this.memList.length);
    console.log('melist:::::::::::'+mList);
    this.memList.push(mList);
    console.log('melist:::::::::::'+this.memList.length);*/
  }

  /*open(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }*/

  addDetails(){
    console.log('Added ,.....');
    this.router.navigate(['dashboard/product-setup/gen/network'],{queryParams:{mode:'add',entid:this.entid}});
  }
  editDetails(prodId){
    console.log('Added ,.....');
    this.router.navigate(['dashboard/product-setup/gen/network'],{queryParams:{mode:'edit',entid:this.entid,productId:prodId}});
  }
  viewDetails(prodId){
    console.log('Added ,.....');
    this.router.navigate(['dashboard/product-setup/gen/network'],{queryParams:{mode:'view',entid:this.entid,productId:prodId}});
  }
  certifyDetails(prodId){
    console.log('Added ,.....');
    this.router.navigate(['dashboard/product-setup/gen/network'],{queryParams:{mode:'certify',entid:this.entid,productId:prodId}});
  }

}
