import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { map } from 'rxjs/operators';
import { ProductModel } from '../prd/prd-model'
import {MatTableDataSource} from '@angular/material/table';
import {environment} from './environment/environment.prod';
@Injectable({
  providedIn: 'root'
})

export class IcmService{

    readonly APIUrl = environment.apiUrl;
    constructor(private http:HttpClient) { }
    result1:ProductModel[]=[];
    getIssProductList(entityId){
        this.result1.splice(0, this.result1.length);

    

      return this.http.get<{[key:number]:ProductModel}>(this.APIUrl+'global-onboarding/getProductListByEntityId/'+entityId)
      /*.pipe(
          map((responsedata:{[key:number]:ProductModel})=>{
            for(const key in responsedata)
            {
              this.result1.push(responsedata[key]);
            }
            
          }

          )

      )
      .subscribe(
        result =>{
          console.log(result);
          
        }
      
      );

     return this.result1; */

  }

  getIssProductStatusList(entityId,status){
    this.result1.splice(0, this.result1.length);



  return this.http.get<{[key:number]:ProductModel}>(this.APIUrl+'global-onboarding/getProductListByEntityIdAndStatus/'+entityId+'/'+status)
  /*.pipe(
      map((responsedata:{[key:number]:ProductModel})=>{
        for(const key in responsedata)
        {
          this.result1.push(responsedata[key]);
        }
      }

      )

  )
  .subscribe(
    result =>{
      console.log(result);
      
    }
  
  );

 return this.result1; */

}

  



}