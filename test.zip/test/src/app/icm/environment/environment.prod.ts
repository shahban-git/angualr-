export const environment = {
    production: true,
    apiUrl: 'http://192.168.83.170:7458/',
    refreshTime : 720000,
    idleTimeout : 1200000
  };
  