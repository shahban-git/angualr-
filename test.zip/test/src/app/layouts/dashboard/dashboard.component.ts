import { BreakpointObserver } from '@angular/cdk/layout';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { LoginService } from 'src/app/services/subscribe/login.service';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  mode = 'side';
  opened = true;
  linkValues ;
  constructor(private route: ActivatedRoute, private service : LoginService, private breakpointObserver: BreakpointObserver ) {
    this.linkValues = localStorage.getItem('linkValues');
    breakpointObserver.observe([
      '(max-width: 767px)']).subscribe(result => {
        if (result.breakpoints['(max-width: 767px)']){
          this.mode = 'over';
          this.opened = false;
        }else{
          this.mode = 'side';
          this.opened = true;
        }
      });
    }

  ngOnInit(): void {
     
  }

  toggleSidenavEvent(event){
    console.log("header vent",event);
    if(event){
      //this.drawer.toggle()
      this.opened = !this.opened;
    }
  }

}
