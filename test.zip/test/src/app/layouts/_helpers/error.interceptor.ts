import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { LoginService } from 'src/app/services/subscribe/login.service';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {

  constructor(private authenticationService: LoginService,public router :  Router) {
  }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        return next.handle(request).pipe(catchError(err => {
            if (err.error["statusCode"] == "A02" ) {
                console.log("77777777777777777",err)
                // this.messagesBoxService.openSnackBar(err.error["statusDesc"]);
                // this.authenticationService.logout();
                this.authenticationService.logout().subscribe((res) => {
                  Swal.fire({
                    imageUrl: 'assets/images/warning.svg',
                    text: err.error["statusDesc"],
                    confirmButtonText: `OK`,
                    
                    // showConfirmButton: false
                  })
                  .then((result) => {  
                    /* Read more about isConfirmed, isDenied below */  
                      if (result.isConfirmed) {    
                        Swal.fire( window.location.href = "login")  
                      } else if (result) {    
                        Swal.fire('Changes are not saved', '', 'info')  
                     }
                  });
                  
                  
                  
                  
                  
                //   .then(okay => {
                //     if (okay) {
                //      window.location.href = "login";
                //    }
                // });
                
                    sessionStorage.clear();
                    localStorage.removeItem('currentUser');
                    localStorage.removeItem('linkValues');
                    localStorage.removeItem('cdPms');
                    localStorage.removeItem('entityId');
                    sessionStorage.removeItem('Token');
                    sessionStorage.removeItem('rt');
                    localStorage.removeItem('viewData');
                    localStorage.removeItem('tabInd')
                    if (!location.pathname.includes('auth')) {
                      location.reload();
                    }
                    this.authenticationService.stopTimer();
                    // this.router.navigate(['login']);
              
                }, error => {
              
                })
                //location.reload(true);
           }
            
            const error = err || err.statusText;
            return throwError(error);
        })
        )
    }
}