import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder, FormArray } from '@angular/forms';
import { BranchCreate } from 'src/app/models/branch/branch-create';
import { BranchService } from 'src/app/services/master/branch.service';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-edit-branch',
  templateUrl: './edit-branch.component.html',
  styleUrls: ['./edit-branch.component.css']
})
export class EditBranchComponent implements OnInit {
  @Output() cancelEvent = new EventEmitter<any>();
  @Input() userNameFromParent: string;
  addBranchForm: FormGroup;
  branchCreate: BranchCreate;
  submitted = false;
  bankList;
  countryList;
  stateList;
  cityList;
  entityId;
  branch: BranchCreate = new BranchCreate()
  zoneList: any;
  regionList: any;
  bankId: any;

  constructor(private formBuilder: FormBuilder, private service: BranchService, private router: Router) { }

  ngOnInit(): void {
    this.entityId = localStorage.getItem('entityId');
    this.formInit();
    this.fetchBank();
    this.fetchCountry();
    this.bankId = JSON.parse(this.userNameFromParent).bankId
    this.fetchBranch(JSON.parse(this.userNameFromParent).bankId)
    this.getBranchId(JSON.parse(this.userNameFromParent).branchId)
  }

  formInit() {
    this.addBranchForm = this.formBuilder.group({
      branchBank: ["", Validators.required],
      branchAbbreviation: ["", Validators.required],
      branchDescription: ["", Validators.required],
      branchState: ['', Validators.required],
      branchZone: [''],
      branchRegion: [''],
      branchEntity: [{ entityId: this.entityId }],
      branchCode: ['', Validators.required],
      branchCountry: ['', Validators.required],
      branchAddress: ['', Validators.required],
      branchPin: ['', Validators.required],
      branchCity: ['', Validators.required],
      branchPhone: ['', Validators.required]
    });
  }
  // convenience getters for easy access to form fields
  get f() { return this.addBranchForm.controls; }

  onSubmit(form: FormGroup) {
    this.submitted = true;
    this.branch = form.value
    this.branch.branchBank = {
      bankId: JSON.parse(this.userNameFromParent).bankId
    }
    this.branch['branchId'] = JSON.parse(this.userNameFromParent).branchId

    if (form.invalid) {
      return
    }
    else {
      this.service.updateBranch(this.branch).subscribe(res => {
        if(res['statusCode']=="R106"){
          Swal.fire({
            imageUrl: 'assets/images/checked_icon.svg',
            text: 'Branch has been update successfully'
          })
  
          this.router.navigate(['dashboard'])
        }
        else{
          Swal.fire({
            imageUrl: 'assets/images/warning.svg',
            text: res['statusDesc']
          })
        }
     
      },(error)=>{
        Swal.fire({
          imageUrl: 'assets/images/warning.svg',
          text:"Server Not Responding, Please Try Again Later."
        })
      }
      );
    }
  }

  fetchBank() {
    this.addBranchForm.controls['branchZone'].reset();
    this.addBranchForm.controls['branchRegion'].reset();
    this.service.fetchBankList().subscribe((res) => {
      // this.bankList = res['Bank DropDown'];
      if(res['statusCode']=="R112"){
        this.bankList = res['data'];
      }
    });

  }

  fetchBranch(bankId: number) {
    this.fetchZone(bankId)
  }

  fetchCountry() {
    this.service.fetchCountryList().subscribe((res) => {
      // this.countryList = res['Country DropDown'];
      if(res['statusCode']=="R128"){
        this.countryList = res['data'];
      }
    });
  }

  fetchState(cntName: String) {
    this.addBranchForm.get('branchState').reset();
    this.service.fetchStateList(cntName).subscribe((res) => {
      this.stateList = res['State Dropdown'];
    });
  }

  fetchCity(cntName: String, stateName: String) {
    this.addBranchForm.get('branchCity').reset();
    this.service.fetchCityList(cntName, stateName).subscribe((res) => {
      this.cityList = res['City Dropdown'];
    });
  }

  fetchZone(bankId) {
    this.service.fetchZoneList(bankId).subscribe((res) => {
      // this.zoneList = res['Zone DropDown'];
      if(res['statusCode']=="R096"){
        this.zoneList = res['data'];
      }
    });
  }

  fetchRegion(bankId, zoneId) {
    console.log("eeeeeeeeeeeeeeeeeee",bankId,zoneId)
    this.service.fetchRegionList(bankId, zoneId).subscribe((res) => {
      // this.regionList = res['Region Bank-Zone'];
      if(res['statusCode']=="R087"){
        this.regionList = res['data'];

      }
    });
  }

  cancel() {
    this.cancelEvent.emit({ name: JSON.parse(this.userNameFromParent).bank, type: "cancel", category: 'branch' });
  }

  getBranchId(branchId) {
    this.service.getBranchId(branchId).subscribe((res) => {
      console.log("edittttttttttttttttt",res);
      if(res['statusCode']=="R099"){
        this.fetchRegion(JSON.parse(this.userNameFromParent).bankId, +res['data']['branchZone']);
        this.fetchState(res['data']['branchAddress']['addrCountry']);
        this.fetchCity(res['data']['branchAddress']['addrCountry'], res['data']['branchAddress']['addrState'])
        this.addBranchForm.patchValue({
          branchBank: +res['data']['branchBank']['bankId'],
          branchAbbreviation: res['data']['branchAbbreviation'],
          branchDescription: res['data']['branchDescription'],
          branchState: res['data']['branchAddress']['addrState'],
          branchZone: +res['data']['branchZone'],
          branchRegion: +res['data']['branchRegion'],
          branchEntity: { entityId: +res['data']['branchEntity']['entityId'] },
          branchCode: res['data']['branchCode'],
          branchCountry: res['data']['branchAddress']['addrCountry'],
          branchAddress: res['data']['branchAddress']['address1'],
          branchPin: res['data']['branchAddress']['addrPin'],
          branchCity: res['data']['branchAddress']['addrCity'],
          branchPhone: res['data']['branchPhone']
        })
      }
     
    });
  }

}
