import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import {FormGroup, FormControl, Validators,FormBuilder, FormArray} from '@angular/forms';
import { BranchCreate } from 'src/app/models/branch/branch-create';
import { BranchService } from 'src/app/services/master/branch.service';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-add-branch',
  templateUrl: './add-branch.component.html',
  styleUrls: ['./add-branch.component.css']
})
export class AddBranchComponent implements OnInit {

  addBranchForm: FormGroup;
  branchCreate : BranchCreate;
  submitted = false;

   @Output() nameEvent = new EventEmitter<any>();
  bankList;
  countryList;
  stateList;
  cityList;
  entityId;
  branch: BranchCreate = new BranchCreate()
  zoneList: any;
  regionList: any;
  bankId: number;
  constructor(private formBuilder: FormBuilder, private service : BranchService,private router : Router) { }

  ngOnInit(): void {
    this.entityId = localStorage.getItem('entityId');
    this.formInit();
    this.fetchBank();
    this.fetchCountry();
  }
  formInit(){
    this.addBranchForm = this.formBuilder.group({
      branchBank: ["", Validators.required],
      branchAbbreviation: ["", Validators.required],
      branchDescription: ["", Validators.required],
      branchState:['', Validators.required],
      branchZone:[''],
      branchRegion:[''],
      branchEntity : [{entityId : this.entityId}],
      branchMasterAop:['', Validators.required],
      branchCode:['', Validators.required],
      branchCountry :['', Validators.required],
      branchAddress:['', Validators.required],
      branchPin:['', Validators.required],
      branchCity:['', Validators.required],
      branchPhone:['', Validators.required]
   });
  }
  // convenience getters for easy access to form fields
  get f() { return this.addBranchForm.controls; }

  onSubmit(form: FormGroup) {
//--------------------
this.submitted = true;
this.branch = form.value
this.branch.branchBank = {
  bankId : form.value['branchBank']
}
if(form.invalid)
    {
        return
    }
    else
    {
this.service.createBranch(this.branch).subscribe(res => {
  console.log("submitttttttttttttttt",res)
  if(res['statusCode']=="R104"){
    Swal.fire({
      imageUrl : 'assets/images/checked_icon.svg',
      text: 'Branch has been saved successfully'
    })
    this.nameEvent.emit({name:"",type:"",category:'branch'});
    this.router.navigate(['dashboard'])
  }
  else{
    Swal.fire({
      imageUrl: 'assets/images/warning.svg',
      text: res['statusDesc']
    })
  }

 
  // form.reset();
},(error)=>{
  Swal.fire({
    imageUrl: 'assets/images/warning.svg',
    text: "Server Not Responding, Please Try Again Later."
  })
});
}
//-------------------
 }
 reset(){
  this.addBranchForm.reset();
  this.addBranchForm.markAsPristine();
    this.addBranchForm.markAsUntouched();
    this.addBranchForm.updateValueAndValidity();
    this.submitted = false;
 }

 fetchBank() {
  this.addBranchForm.controls['branchZone'].reset();
  this.addBranchForm.controls['branchRegion'].reset();
  this.service.fetchBankList().subscribe((res) => {
      if(res['statusCode']=="R112"){
        this.bankList = res['data'];
      }
    
  });
  
}

fetchBranch(bankId : number) {
  this.bankId=bankId
  this.fetchZone(bankId)
}

fetchCountry() {
  this.service.fetchCountryList().subscribe((res) => {
      if(res['statusCode']=="R128"){
        this.countryList = res['data'];
      }
  });
}
fetchState(cntName : String)
{
  this.addBranchForm.get('branchState').reset();
  this.service.fetchStateList(cntName).subscribe((res) => {
    if(res['statusCode']=="R157"){
      this.stateList = res['data'];

    }
  });
}
fetchCity(cntName : String, stateName : String)
{
  this.addBranchForm.get('branchCity').reset();
  this.service.fetchCityList(cntName, stateName).subscribe((res) => {
    if(res['statusCode']=="R150"){
      this.cityList = res['data'];

    }
  });
}

fetchZone(bankId) { 
  this.service.fetchZoneList(bankId).subscribe((res) => {
    if(res['statusCode']=="R096"){
      this.zoneList = res['data'];
    }
  });
}

fetchRegion(bankId,zoneId) { 
  this.service.fetchRegionList(bankId,zoneId).subscribe((res) => {
      if(res['statusCode']=="R087"){
        this.regionList = res['data'];

      }
  });
}
}
