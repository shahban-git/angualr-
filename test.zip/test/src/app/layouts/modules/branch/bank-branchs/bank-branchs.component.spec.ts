import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BankBranchsComponent } from './bank-branchs.component';

describe('BankBranchsComponent', () => {
  let component: BankBranchsComponent;
  let fixture: ComponentFixture<BankBranchsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BankBranchsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BankBranchsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
