import {
  Component,
  OnInit,
  Input,
  ViewChild,
  Output,
  EventEmitter,
} from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { BranchView } from 'src/app/models/branch/branch-view';
import { BranchService } from 'src/app/services/master/branch.service';
import { FilterModel } from 'src/app/models/filter';
import { BranchUpdate } from 'src/app/models/branch/branch-update';

@Component({
  selector: 'app-bank-branchs',
  templateUrl: './bank-branchs.component.html',
  styleUrls: ['./bank-branchs.component.css'],
})
export class BankBranchsComponent implements OnInit {
  @Output() nameEvent = new EventEmitter<any>();
  @Input() userNameFromParent;
  crudPriv: number;
  displayedColumns: string[] = [
   
    'member name',
    'branch_name',
    'branch_code',
    'creation_date',
    'status',
  ];
  dataSource: MatTableDataSource<BranchView>;
  filterModel: FilterModel = new FilterModel();
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  totalCount: Number;
  branchDetailMes

  constructor(private service: BranchService) {
    this.filterModel = {
      name: '',
      page: 0,
      size: 5
    }
  }

  ngOnInit(): void {
    this.crudPriv = +localStorage.getItem('cdPms');
    this.userNameFromParent = JSON.parse(this.userNameFromParent);
    this.getBranchView(this.userNameFromParent, this.filterModel);
  }

  passName(e, element, type) {
    e.preventDefault();
    this.nameEvent.emit({ name: element, type: type, category: 'branch' });
  }

  back() {
    this.nameEvent.emit({ name: '', type: '', category: 'branch' });
  }

  getBranchView(bankName: string, pageParams) {
    console.log("bankkkkkknameeeeee",this.userNameFromParent)
    this.service.viewSubListBranch(bankName['bankName'].trim(), pageParams).subscribe(
      data => {
        console.log("@@@@@@@@@@@",data);
        if(data['statusCode']=="R108"){
          if(data["data"]['content'].length>0){
            this.dataSource = new MatTableDataSource(data["data"]['content']);
            this.totalCount = data["data"]['totalElements'];
          }
          else{
            this.dataSource=null;
            this.branchDetailMes="No Records Found."
          }
        }
        else{
          this.dataSource=null;
          this.branchDetailMes=data['statusDesc']
        }
       
        //this.dataSource.paginator = this.paginator;
      },(error)=>{
        this.dataSource=null;
        this.branchDetailMes="Server Not Responding, Please Try Again Later."
      }
    );
  }

  paginatorClick(pageNum: Number) {
    this.filterModel.page = pageNum['pageIndex'];
    this.filterModel.size = pageNum['pageSize'];
    this.getBranchView(this.userNameFromParent, this.filterModel);

  }

  onSearch(event: Event) {
    this.paginator.firstPage();
    this.filterModel.name = (event.target as HTMLInputElement).value
    this.filterModel.page = 0;
    this.filterModel.size = 5;
    this.getBranchView(this.userNameFromParent, this.filterModel);

  }

}
