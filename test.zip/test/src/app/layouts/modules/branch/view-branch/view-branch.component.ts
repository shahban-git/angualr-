import {
  Component,
  OnInit,
  ViewChild,
  Output,
  EventEmitter,
} from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { Router } from '@angular/router';
import { BankView } from 'src/app/models/bank/bank-view';
import { BranchService } from 'src/app/services/master/branch.service';
import { FilterModel } from 'src/app/models/filter';

@Component({
  selector: 'app-view-branch',
  templateUrl: './view-branch.component.html',
  styleUrls: ['./view-branch.component.css'],
})
export class ViewBranchComponent implements OnInit {
  @Output() nameEvent = new EventEmitter<any>();

  crudPriv: number;
  branchMes;
  displayedColumns: string[] = [ 'member name', 'branches'];
  filterModel: FilterModel = new FilterModel();
  totalCount: number;
  dataSource: MatTableDataSource<BankView>;
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;

  constructor(private router: Router, private service: BranchService) {
    this.filterModel = {
      name : '',
      page: 0,
      size: 5
    }
  }

  ngOnInit(): void {
    this.crudPriv = +localStorage.getItem('cdPms');
    this.refreshBranchList(this.filterModel);
  }
  passName(e, element, type) {
    console.log("qqqqqqqqqqqqqqqqqqqq",element,type,)
    e.preventDefault();
   
    this.nameEvent.emit({ name: element, type: type, category: 'branch' });
  }

  refreshBranchList(pageParams) {
    this.service.getBranchList(pageParams).subscribe((data) => {
      console.log("branchchhhhhhhhhhhhhh",data);
        if(data['statusCode']=="R098"){
          if(data["data"]["content"].length>0){
            this.dataSource = new MatTableDataSource(data["data"]["content"]);
            this.totalCount = data["data"]['totalElements'];
          }
          else{
            this.dataSource=null;
            this.branchMes="No Records Found."
          }
        }
        else{
          this.dataSource=null;
          this.branchMes=data['statusDesc']
        }
    
      //this.dataSource.paginator = this.paginator;
    },(error)=>{
      this.dataSource=null;
      this.branchMes="Server Not Responding, Please Try Again Later."
    });
  }

  paginatorClick(pageNum: Number) {
    this.filterModel.page = pageNum['pageIndex'];
    this.filterModel.size = pageNum['pageSize'];
    this.refreshBranchList(this.filterModel);

  }
  onSearch(event: Event) {
    this.paginator.firstPage();
    this.filterModel.name = (event.target as HTMLInputElement).value
    this.filterModel.page = 0;
    this.filterModel.size = 5;
    this.refreshBranchList(this.filterModel);
  
  }
}
