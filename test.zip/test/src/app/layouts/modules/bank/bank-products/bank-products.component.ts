import { Component, OnInit ,Input,ViewChild, Output, EventEmitter} from '@angular/core';
import { MatTableDataSource} from '@angular/material/table';
import {MatPaginator} from '@angular/material/paginator';
import {PageEvent} from '@angular/material/paginator';
import { ProductView } from 'src/app/models/product/product';
import { BankService } from 'src/app/services/master/bank.service';
import { FilterModel } from 'src/app/models/filter';


@Component({
  selector: 'app-bank-products',
  templateUrl: './bank-products.component.html',
  styleUrls: ['./bank-products.component.css']
})
export class BankProductsComponent implements OnInit {
  @Output() nameEvent = new EventEmitter<any>();
  @Input() userNameFromParent ;
  crudPriv : number;
  displayedColumns: string[] = ['member name', 'Product Name', 'date','status'];
  dataSource : MatTableDataSource<ProductView>;
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  filterModel: FilterModel = new FilterModel();
  totalCount : Number;
  isAdmin : Number;
  productMes
  bankName;
  constructor(private service : BankService) {
    this.filterModel = {
      name : '',
      page: 0,
      size: 5
    }
  }

  ngOnInit(): void {
    this.crudPriv = +localStorage.getItem('cdPms');
    this.isAdmin = +localStorage.getItem('vf');
    // console.log("jsonnnnnnnnnnnnnnnnnnnnn",this.userNameFromParent)
    this.bankName = JSON.parse(this.userNameFromParent);
    if(this.isAdmin == 1)
    {
      this.getProductView(this.bankName.orgName, this.filterModel);
    }
    else
    {
      this.getProductView(this.bankName.memberName, this.filterModel);
    }
    

  }
  passName(e,element){
    e.preventDefault();
    this.nameEvent.emit(element);
  }
  passElement(e,element,type){
    e.preventDefault();
    this.nameEvent.emit({name:element,type:type,category:'bank'});
  }
  back(){
    this.nameEvent.emit({name:"",type:"",category:'bank'});
  }
  getProductView(bankName, pageParams)
  {
    console.log("bankkkknammemme",bankName)
    console.log("crosspolicyyyyyyy",bankName['memberName'])
    console.log("parammmmmmmmmmm",pageParams)
     this.service.viewSubListBank(bankName,pageParams).subscribe(
      data => {
        console.log("sublimkkkkkkkkkkkkkk",data);
        if(data['statusCode']=="R120"){
          if(data["data"]["content"].length>0){
            this.dataSource = new MatTableDataSource(data["data"]["content"]);
            this.totalCount = data["data"]['totalElements']
          }
          else{
            this.dataSource=null;
            this.productMes="No Records Found."
          }
        }
        else{
          this.dataSource=null;
          this.productMes=data['statusDesc']
        }
      
        //this.dataSource.paginator = this.paginator;
      },(error)=>{
        this.dataSource=null;
        this.productMes="Server Not Responding, Please Try Again Later."
      }
    )
  }

  onSearch(event: Event) {
    this.paginator.firstPage();
    this.filterModel.name = (event.target as HTMLInputElement).value
    this.filterModel.page = 0;
    this.filterModel.size = 5;
    this.getProductView(JSON.parse(this.userNameFromParent).memberName, this.filterModel);
  
  }

  paginatorClick(pageNum: Number) {
    this.filterModel.page = pageNum['pageIndex'];
    this.filterModel.size = pageNum['pageSize'];
    this.getProductView(this.userNameFromParent,this.filterModel);

  }
}
