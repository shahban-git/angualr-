import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BankProductsComponent } from './bank-products.component';

describe('BankProductsComponent', () => {
  let component: BankProductsComponent;
  let fixture: ComponentFixture<BankProductsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BankProductsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BankProductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
