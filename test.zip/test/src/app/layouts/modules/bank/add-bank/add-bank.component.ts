import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import {
  FormGroup,
  FormControl,
  Validators,
  FormBuilder,
  FormArray,
} from '@angular/forms';
import { Router } from '@angular/router';
import { Address } from 'src/app/models/address/address';
import { BankCreate } from 'src/app/models/bank/bank-create';
import { BankService } from 'src/app/services/master/bank.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-bank',
  templateUrl: './add-bank.component.html',
  styleUrls: ['./add-bank.component.css'],
})
export class AddBankComponent implements OnInit {
  dynamicForm: FormGroup;
  bankEditForm: FormGroup;
  submitted = false;
  count = 0;
  bankSave: BankCreate = new BankCreate();
  address: Address;
  @Input() userNameFromParent;
  user;
  @Output() nameEvent = new EventEmitter<any>();
  toppingList: String[] = [];
  // : string[] = ['Sub product1', 'sub product 2', 'sub product 3'];
  selectbusiness = ['Issuer', 'Acquirer', 'Fintech', 'Both'];
  countryList;
  stateList;
  cityList;
  conCityList;
  productList;

  formErrors = {
    'primaryPhoneNo': '',
    'memberName'  : '',
    'memberDesc' : '',
    'primaryMobileNo' :'',
    'primaryEmail' : '',
    'legalAddress': '',
    'country': '',
    'state': '',
    'city': '',
    'bankUrl': '',
    'secondaryPhoneNo' : '',
    'secondaryMobileNo' : '',
    'secondaryEmail' : '',
   'contactPerson': '',
   'designation': '',
    'conEmail': '',
    'conPhone': '',
    'conMobile': '',
    'faxNumber': '',
    'addrType': '',
    'conLegalAddr':'',
    'conZipCode': '',
    'constate': '', 
    'conCity': '',
    'orgName': '',
    'productName' : ''

  };

  validationMessages = {
    'primaryPhoneNo': { 'required': 'Primary Phone is required', 
    'min' : 'Phone Number is invalid','pattern':'Only Numbers Allowed' },
    'memberName'  : {'required': 'Member Name is required','minlength' : 'Minimum Length 3 required','maxlength' : 'Maximum Length 15 required', 'pattern' : 'Special characters and Digits not allowed' },
    'memberDesc' : {'required': 'Description is required','minlength' : 'Minimum Length 5 required'},
    'primaryMobileNo' : {'required': 'Primary Mobile is required',
    'min' : 'Mobile Number is invalid','pattern':'Only Numbers Allowed'},
    'primaryEmail' : {'required': 'Primary Email is required', 'email': 'Invalid email format'},
    'legalAddress': {'required': 'Legal Address is required'},
    'country': {'required': 'Country is required'},
    'state': {'required': 'State is required'},
    'city': {'required': 'City is required'},
    'bankUrl': {'required': 'Bank URL is required', 'pattern' : 'URL format is invalid'},
    'secondaryPhoneNo' : {'min' : 'Phone Number is invalid','pattern':'Only Numbers Allowed'},
    'secondaryMobileNo' : {'min' : 'Phone Number is invalid','pattern':'Only Numbers Allowed'},
    'secondaryEmail' : {'email': 'Invalid email format'},
    'contactPerson': {'required': 'Contact Person is required','pattern' : 'Special characters and Digits not allowed' },
    'designation': {'required': 'Designation is required','pattern' : 'Special characters not allowed'},
     'conEmail': {'required': 'Contact Email is required','email': 'Invalid email format'},
     'conPhone': {'required': 'Contact Phone is required','min' :'Phone Number is invalid','pattern':'Only Numbers Allowed'},
     'conMobile': {'required': 'Contact Mobile is required','min' :'Mobile Number is invalid','pattern':'Only Numbers Allowed'},
     'faxNumber': {'required': 'Fax number is required', 'min' : 'Fax is invalid'},
     'addrType': {'required': 'Address Type is required', 'pattern' : 'Special characters and Digits not allowed', 'minlength' : 'Minimum Length 3 required' },
     'conLegalAddr':{'required': 'Legal Address is required'},
     'conZipCode': {'required': 'Zip code is required','min' : 'Invalid Zip Code'},
     'constate': {'required': 'State is required'},
     'conCity': {'required': 'City is required'},
     'orgName': {'required': 'Organization Name is required', 'pattern' : 'Special characters and Digits not allowed'},
     'productName' : {'required': 'Product Name is required'}


  }

  constructor(private formBuilder: FormBuilder, private service: BankService, private router: Router) { }
  ngOnInit(): void {
    this.formInit();
    this.fetchCountry();
    this.fetchProduct();
    //  this.onChangeAdd(1);
    this.dynamicForm.valueChanges.subscribe(data => {
      this.logValidationErrors(this.dynamicForm);
    })
  }
  formInit() {
    // this.user = JSON.parse(this.userNameFromParent);
    // console.log('This User  ', this.user);
    // if (!this.user) {
    //   this.user = 'Axis Bank';
    // }
    this.dynamicForm = this.formBuilder.group({
      memberName: ['', Validators.compose([Validators.required, Validators.minLength(3), Validators.maxLength(20),Validators.pattern(/^[ A-Za-z]+$/)])],
      memberDesc: ['', Validators.compose([Validators.required,Validators.minLength(5)])],
      primaryPhoneNo: ['',Validators.compose([Validators.required,Validators.min(1000000000),Validators.pattern(/^[0-9]+$/)])],
      primaryMobileNo: ['', Validators.compose([Validators.required,Validators.min(1000000000),Validators.pattern(/^[0-9]+$/)])],
      primaryEmail: ['',Validators.compose([Validators.required, Validators.email])],
      legalAddress: ['', Validators.required],
      country: ['', Validators.required],
      state: ['', Validators.required],
      city: ['', Validators.required],
      bankUrl: ['', Validators.compose([Validators.required, Validators.pattern(/((([A-Za-z]{3,9}:(?:\/\/)?)(?:[-;:&=\+\$,\w]+@)?[A-Za-z0-9.-]+|(?:www.|[-;:&=\+\$,\w]+@)[A-Za-z0-9.-]+)((?:\/[\+~%\/.\w-_]*)?\??(?:[-\+=&;%@.\w_]*)#?(?:[\w]*))?)/)])],
      secondaryPhoneNo: ['',Validators.compose([Validators.min(1000000000),Validators.pattern(/^[0-9]+$/)])],
      secondaryMobileNo: ['',Validators.compose([Validators.min(1000000000),Validators.pattern(/^[0-9]+$/)])],
      secondaryEmail: ['', Validators.email],

      contactPerson: ['', Validators.compose([Validators.required,Validators.pattern(/^[ A-Za-z]+$/)])],
      designation: ['', Validators.compose([Validators.required,Validators.pattern(/^[ A-Za-z0-9]+$/)])],
      conEmail: ['', Validators.compose([Validators.required, Validators.email])],
      conPhone: ['',Validators.compose([Validators.required,Validators.min(1000000000),Validators.pattern(/^[0-9]+$/)])],
      conMobile: ['',Validators.compose([Validators.required,Validators.min(1000000000),Validators.pattern(/^[0-9]+$/)])],
      faxNumber: ['', Validators.compose([Validators.required,Validators.min(1000)])],
      addrType: ['', Validators.compose([Validators.required,Validators.pattern(/^[ A-Za-z]+$/), Validators.minLength(3)])],
      conLegalAddr: ['', Validators.required],
      conZipCode: ['',  Validators.compose([Validators.required,Validators.min(1000)])],
      constate: ['', Validators.required],
      conCity: ['', Validators.required],
      orgName: ['', Validators.compose([Validators.required,Validators.pattern(/^[ A-Za-z]+$/)])],
      //businessTypes: this.formBuilder.array([]),
      businessTypes: new FormArray([]),
    });
    //  this.onChangeAdd(1);
    this.addBusiness();
  }
  // convenience getters for easy access to form fields
  get f() {
    return this.dynamicForm.controls;
  }
  get b() {
    return this.f.businessTypes as FormArray;
  }
  get t() {
    return this.f.products as FormArray;
  }

  addBusiness() {
    let fg = this.formBuilder.group({
      businessType: ['', Validators.required],
      productName: ['', Validators.required],
      subProductName: ['', Validators.required],
      //products: this.formBuilder.array([]),
    });
    (<FormArray>this.dynamicForm.get('businessTypes')).push(fg);
    let userIndex =
      (<FormArray>this.dynamicForm.get('businessTypes')).length - 1;
    //this.addProducts(userIndex);
  }

  logValidationErrors(group: FormGroup = this.dynamicForm): void {

    Object.keys(group.controls).forEach((key: string) => {

      const abstractControl = group.get(key);
      this.formErrors[key] = '';
      if (abstractControl && !abstractControl.valid && (abstractControl.touched || abstractControl.dirty)) {
        const message = this.validationMessages[key];
        for (const err in abstractControl.errors) {
          if (err) {
            console.log('err , key ', err,key);
            this.formErrors[key] = message[err] + ' ';
          }
        }
      }
      if (abstractControl instanceof FormGroup) {
        this.logValidationErrors(abstractControl);
      }
    });
  }

  deleteBusiness(index: number) {
    (<FormArray>this.dynamicForm.get('businessTypes')).removeAt(index);
  }

  // addProducts(userIndex: number) {
  //   let fg = this.formBuilder.group({
  //     productName: ['', Validators.required],
  //     subProductName: ['', Validators.required],
  //   });
  //   (<FormArray>(
  //     (<FormGroup>(
  //       (<FormArray>this.dynamicForm.controls['businessTypes']).controls[
  //         userIndex
  //       ]
  //     )).controls['products']
  //   )).push(fg);
  // }

  // deleteProduct(userIndex: number, index: number) {
  //   //console.log('userIndex', userIndex, '-------', 'index', index);
  //   (<FormArray>(
  //     (<FormGroup>(
  //       (<FormArray>this.dynamicForm.controls['businessTypes']).controls[
  //         userIndex
  //       ]
  //     )).controls['products']
  //   )).removeAt(index);
  // }

  onChangeAdd(e) {
    //console.log("function",this.t);
    const numberOfProducts = e || 0;
    if (this.t.length < numberOfProducts) {
      for (let i = this.t.length; i < numberOfProducts; i++) {
        this.t.push(
          this.formBuilder.group({
            // name: ['', Validators.required],
            productName: ['', Validators.required],
          })
        );
        this.count = this.count + 1;
      }
    } else {
      for (let i = this.t.length; i >= numberOfProducts; i--) {
        this.t.removeAt(i);
      }
    }
  }
  addMore(number) {
    this.t.push(
      this.formBuilder.group({
        // name: ['', Validators.required],
        productName: ['', Validators.required],
      })
    );
  }
  onSubmit(form: FormGroup) {
    
    if (form.invalid) {
      form.markAllAsTouched()
      this.logValidationErrors();
      return;
    }

    this.submitted = true;
    //this.bankSave = form.value;
    this.address = {
      primaryPhoneNo: form.value['primaryPhoneNo'],

      primaryMobileNo: form.value['primaryMobileNo'],

      secondaryPhoneNo: form.value['secondaryPhoneNo'],

      secondaryMobileNo: form.value['secondaryMobileNo'],

      primaryEmail: form.value['primaryEmail'],

      secondaryEmail: form.value['secondaryEmail'],

      legalAddress: form.value['legalAddress'],

      conLegalAddr: form.value['conLegalAddr'],

      addrCity: form.value['city'],

      addrState: form.value['state'],

      addrCountry: form.value['country'],

      addrContactPerson: form.value['contactPerson'],

      conEmail: form.value['conEmail'],

      designation: form.value['contactDesignation'],

      mobileNo: form.value['conMobile'],

      contactNo: form.value['conPhone'],

      addrPin: form.value['conZipCode'],

      addrFax: form.value['faxNumber'],

      addressType: form.value['addrType'],
    };
    this.bankSave.address = this.address;
    this.bankSave.memberName = form.value['memberName'];
    this.bankSave.memberDesc = form.value['memberDesc'];
    this.bankSave.orgName = form.value['orgName'];
    this.bankSave.bankUrl = form.value['bankUrl'];
    this.bankSave.designation = form.value['designation'];
    this.bankSave.products = form.value['businessTypes'];
    
      this.service.saveBank(this.bankSave).subscribe((data) => {
        console.log("$$$$$$$$$$",data)
        if(data['statusCode']=="R113"){
          Swal.fire({
            imageUrl: 'assets/images/checked_icon.svg',
            text: 'Member has been saved successfully.',
          })
          this.router.navigate(['dashboard'])
        }
        else{
          Swal.fire({
            imageUrl: 'assets/images/warning.svg',
            text: data['statusDesc']
          })
        }
      
      },(error)=>{
        Swal.fire({
          imageUrl: 'assets/images/warning.svg',
          text: "Server Not Responding, Please Try Again Later."
        })
      });

  }
  reset() {
    this.dynamicForm.reset();
    // this.formInit();
    // Object.keys(this.dynamicForm.controls).forEach((key) => {
    //   this.dynamicForm.controls[key].setErrors(null);
    // });
    this.dynamicForm.markAsPristine();
    this.dynamicForm.markAsUntouched();
    this.dynamicForm.updateValueAndValidity();
    this.submitted = false;
  }

  passName(e, element, type) {
    e.preventDefault();
    this.nameEvent.emit({ name: element, type: type, category: 'bank' });
  }
  fetchProduct() {
    this.service.fetchProductList().subscribe((res) => {
      if(res['statusCode']=="R043"){
        this.productList = res['data'];

      }
    });
  }
  fetchSubProduct(index: number, product) {
    this.service.fetchSubProductList(product).subscribe((res) => {
      console.log("subproductttttttttttt",res);
      if(res['statusCode']=="R044"){
        this.toppingList.splice(index, 0, res['data'])

      }
      // this.toppingList.push(res['SubProduct DropDown']);
    });
  }
  fetchCountry() {
    this.service.fetchCountryList().subscribe((res) => {

      if(res['statusCode']=="R128"){
        this.countryList = res['data'];

      }
    });
  }
  fetchState(cntName: String) {
    this.dynamicForm.get('state').reset();
    this.service.fetchStateList(cntName).subscribe((res) => {
      console.log("stateeeeeeeeeee",res);
    
      if(res['statusCode']=="R157"){
        this.stateList = res['data'];

      }
    });
  }
  fetchCity(cntName: String, stateName: String) {
    // this.dynamicForm.get('city').reset();
    this.service.fetchCityList(cntName, stateName).subscribe((res) => {
      console.log("cityyyyyyyyy",res)
      statusDesc: "City Dropdown"
      if(res['statusCode']=="R150"){
        this.cityList = res['data'];

      }
    });
  }

  fetchConCity(cntName: String, stateName: String) {
    // this.dynamicForm.get('city').reset();
    this.service.fetchCityList(cntName, stateName).subscribe((res) => {
      console.log("cityyyyy222222222",res);
      if(res['statusCode']=="R150"){
        this.conCityList = res['data'];

      }
    });
  }
}
