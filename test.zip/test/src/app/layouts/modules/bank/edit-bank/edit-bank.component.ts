import { Component, OnInit,Output, EventEmitter,Input, ViewChild, ElementRef } from '@angular/core';
import {FormGroup, FormControl, Validators,FormBuilder, FormArray} from '@angular/forms';
import Swal from 'sweetalert2';
import { Router,ActivatedRoute} from '@angular/router';
import { BankService } from 'src/app/services/master/bank.service';
import { BankUpdate } from 'src/app/models/bank/bank-update';
import { Address } from 'src/app/models/address/address';

@Component({
  selector: 'app-edit-bank',
  templateUrl: './edit-bank.component.html',
  styleUrls: ['./edit-bank.component.css']
})
export class EditBankComponent implements OnInit {
  @Output() cancelEvent = new EventEmitter<any>();
  @Output() nameEvent = new EventEmitter<any>();
  @Output() selectNextEvent = new EventEmitter<any>();
  @Output() selectedTab = new EventEmitter<any>();
  @Input() userNameFromParent: any;
  dynamicForm: FormGroup;
  bankEditForm : FormGroup;
  bank;
  view;
  submitted = false;
  delete;
    // for delete all
    setdelete;
    deleteUser;
    bankSave: BankUpdate = new BankUpdate();
    address: Address;
    toppingList : String[] = [];
productList;
selectbusiness=['Issuer','Acquirer','Fintech','Both'];
 country ;
 state;
 city;
 memberId;
  subSelectedValue ;
//   
//  data =[
//    {businessType:'Issuer',products:[{productName:'product 1',subProduct:['sub product 2','Sub product1']}]},
//    {businessType:'Acquirer',products:[{productName:'product 2',subProduct:['Sub product1']}]}
//    ]
  constructor(private formBuilder: FormBuilder,private route :ActivatedRoute,private router : Router,private service : BankService) { }

  ngOnInit(): void {
    this.view = localStorage.getItem('vf');
   
    this.fetchProduct()
   
    // for delete all
    this.setdelete = this.route.snapshot.params.setDelete;
    this.deleteUser=this.route.snapshot.params.user;

    //  console.log("user object",this.userNameFromParent);
    //  console.log("user",JSON.parse(this.userNameFromParent).memberName);
    // console.log("user object type",JSON.parse(this.userNameFromParent).type);
    console.log("uuuuuuuuuuuuuuuuuuu",this.userNameFromParent)
    if(JSON.parse(this.userNameFromParent).type){
       this.bank =JSON.parse(this.userNameFromParent).memberName;
       this.delete=true;
    }else{
      this.bank =JSON.parse(this.userNameFromParent);
      this.delete=false;
    }

 this.memberId = this.bank.memberId;
 this.formInit();
  }
formInit(){
    //console.log("user name from parent",JSON.parse(this.userNameFromParent));
   if(JSON.parse(this.userNameFromParent).type){
       this.bank =JSON.parse(this.userNameFromParent).memberName;
       console.log("user",JSON.parse(this.userNameFromParent).parameters.memberName);
    }else{
      this.bank =JSON.parse(this.userNameFromParent);
    }
    this.country = this.bank.address.addrCountry ? this.bank.address.addrCountry.split() : '';
    this.state = this.bank.address.addrState ? this.bank.address.addrState.split() : '';
    this.city = this.bank.address.addrCity ? this.bank.address.addrCity.split() : '';
    //this.fetchSubProduct(this.bank.)
    this.dynamicForm = this.formBuilder.group({
      memberName: [this.bank.memberName , Validators.required],
      memberDesc:[this.bank.memberDesc , Validators.required],
      primaryphoneNumber:[this.bank.address.primaryPhoneNo , Validators.required],
      primaryMobNumber:[this.bank.address.primaryMobileNo , Validators.required],
      primaryEmail:[this.bank.address.primaryEmail , Validators.required],
      legalAddress:[this.bank.address.legalAddress , Validators.required],
      country:[this.bank.address.addrCountry, Validators.required],
      state:[this.bank.address.addrState, Validators.required],
      city:[this.bank.address.addrCity, Validators.required],
      website:[this.bank.bankUrl, Validators.required],
      secphoneNumber:[this.bank.address.secondaryPhoneNo],
      secMobNumber:[this.bank.address.secondaryMobileNo],
      secEmail:[this.bank.address.secondaryEmail],

      contactPerson:[this.bank.address.addrContactPerson,Validators.required],
      contactDesignation:[this.bank.designation,Validators.required],
      conEmail:[this.bank.address.conEmail,Validators.required],
      conPhone:[this.bank.address.contactNo,Validators.required],
      conMobile:[this.bank.address.mobileNo,Validators.required],
      faxNumber:[this.bank.address.addrFax,Validators.required],
      addrType:[this.bank.address.addressType,Validators.required],
      conLegalAddr:[this.bank.address.conLegalAddr,Validators.required],
      conZipCode:[this.bank.address.addrPin,Validators.required],
      constate:[this.bank.address.addrState,Validators.required],
      conCity:[this.bank.address.addrCity,Validators.required],
      orgName:[this.bank.orgName, Validators.required],
      businessTypes:this.formBuilder.array([])
      //products: new FormArray([])
   });
   //this.onChangeAdd(1);

    this.addBusiness(this.bank.products);
  }

  addNewBusiness() {
    let fg = this.formBuilder.group({
      businessType: ['', Validators.required],
      productName: ['', Validators.required],
      subProductName: ['', Validators.required],
      //products: this.formBuilder.array([]),
    });
    (<FormArray>this.dynamicForm.get('businessTypes')).push(fg);
    let userIndex =
      (<FormArray>this.dynamicForm.get('businessTypes')).length - 1;
    console.log('userIndex', userIndex);
    //this.addProducts(userIndex);
  }

  fetchProduct() {
    this.service.fetchProductList().subscribe((res) => {
      if(res['statusCode']=="R043"){
        this.productList = res['data'];

      }
    });
  }

  fetchSubProduct(index : number, product) {
    // if(this.productList)
    // {
    //   let id = this.productList.filter(i  => i.productName == product)[0].productId
    //   this.service.fetchSubProductList(id).subscribe((res) => {t
    //     this.toppingList = res['SubProduct DropDown'];
    //   });
    // }
    // else
    // {
      this.service.fetchSubProductList(product).subscribe((res) => {
        if(res['statusCode']=="R044"){
          this.toppingList.splice(index, 0, res['data'])

        }
      });
}
  
   // convenience getters for easy access to form fields
   get f() { return this.dynamicForm.controls; }

   get t() { return this.f.products as FormArray; }

   getProductNumber(e) {
    //console.log("function",this.t);
    const numberOfProducts = e || 0;
    if (this.t.length < numberOfProducts) {
        for (let i = this.t.length; i < numberOfProducts; i++) {
            this.t.push(this.formBuilder.group({
              // name: ['', Validators.required],
              productName: ['', Validators.required],
            }));
        }
    } else {
        for (let i = this.t.length; i >= numberOfProducts; i--) {
            this.t.removeAt(i);
        }
    }
}
addMore(number){
  this.t.push(this.formBuilder.group({
    // name: ['', Validators.required],
    productName: ['', Validators.required],
  }));
}

addBusiness(data){
  
  for(let i=0;i < data.length;i++){
    
    this.fetchSubProduct(i, +data[i].productName)
    //console.log("data[i].productName sub product  ", JSON.parse("[" +data[i].subProductName+ "]"));
     let fg = this.formBuilder.group({
             businessType: [data[i].businessType, Validators.required],
             productName: [+data[i].productName, Validators.required],
             subProductName: [JSON.parse("[" +data[i].subProductName+ "]"), Validators.required]
             //products: this.formBuilder.array([]),
        });
 
  (<FormArray>this.dynamicForm.get('businessTypes')).push(fg);
  // (<FormArray>this.dynamicForm.get('productName')).push(fg);
  // (<FormArray>this.dynamicForm.get('subProduct')).push(fg);
 // this.addProducts(i);
  }

}
deleteBusiness(index: number) {
        (<FormArray>this.dynamicForm.get('businessTypes')).removeAt(index);
    }

addProducts(prodNumber:number){
  // console.log("length ",prodNumber)
    //console.log("subProduct",this.data[userIndex].products[j].subProduct);
  // for(let j=0;j< prodNumber;j++){
    //console.log("product name",this.bank.products[prodNumber].subProductName);
    let fg = this.formBuilder.group({
             'businessType': [this.bank.products[prodNumber].businessType, Validators.required],
            'productName': [this.bank.products[prodNumber].productName, Validators.required],
            'subProductName': [this.bank.products[prodNumber].subProductName, Validators.required]
        });
        (<FormArray>this.dynamicForm.get('businessTypes')).push(fg);
  // }
}

deleteProduct(userIndex: number) {
        //console.log('userIndex', userIndex, '-------', 'index', index);
        // (<FormArray>(<FormGroup>(<FormArray>this.dynamicForm.controls['businessTypes']).controls[userIndex]).controls['products']).removeAt(index);
        (<FormArray>this.dynamicForm.controls['businessTypes']).removeAt(userIndex);
    }

  onSubmit(form: FormGroup) {
    this.submitted = true;
    console.log("form value",form.value);
    this.address = {
      primaryPhoneNo: form.value['primaryphoneNumber'],

      primaryMobileNo: form.value['primaryMobNumber'],

      secondaryPhoneNo: form.value['secphoneNumber'],

      secondaryMobileNo: form.value['secMobNumber'],

      primaryEmail: form.value['primaryEmail'],

      secondaryEmail: form.value['secEmail'],

      legalAddress: form.value['legalAddress'],

      conLegalAddr : form.value['conLegalAddr'],

      addrCity: form.value['city'],

      addrState: form.value['state'],

      addrCountry: form.value['country'],

      addrContactPerson: form.value['contactPerson'],

      conEmail : form.value['conEmail'],

      designation : form.value['contactDesignation'],

      mobileNo: form.value['conMobile'],

      contactNo: form.value['conPhone'],

      addrPin: form.value['conZipCode'],

      addrFax: form.value['faxNumber'],

      addressType: form.value['addrType'],
    };
    this.bankSave.address = this.address;
    this.bankSave.memberId = this.memberId
    this.bankSave.memberName = form.value['memberName'];
    this.bankSave.memberDesc = form.value['memberDesc'];
    this.bankSave.orgName = form.value['orgName'];
    this.bankSave.bankUrl = form.value['website'];
    this.bankSave.designation = form.value['contactDesignation'];
    this.bankSave.products = form.value['businessTypes'];
    console.log('Bank Update, ', this.bankSave)
    this.service.updateBank(this.bankSave).subscribe((data) => {
      console.log("444111111",data)
      if(data['statusCode']=="R114"){
        Swal.fire({
          text: 'Business type and product name have been updated successfully.',
          imageUrl: 'assets/images/checked_icon.svg',
        });
          this.router.navigate(['dashboard'])
      }
      else{
        Swal.fire({
          imageUrl: 'assets/images/warning.svg',
          text: data['statusDesc']
        })
      }
     
    },(error)=>{
      Swal.fire({
        imageUrl: 'assets/images/warning.svg',
        text:"Server Not Responding, Please Try Again Later."
      })
    });
  }

  cancel(){
    this.cancelEvent.emit({name:" ",type:"cancel",category:'bank'});
  }
   //delete data
  deleteData(e){
    //let val = value;
    e.preventDefault();

    Swal.fire({
      imageUrl:'assets/images/checked_icon.svg',
      text:this.bank + 'Issuer products has been deleted successfully.',
      confirmButtonText:'ok',
    });
     this.nameEvent.emit({name:this.bank,type:'viewbank',category:'bank'});
  }

  passName(e,element,type){
    e.preventDefault();
    this.nameEvent.emit({name:element,type:type,category:'bank'});
  }
  selected(){
    this.selectNextEvent.emit('1');
  }
  // for delete all

  removeField(name){
    // this.removedvalues.push(name);
    delete this.f[name];
    //console.log("fremove controls",this.removedvalues);
   }

   deleteMsg(){
     Swal.fire({
       imageUrl:'assets/images/checked_icon.svg',
       title:'Member and related all masters/data have been deleted successfully.'
     }).then((result) => {
       if(result.isConfirmed){
         this.nameEvent.emit({name:'',type:'viewBank',category:'bank'});
         this.router.navigate(['/dashboard/']);
       }
     });
   }
   cancelDelete(){
     //console.log("clicked");
     this.selectedTab.emit(true);
     this.router.navigate(['/dashboard/']);
   }
}
