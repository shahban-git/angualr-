import { Component, OnInit ,ViewChild, Output, EventEmitter} from '@angular/core';
import { MatTableDataSource} from '@angular/material/table';
import {MatPaginator} from '@angular/material/paginator';
import {PageEvent} from '@angular/material/paginator';
import { Router } from '@angular/router';
import { BankService } from 'src/app/services/master/bank.service';
import { BankView } from 'src/app/models/bank/bank-view';
import { LoginService } from 'src/app/services/subscribe/login.service';
import { FilterModel } from 'src/app/models/filter';
import { FormControl, FormGroup } from '@angular/forms';
import { BankUpdate } from 'src/app/models/bank/bank-update';



@Component({
  selector: 'app-view-bank',
  templateUrl: './view-bank.component.html',
  styleUrls: ['./view-bank.component.css']
})
export class ViewBankComponent implements OnInit {
  @Output() nameEvent = new EventEmitter<any>();
  @ViewChild('paginator') paginator: MatPaginator;
  crudPriv : number;
  displayedColumns: string[] = [ 'member name', 'products', 'date','status','action'];
  dataSource :  MatTableDataSource<BankView>;
  totalCount: number;
  filterModel: FilterModel = new FilterModel();
   bankUpdate : BankUpdate;
   viewBankMes
  //@ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  constructor(private service: BankService) {
    this.filterModel = {
      name : '',
      page: 0,
      size: 5
    };
  }

  ngOnInit(): void {
    this.crudPriv = +localStorage.getItem('cdPms');
    this.refreshBankList(this.filterModel);
  }

  passName(e,element,type){
    e.preventDefault();
    this.fetchMember(element)
    setTimeout(() => {
    this.nameEvent.emit({name:this.bankUpdate,type:type,category:'bank'});
    },2000)
  }

  fetchMember(element)
  {
    this.service.fetchBankById(element).subscribe(data => {
      console.log("ttttttttttttttttttttt",data);
statusDesc: "Bank By Id"

      if(data['statusCode']=="R117"){

      }
      this.bankUpdate = data['data']
      console.log("Fetch Products  " , this.bankUpdate);
    });
  }

  paginatorClick(pageNum: Number) {
    this.filterModel.page = pageNum['pageIndex'];
    this.filterModel.size = pageNum['pageSize'];
    this.refreshBankList(this.filterModel);
  }
  refreshBankList(pageParams)
 {
    this.service.getBankList(pageParams).subscribe(data => {
      console.log("ggggggggggggggggggg",data);
   
      if(data['statusCode']=="R112"){
        if(data['data']['content'].length>0){
          this.dataSource = new MatTableDataSource(data["data"]["content"]);
          this.totalCount = data["data"]['totalElements']
        }
        else{
          this.dataSource=null;
          this.viewBankMes="No Records Found"
        }
      }
      else{
        this.dataSource=null;
        this.viewBankMes=data['statusDesc']
      }
    
      //this.dataSource.paginator = this.paginator;
    },(error)=>{
      this.dataSource=null;
      this.viewBankMes="Server Not Responding, Please Try Again Later."
    });
 }

 onSearch(event: Event) {
  this.paginator.firstPage();
  this.filterModel.name = (event.target as HTMLInputElement).value
  this.filterModel.page = 0;
  this.filterModel.size = 5;
  this.refreshBankList(this.filterModel);

}

}

