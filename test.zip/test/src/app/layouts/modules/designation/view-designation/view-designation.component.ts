import { Component, OnInit ,ViewChild, Output, EventEmitter} from '@angular/core';
import { MatTableDataSource} from '@angular/material/table';
import {MatPaginator} from '@angular/material/paginator';
import { BankView } from 'src/app/models/bank/bank-view';
import { DesignationService } from 'src/app/services/master/designation.service';
import { FilterModel } from 'src/app/models/filter';

@Component({
  selector: 'app-view-designation',
  templateUrl: './view-designation.component.html',
  styleUrls: ['./view-designation.component.css']
})
export class ViewDesignationComponent implements OnInit {
  @Output() nameEvent = new EventEmitter<any>();
  crudPriv: number;
  totalCount: number;
  designationMes;
  filterModel: FilterModel = new FilterModel();
  displayedColumns: string[] = [ 'member name', 'designations', 'create date','status','action'];
  dataSource : MatTableDataSource<BankView>;
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;

  constructor(private service: DesignationService) {
    this.filterModel = {
      name : '',
      page: 0,
      size: 5
    };
   }

  ngOnInit(): void {
    this.crudPriv = +localStorage.getItem('cdPms');
    this.refreshDesigList(this.filterModel);
  }
  passName(e,element,type){
    e.preventDefault();
    this.nameEvent.emit({name:element,type:type,category:'designation'});
  }
  refreshDesigList(pageParams) {
    this.service.getDesigList(pageParams).subscribe((data) => {
      console.log("designationssssssssssssssssssss",data);
      if(data['statusCode']=="R065"){
        if(data['data']['content'].length>0){
          this.dataSource = new MatTableDataSource(data['data']['content']);
          this.totalCount = data["data"]['totalElements']
        }
        else{
          this.dataSource=null;
          this.designationMes="No Records Found."
        }
      }
      else{
        this.dataSource=null;
        this.designationMes=data['statusDesc']
      }
    
      //this.dataSource.paginator = this.paginator;
    },(error)=>{
      this.dataSource=null;
        this.designationMes="Server Not Responding, Please Try Again Later."
    });
  }
  paginatorClick(pageNum: Number) {
    this.filterModel.page = pageNum['pageIndex'];
    this.filterModel.size = pageNum['pageSize'];
    this.refreshDesigList(this.filterModel);

  }

  onSearch(event: Event) {
    this.paginator.firstPage();
    this.filterModel.name = (event.target as HTMLInputElement).value
    this.filterModel.page = 0;
    this.filterModel.size = 5;
    this.refreshDesigList(this.filterModel);
  
  }
}
