import { Component, OnInit ,Input,ViewChild, Output, EventEmitter} from '@angular/core';
import { MatTableDataSource} from '@angular/material/table';
import {MatPaginator} from '@angular/material/paginator';
import { DesignationView } from 'src/app/models/designation/designation-view';
import { DesignationService } from 'src/app/services/master/designation.service';
import { FilterModel } from 'src/app/models/filter';

@Component({
  selector: 'app-bank-designation',
  templateUrl: './bank-designation.component.html',
  styleUrls: ['./bank-designation.component.css']
})
export class BankDesignationComponent implements OnInit {
  @Output() nameEvent = new EventEmitter<any>();
  @Input() userNameFromParent;
  crudPriv : number;
  totalCount: number;
  designationDetailMes;
  filterModel: FilterModel = new FilterModel();
  displayedColumns: string[] = [ 'member name', 'Designations', 'create date','status'];
  dataSource :  MatTableDataSource<DesignationView>;
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  constructor(private service : DesignationService) {
    this.filterModel = {
      name : '',
      page: 0,
      size: 5
    };
  }

  ngOnInit(): void {
    this.crudPriv = +localStorage.getItem('cdPms');
    this.userNameFromParent = JSON.parse(this.userNameFromParent);
    this.getDesigView(this.userNameFromParent, this.filterModel);
  }
  back(){
    this.nameEvent.emit({name:"",type:"",category:'designation'});
  }
  getDesigView(bankName : string, pageParams)
  {
    this.service.viewSubListDesig(bankName.trim(), pageParams).subscribe(
      data => {
        console.log("kkkkkkkkkkkkkkkkk",data);
        if(data['statusCode']=="R075"){
          if(data["data"]['content'].length>0){
            this.dataSource = new MatTableDataSource(data["data"]['content']);
            this.totalCount = data["data"]['totalElements']
          }
          else{
            this.dataSource=null;
            this.designationDetailMes="No Records Found."
          }
        }
        else{
          this.dataSource=null;
          this.designationDetailMes=data['statusDesc']
        }
      
        //this.dataSource.paginator = this.paginator;
      },(error)=>{
        this.dataSource=null;
        this.designationDetailMes="Server Not Responding, Please Try Again Later."
      }
    )
  }
  paginatorClick(pageNum: Number) {
    this.filterModel.page = pageNum['pageIndex'];
    this.filterModel.size = pageNum['pageSize'];
    this.getDesigView(this.userNameFromParent, this.filterModel);

  }

  onSearch(event: Event) {
    this.paginator.firstPage();
    this.filterModel.name = (event.target as HTMLInputElement).value
    this.filterModel.page = 0;
    this.filterModel.size = 5;
    this.getDesigView(this.userNameFromParent, this.filterModel);
  
  }

}
