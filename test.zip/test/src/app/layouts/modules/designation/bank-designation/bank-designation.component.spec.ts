import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BankDesignationComponent } from './bank-designation.component';

describe('BankDesignationComponent', () => {
  let component: BankDesignationComponent;
  let fixture: ComponentFixture<BankDesignationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BankDesignationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BankDesignationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
