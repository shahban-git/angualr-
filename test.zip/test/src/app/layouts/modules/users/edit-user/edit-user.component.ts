import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder, FormArray } from '@angular/forms';
import { Router } from '@angular/router';
import { UserCreate } from 'src/app/models/user/user-create';
import { UserView } from 'src/app/models/user/userView';
import { UserService } from 'src/app/services/user.service';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {
  @Output() cancelEvent = new EventEmitter<any>();
  @Input() userNameFromParent;
  user: UserCreate = new UserCreate();
  editUserForm: FormGroup;
  deptList ;
  desigList ;
  roleList
  submitted = false;
  bankName;
  branchName;
  userId;
  zoneList: any;
  regionList: any;
  bankId: number;
  roleId: number;

  constructor(private formBuilder: FormBuilder, private service: UserService, private router : Router) {

  }


  ngOnInit(): void {
    this.user = JSON.parse(this.userNameFromParent);
    console.log('In NGINITyyyyyyyyyyyyyyyyyyy ' , this.user)
    this.bankId=this.user.userBank.bankId;
    this.roleId =JSON.parse(this.userNameFromParent).userRoleId.roleId;
    this.fetchRole(this.bankId)
    this.fetchDeptList(this.user.userBank.bankId);
    this.fetchDesigList(this.user.userBank.bankId);
    this.fetchZone(this.user.userBank.bankId);
    this.fetchRegion(this.user.userBank.bankId,this.user.userZone);
    this.bankName = this.user.userBankName;
    this.branchName = this.user.userBranchName;
    this.userId = JSON.parse(this.userNameFromParent).userId;
    this.editUserForm = this.formBuilder.group({
      userBank: [this.user.userBankName, Validators.required],
      userBranchName: [this.user.userBranchName, Validators.required],
      userName: [this.user.userName, Validators.required],
      userPhone: [this.user.userPhone, Validators.required],
      userEmail: [this.user.userEmail, Validators.required],
      userFromDate: [this.user.userValidFrom ? new Date(this.user.userValidFrom) : '', Validators.required],
      userToDate: [this.user.userValidTo ? new Date(this.user.userValidTo) : '', Validators.required],
      userStatus: [this.user.userStatus, Validators.required],
      userDepartment: [this.user.userDepartmentId, Validators.required],
      userDesignation: [this.user.userDesignationId, Validators.required],
      reportingOfficer: [this.user.reportingOfficer, Validators.required],
      isMask: [this.user.isMask],
      userZone: [this.user.userZone, Validators.required],
      userRegion: [this.user.userRegion, Validators.required],
      userLock: [this.user.userLock],
      userRole:[this.user['userRoleId'].roleId]
    });
  }
  // convenience getters for easy access to form fields
  get f() { return this.editUserForm.controls; }
  onSubmit(form: FormGroup) {
    this.submitted = true;
    this.user = form.value
    this.user.userBank = {
      bankId : this.bankId
    }
    console.log(this.user)
    this.user.userRole = {
      roleId : this.roleId
    }

   
    
    this.user.userId = this.userId
    console.log('USer 1 ' + JSON.stringify(this.user))
    this.service.updateUser(this.user).subscribe(res => {
      console.log("&&&&&&&&&&&&&",res)
      Swal.fire({
        imageUrl : 'assets/images/checked_icon.svg',
        text: 'User has been saves successfully'
      })

      this.router.navigate(['dashboard'])
      // form.reset();
    });
  }

  fetchRole(bankId: number) {
    this.service.fetchRoleList(bankId).subscribe(res => {
      if(res['statusCode']=="R024"){
          this.roleList = res['data']['roles'];

        
      }
    });
  }

  cancel() {
    this.cancelEvent.emit({ name: {bankName : this.bankName, branchName : this.branchName}, type: "cancel", category: 'user' });
  }

  fetchDeptList(bankId : number)
  {
    this.service.fetchDeptList(bankId).subscribe(res => {
      // this.deptList = res['Department DropDown'];
      if(res['statusCode']=="R060"){
        this.deptList = res['data'];

      
    }
    });
  }
  fetchStatus
  = [
   {value: 'ACTV', viewValue: 'ACTV'},
   {value: 'NA', viewValue: 'NA'},
 ];
  fetchDesigList(bankId : number)
  {
    this.service.fetchDesigList(bankId).subscribe(res => {
      if(res['statusCode']=="R074"){
        this.desigList = res['data'];
      }
    });
  }

  fetchZone(bankId) { 
    this.service.fetchZoneList(bankId).subscribe((res) => {
      console.log("zoneeeeeeeeeeeeeeeee",res['data']);
      if(res['statusCode']=="R096"){
        this.zoneList = res['data'];

      }
    });
  }

  getRegion(zoneId) {
    this.fetchRegion(this.user.userBank.bankId,zoneId)
  }

  fetchRegion(bankId,zoneId) { 
    // console.log("zoneiddddddddddd",zoneId)

    this.service.fetchRegionList(bankId,zoneId).subscribe((res) => {
      console.log(res);
      if(res['statusCode']=="R087"){
        this.regionList = res['data'];

      }
    });
  }
}
