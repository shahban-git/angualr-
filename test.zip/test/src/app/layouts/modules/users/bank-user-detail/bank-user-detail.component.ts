import { Component, OnInit ,Input,ViewChild, Output, EventEmitter} from '@angular/core';
import { MatTableDataSource} from '@angular/material/table';
import {MatPaginator} from '@angular/material/paginator';
import { UserService } from 'src/app/services/user.service';
import { UserView } from 'src/app/models/user/userView';
import { UserCreate } from 'src/app/models/user/user-create';
import { FilterModel } from 'src/app/models/filter';

@Component({
  selector: 'app-bank-user-detail',
  templateUrl: './bank-user-detail.component.html',
  styleUrls: ['./bank-user-detail.component.css']
})

export class BankUserDetailComponent implements OnInit {
  @Output() nameEvent = new EventEmitter<any>();
  @Input() userNameFromParent ;
  crudPriv : number;
  isAdmin : Number;
  user : UserCreate;
  usersMes
  bankName;
  displayedColumns: string[] = [ 'member name', 'user_name', 'branch_name','create_date','status'];
  dataSource : MatTableDataSource<UserView>;
  filterModel: FilterModel = new FilterModel();
  totalCount: number;
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;

  constructor(private service : UserService) {
    this.filterModel = {
      name : '',
      page: 0,
      size: 5
    }
  }

  ngOnInit(): void {
    this.userNameFromParent = JSON.parse(this.userNameFromParent);
console.log("fromparenttttttttttt",this.userNameFromParent)
   this.crudPriv = +localStorage.getItem('cdPms');
    this.isAdmin = +localStorage.getItem('vf');

    if(this.isAdmin == 1)
    {
      this.userList(this.userNameFromParent,  this.filterModel);    }
    else
    {
      this.userList(this.userNameFromParent,  this.filterModel);    }
    
  }

  passName(e,element,type){
    e.preventDefault();
    this.fetchUser(element)
    setTimeout(() => {
      this.nameEvent.emit({name:this.user,type:type,category:'user'});
    }, 2000)

  }
  back(){
    this.nameEvent.emit({name:"",type:"",category:'user'});
  }

  userList(bankId,  pageParams) {
   
    if(this.isAdmin == 0){
      bankId=bankId.bankName
    } 
    this.service.viewSubListUsers(bankId,pageParams).subscribe(data => {
      console.log("vvvvvvvvvvvvvvv",data);
      if(data['statusCode']=="R012"){
        if(data['data']['content'].length>0){
          this.dataSource = new MatTableDataSource(data['data']['content']);
          this.totalCount = data["data"]['totalElements']
        }
        else{
          this.dataSource=null;
          this.usersMes="No Records Found."
        }
      }
      else{
        this.dataSource=null;
          this.usersMes=data['statusDesc']
      }
    
     //this.dataSource.paginator = this.paginator;
   },(error)=>{
    this.dataSource=null;
    this.usersMes="Server NotResponding, Please Try Again Later."
   });
 }
  fetchUser(element)  {
      this.service.getUserById(element.userId).subscribe(data => {
        console.log("trewqfgfgfgff",data,element,this.user)
      this.user = data['data'];
      this.user.userBranchName = element.branchName
      this.user.userBank = data['data']['userBankId']
    });
  }
  paginatorClick(pageNum: Number) {
    this.filterModel.page = pageNum['pageIndex'];
    this.filterModel.size = pageNum['pageSize'];
    this.userList(this.userNameFromParent, this.filterModel);

  }

  onSearch(event: Event) {
    this.paginator.firstPage();
    this.filterModel.name = (event.target as HTMLInputElement).value
    this.filterModel.page = 0;
    this.filterModel.size = 5;
    this.userList(this.userNameFromParent,  this.filterModel);
  
  }
}
