import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { BankUpdate } from 'src/app/models/bank/bank-update';
import { UserCreate } from 'src/app/models/user/user-create';
import { UserService } from 'src/app/services/user.service';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {
  @ViewChild('UploadFileInput', { static: false }) uploadFileInput: ElementRef;
  fileUploadForm: FormGroup;
  fileInputLabel: string;
  addUserForm: FormGroup;
  fileError = false;
  disabled = true;
  fileLabel;
  userAddFlag:boolean=false
  submitted = false;
  bankList: BankUpdate;
  branchList: any;
  deptList: any;
  desigList: any;
  roleList: any;
  zoneList: any;
  regionList: any;
  user: UserCreate = new UserCreate()

  formErrors = {
    'userBank': '',
    'userBranch': '',
    'userDepartment': '',
    'userDesignation': '',
    'userRole': '',
    'userEmployeeId': '',
    'userName': '',
    'userFirstName': '',
    'userPhone': '',
    'userEmail': '',
    'userFromDate': '',
    'userToDate': '',
    'userStatus': '',
    'reportingOfficer': '',
    'userZone': '',
    'userRegion': '',


  }

  validationMessages = {
    'userBank': { 'required': 'Bank is required' },
    'userBranch': { 'required': 'Branch is required' },
    'userZone': { 'required': 'Zone is required' },
    'userRegion': { 'required': 'Region is required' },
    'userDepartment': { 'required': 'Department is required' },
    'userDesignation': { 'required': 'Designation is required' },
    'userRole': { 'required': 'Role is required' },
    'userEmployeeId': { 'required': 'Employee ID is required' },
    'userName': { 'required': 'User Name is required', 'minlength': 'Minimum Length 5 required', 'pattern': 'Special characters not allowed' },
    'userFirstName': { 'required': 'First Name is required', 'minlength': 'Minimum Length 3 required', 'pattern': 'Special characters and Digits not allowed' },
    'userPhone': { 'required': 'Mobile Number is required',
     'min': 'Phone Number is invalid', 'pattern':'Only Numbers Allowed' },
    'userEmail': { 'required': 'Email is required', 'email': 'Invalid email format' },
    'userFromDate': { 'required': 'From Date is required' ,'lessThenProperty':'Form Date Must Be Less Than To Date'},
    'userToDate': { 'required': 'To Date is required' },
    'userStatus': { 'required': 'User Status is required' },
    'reportingOfficer': {  'minlength': 'Minimum Length 3 required', 'pattern': 'Special characters and Digits not allowed' }
    

  }
  bankId: number;
  entityId;

  constructor(private service: UserService, private formBuilder: FormBuilder,
     private router: Router) { }
  single = true;
 
  ngOnInit(): void {
    this.entityId = localStorage.getItem('entityId');
    this.addUserForm = this.formBuilder.group({
      userBank: [this.user.userBank, Validators.required],
      userBranch: [this.user.userBranch, Validators.required],
      userZone: [this.user.userZone],
      userRegion: [this.user.userRegion],
      userDepartment: [this.user.userDepartmentId, Validators.required],
      userDesignation: [this.user.userDesignationId, Validators.required],
      userRole: [ this.user.userRole, Validators.required],
      userEmployeeId: [this.user.userEmployeeId, Validators.required],
      userName: [this.user.userName, Validators.compose([Validators.required, Validators.minLength(5), Validators.pattern(/^[ A-Za-z0-9]+$/)])],
      userFirstName: [this.user.userFirstName, Validators.compose([Validators.required, Validators.minLength(3), Validators.pattern(/^[ A-Za-z]+$/)])],
      userPhone: [this.user.userPhone, Validators.compose([Validators.required, Validators.min(1000000000),Validators.pattern(/^[0-9]+$/)])],
      userEmail: [this.user.userEmail, Validators.compose([Validators.required, Validators.email])],
      userFromDate: [this.user.userFromDate, Validators.required],
      userToDate: [this.user.userToDate, Validators.required],
      userStatus: [this.user.userStatus, Validators.required],
      reportingOfficer: [this.user.reportingOfficer, Validators.compose([ Validators.minLength(3), Validators.pattern(/^[ A-Za-z]+$/)])],
      isMask: [this.user.isMask],
      userEntity: [+this.entityId],
    });

    this.fileUploadForm = this.formBuilder.group({
      myfile: ['']
    });

    this.fetchBank();
    //this.fetchRole();
    this.addUserForm.valueChanges.subscribe(data => {
      this.logValidationErrors(this.addUserForm);
    })
  }

  logValidationErrors(group: FormGroup = this.addUserForm): void {

    Object.keys(group.controls).forEach((key: string) => {

      const abstractControl = group.get(key);
      this.formErrors[key] = '';
      if (abstractControl && !abstractControl.valid && (abstractControl.touched || abstractControl.dirty)) {
        const message = this.validationMessages[key];
        for (const err in abstractControl.errors) {
          if (err) {
            this.formErrors[key] = message[err] + ' ';
          }
        }
      }
      if (abstractControl instanceof FormGroup) {
        this.logValidationErrors(abstractControl);
      }
    });
  }

  onChange(event) {
    if (event.value === '2') {
      this.single = false;
    } else {
      this.single = true;
    }
  }
  get f() { return this.addUserForm.controls; }

  // file validation
  onFileSelect(event) {
    this.fileError = false;
    const af = ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/vnd.ms-excel'];
    let filename = event.target.files[0];
    this.fileLabel = filename.name;
    let fileType = this.getExt(event.target.files[0].name);
    let file = event.target.files[0].name;
    if (event.target.files[0].size < 0 && event.target.files[0].size > 20480) {
      this.fileError = true;
      this.disabled = true;
    }
    else if (fileType !== 'xlsx') {
      this.fileError = true;
      this.disabled = true;
    }
    else {
      this.fileUploadForm.get('myfile').setValue(file);
      this.fileError = false;
      this.disabled = false;
    }

  }
  getExt(filepath) {
    return filepath.split('.').pop();
  }
  // onFormSubmit() {}

  onDateChange(event){
    if (this.formatting_Date( this.addUserForm.controls['userFromDate'], "ddmmyyyy") > 
    this.formatting_Date( this.addUserForm.controls['userToDate'], "ddmmyyyy")) {
      console.log("lesssssssssssssss")
      this.addUserForm.controls['userFromDate'].setErrors({ 'lessThenProperty': true })

    }
    else {
      console.log("greateeeeeee")
      this.addUserForm.controls['userFromDate'].setErrors(null)
    }
  }

  onSubmit(form: FormGroup) {

    if (form.invalid) {
      form.markAllAsTouched()
      this.logValidationErrors();
      return;
    }
    // if (this.formatting_Date( this.addUserForm.controls['userFromDate'], "ddmmyyyy") > 
    // this.formatting_Date( this.addUserForm.controls['userToDate'], "ddmmyyyy")) {
    //   console.log("lesssssssssssssss")
    //   this.addUserForm.controls['userFromDate'].setErrors({ 'lessThenProperty': true })

    // }
    // else {
    //   console.log("greateeeeeee")
    //   this.addUserForm.controls['userFromDate'].setErrors(null)
    // }
    this.userAddFlag=true
    this.submitted = true;
    this.user = form.value
    this.user.userBank = {
      bankId: form.value['userBank']
    }
    this.user.userRole = {
      roleId: form.value['userRole']
    }
    this.service.createUser(this.user).subscribe(res => {
      this.userAddFlag=false
      if (res['statusCode']=="R007") {
        Swal.fire({
          imageUrl: 'assets/images/checked_icon.svg',
          text: 'User has been saved successfully'
        })
        this.router.navigate(['dashboard'])

        

      } 
      else {
        Swal.fire({
          imageUrl: 'assets/images/warning.svg',
          text: res['statusDesc']
        })

      }

      // form.reset();
    },(error)=>{
      Swal.fire({
        imageUrl: 'assets/images/warning.svg',
        text: "Server Not Responding, Please Try Again Later."
      })
    });
  }
  onFormSubmit(form: FormGroup) {
  }

  fetchBank() {
    this.service.fetchBankList().subscribe(res => {
      // this.bankList = res['data']['Bank DropDown'];
      if(res['statusCode']=="R112"){
      this.bankList = res['data'];

      }

    });
  }

  formatting_Date(date, format): string {
    let eventDate = new Date(date.value);
    console.log("dateeeeeeeeeeeee",eventDate)
    let Zeroappended_month = this.appendLeadingZero((eventDate.getMonth() + 1));
    let Zeroappended_Date = this.appendLeadingZero(eventDate.getDate());
    console.log("zerooooooooo",Zeroappended_month,Zeroappended_Date)
    if (format == "ddmmyyyy") {
      let newDate = Zeroappended_Date + "-" + Zeroappended_month + "-" + eventDate.getFullYear();
      console.log("dateeeeeeeeee",newDate)
      return newDate;
    }
    else {
      let newDate = eventDate.getFullYear() + "-" + Zeroappended_month + "-" + Zeroappended_Date;
      return newDate;
    }

  }
  appendLeadingZero(n) {
    if (n <= 9) {
      return "0" + n;
    }
    return n
  }
  fetchStatus
    = [
      { value: 'ACTV', viewValue: 'ACTV' },
      { value: 'NA', viewValue: 'NA' },
    ];
  fetchBranch(bankId: number) {
    this.addUserForm.controls['userBranch'].reset();
    this.addUserForm.controls['userZone'].reset();
    this.addUserForm.controls['userRegion'].reset();
    this.addUserForm.controls['userDepartment'].reset();
    this.addUserForm.controls['userDesignation'].reset();

    this.service.fetchBranchList(bankId).subscribe(res => {
      
      if(res['statusCode']=="R107"){
        this.branchList = res['data'];
      }
    });
    this.bankId = bankId
    this.fetchDeptList(bankId)
    this.fetchDesigList(bankId)
    this.fetchRole(bankId)
    this.fetchZone(bankId)


  }

  fetchDeptList(bankId: number) {
    this.service.fetchDeptList(bankId).subscribe(res => {
      
      if(res['statusCode']=="R060"){
        this.deptList = res['data'];

      
    }
    });
  }
  fetchDesigList(bankId: number) {
    this.service.fetchDesigList(bankId).subscribe(res => {
      
      
      if(res['statusCode']=="R074"){
        this.desigList = res['data'];
      
    }
    });
  }
  fetchRole(bankId: number) {
    this.service.fetchRoleList(bankId).subscribe(res => {
      if(res['statusCode']=="R024"){
          this.roleList = res['data']['roles'];

        
      }
    });
  }

  fetchZone(bankId) {
    this.service.fetchZoneList(bankId).subscribe((res) => {
      if(res['statusCode']=="R096"){
        if(res['data'].length>0){
          this.zoneList = res['data'];

        }
        else{
          this.zoneList=["No Data Found"]
        }
      }
      else{
        let data=[];
        data.push(res['statusDesc'])
        this.zoneList=data;
      }

      
    },(error)=>{
      this.zoneList=['Server Not Responding, Please Try Again Later.']
    });
  }
  getRegion(zoneId) {
    this.fetchRegion(zoneId)
  }
  fetchRegion(zoneId) {
    this.service.fetchRegionList(this.bankId, zoneId).subscribe((res) => {
      if(res['statusCode']=="R087")
      this.regionList = res['data'];
    });
  }

  reset() {
    this.addUserForm.reset();

    this.addUserForm.markAsPristine();
    this.addUserForm.markAsUntouched();
    this.addUserForm.updateValueAndValidity();
    this.submitted = false;
  }

}
