import { Component, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { Router } from '@angular/router';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { UserView } from 'src/app/models/user/userView';
import { UserService } from 'src/app/services/user.service';
import { LoginService } from 'src/app/services/subscribe/login.service';
import { FilterModel } from 'src/app/models/filter';

@Component({
  selector: 'app-view-user',
  templateUrl: './view-user.component.html',
  styleUrls: ['./view-user.component.css']
})
export class ViewUserComponent implements OnInit {

  @Output() nameEvent = new EventEmitter<any>();

  displayedColumns: string[] = [ 'member name', 'branch_name','users', 'create_date', 'status'];
  dataSource: MatTableDataSource<UserView>;
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  // filter
  // stateCtrl = new FormControl();
  userCtrl = new FormControl();
  // filteredStates: Observable<any>;
  filteredUsers: Observable<any>;
  filterModel: FilterModel = new FilterModel();
  totalCount: number;
  crudPriv : number;
  userListDesc;


  constructor(private router: Router, private service: UserService, private loginService: LoginService) {
    this.filterModel = {
      name : '',
      page: 0,
      size: 5
    }
    // this.filteredStates = this.stateCtrl.valueChanges
    // .pipe(
    //   startWith(''),
    //   map(state => state ? this._filterStates(state) : this.states.slice())
    // );
  }
  //  private _filterStates(value: string) {
  //   const filterValue = value.toLowerCase();

  //   return this.states.filter(state => state.name.toLowerCase().indexOf(filterValue) === 0);
  // }

  ngOnInit(): void {
    this.crudPriv =  +localStorage.getItem('cdPms');
    this.userList(this.filterModel)
  }

  passName(e, element, type) {
    e.preventDefault();
    this.nameEvent.emit({ name: element, type: type, category: 'user' });
  }


  userList(pageParams) {
    this.service.viewListUsers(pageParams).subscribe(data => {
      console.log("userrrrrrrrrrrrrrrrrrr",data)
      if(data['statusCode']=="R011"){
        if(data["data"]['content'].length > 0){
          this.dataSource = new MatTableDataSource(data["data"]['content']);
          this.totalCount = data["data"]['totalElements']
        }
        else{
          this.dataSource = null;
          this.userListDesc = "No Records Found";
        }
      }
      else{
        this.dataSource = null;
        this.userListDesc = data['statusDesc'];
      }
      
    },(error)=>{
      this.dataSource = null;
      this.userListDesc = "Server Not Responding, Please Try Again Later."
    });
  }
  paginatorClick(pageNum: Number) {
    
    this.filterModel.page = pageNum['pageIndex'];
    this.filterModel.size = pageNum['pageSize'];
    this.userList(this.filterModel);

  }
  onSearch(event: Event) {
    this.paginator.firstPage();
    this.filterModel.name = (event.target as HTMLInputElement).value
    this.filterModel.page = 0;
    this.filterModel.size = 5;
    this.userList(this.filterModel);
  
  }
}
