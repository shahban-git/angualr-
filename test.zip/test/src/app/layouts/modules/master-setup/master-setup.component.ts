import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute,ActivatedRouteSnapshot} from '@angular/router';
import { MatTabChangeEvent } from '@angular/material/tabs';

@Component({
  selector: 'app-master-setup',
  templateUrl: './master-setup.component.html',
  styleUrls: ['./master-setup.component.css']
})
export class MasterSetupComponent implements OnInit {
  public selectedTabNames = ['Member','Department / Designation','Role',
  'Zone','Region','Branch','Configuration'];
  public selectedTab = this.selectedTabNames[0];
  tabarray=['member','department/designation','role',
  'zone','region','branch','configuration']
  selectedIndex:number = 0;
  tabIndex=0;
  constructor(private route :ActivatedRoute) { }

  ngOnInit(): void {
    let index = this.route.snapshot.params.index;
    console.log("index",index);
    this.tabIndex
    
    this.selectedIndex =   index !== undefined ? index : 0;
    this.tabIndex=index !== undefined ? index : 0;
    console.log("tabbbbbbbbbbbbbbbbbb",this.selectedIndex)
    localStorage.setItem("tabInd",this.tabIndex.toString())
    localStorage.setItem("viewData",this.tabarray[this.selectedIndex])
    this.selectedTab = this.selectedTabNames[this.selectedIndex];
  }
  onTabChanged(event: MatTabChangeEvent) 
  {
    this.tabIndex=event.index
    console.log("tab change event",this.tabarray[this.tabIndex]);
    let a ="dep"
    this.tabIndex=event.index
    let b=1
    localStorage.setItem("tabInd",this.tabIndex.toString())
    localStorage.setItem("viewData",this.tabarray[this.tabIndex])
    this.selectedTab=this.selectedTabNames[event.index];
  }
  
}
