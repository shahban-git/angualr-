import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {
  FormGroup,
  FormControl,
  Validators,
  FormBuilder,
  FormArray,
} from '@angular/forms';
import { ConfigurationCreate } from 'src/app/models/config-user/config-create';
import { ConfigService } from 'src/app/services/master/config.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-edit-config',
  templateUrl: './edit-config.component.html',
  styleUrls: ['./edit-config.component.css'],
})
export class EditConfigComponent implements OnInit {
  @Output() cancelEvent = new EventEmitter<any>();
  @Input() userNameFromParent;
  editConfigForm: FormGroup;
  configUpdate: ConfigurationCreate;
  submitted = false;

  // convenience getters for easy access to form fields
  get f() {
    return this.editConfigForm.controls;
  }

  constructor(
    private formBuilder: FormBuilder,
    private service: ConfigService
  ) {}

  ngOnInit(): void {
    this.configUpdate = JSON.parse(this.userNameFromParent);
    this.editConfigForm = this.formBuilder.group({
      configBank: [{ bankId: 233 }, Validators.required],
      configEntity: [{ entityId: 230 }],
      configHostIP: [this.configUpdate.configHostIP, Validators.required],
      configHostPort: [this.configUpdate.configHostPort, Validators.required],
      configUsername: [this.configUpdate.configUsername, Validators.required],
      configPassword: [this.configUpdate.configPassword, Validators.required],
      configPasswordTrackCount: [
        this.configUpdate.configPasswordTrackCount,
        Validators.required,
      ],
      configPasswordExpiry: [
        this.configUpdate.configPasswordExpiry,
        Validators.required,
      ],
      configLockCounter: [
        this.configUpdate.configLockCounter,
        Validators.required,
      ],
      configRecordPerPage: [
        this.configUpdate.configRecordPerPage,
        Validators.required,
      ],
      configCaptchaEnabled: [
        this.configUpdate.configCaptchaEnabled,
        Validators.required,
      ],
      configMailAddress: [
        this.configUpdate.configMailAddress,
        Validators.required,
      ],
    });
  }
  onSubmit(form: FormGroup) {
    this.submitted = true;
    if (form.invalid) {
      return;
    }
    Swal.fire({
      imageUrl: 'assets/images/checked_icon.svg',
      text: 'Configuaration data has been saved successfully.',
    });
  }
  cancel() {
    this.cancelEvent.emit({ name: '', type: 'cancel', category: 'config' });
  }
}
