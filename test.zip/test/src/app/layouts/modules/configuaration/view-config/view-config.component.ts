import { Component, OnInit ,ViewChild, Output, EventEmitter} from '@angular/core';
import { MatTableDataSource} from '@angular/material/table';
import {MatPaginator} from '@angular/material/paginator';
import { BankView } from 'src/app/models/bank/bank-view';
import { ConfigService } from 'src/app/services/master/config.service';
import { FilterModel } from 'src/app/models/filter';

@Component({
  selector: 'app-view-config',
  templateUrl: './view-config.component.html',
  styleUrls: ['./view-config.component.css']
})
export class ViewConfigComponent implements OnInit {
  @Output() nameEvent = new EventEmitter<any>();
  crudPriv : number;
  displayedColumns: string[] = [ 'member name'];
  dataSource :  MatTableDataSource<BankView>;
  filterModel: FilterModel = new FilterModel();
  totalCount: number;
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  constructor(private service: ConfigService) {
    this.filterModel = {
      name : '',
      page: 0,
      size: 5
    }
  }

  ngOnInit(): void {
    this.crudPriv = +localStorage.getItem('cdPms');
    this.refreshConfigList(this.filterModel);
  }

  passName(e,element,type){
    e.preventDefault();
    this.nameEvent.emit({name:element,type:type,category:'config'});
  }

  refreshConfigList(pageParmas)
  {
     this.service.getConfigList(pageParmas).subscribe(data => {
       console.log("configurationsssssssssssss",data)
       this.dataSource = new MatTableDataSource(data["data"]["Config List"]["content"]);
       this.totalCount = data["data"]["Config List"]['totalElements']
       //this.dataSource.paginator = this.paginator;
     });
  }
  paginatorClick(pageNum: Number) {
    this.filterModel.page = pageNum['pageIndex'];
    this.filterModel.size = pageNum['pageSize'];
    this.refreshConfigList(this.filterModel);

  }

  onSearch(event: Event) {
    this.paginator.firstPage();
    this.filterModel.name = (event.target as HTMLInputElement).value
    this.filterModel.page = 0;
    this.filterModel.size = 5;
    this.refreshConfigList(this.filterModel);
  
  }
}
