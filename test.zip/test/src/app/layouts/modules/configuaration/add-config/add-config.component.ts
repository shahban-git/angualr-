import { Component, OnInit } from '@angular/core';
import {FormGroup, FormControl, Validators,FormBuilder, FormArray} from '@angular/forms';
import { ConfigurationCreate } from 'src/app/models/config-user/config-create';
import { ConfigService } from 'src/app/services/master/config.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-config',
  templateUrl: './add-config.component.html',
  styleUrls: ['./add-config.component.css']
})
export class AddConfigComponent implements OnInit {
  addConfigForm: FormGroup;
  submitted = false;
  configSave : ConfigurationCreate;
  bankList;
  // convenience getters for easy access to form fields
  get f() { return this.addConfigForm.controls; }


  constructor(private formBuilder: FormBuilder, private service : ConfigService) { }

  ngOnInit(): void {
    this.formInit();
    this.fetchBank();
  }

  formInit(){
    this.addConfigForm = this.formBuilder.group({
      configBank: ["", Validators.required],
      configEntity : [{entityId : 230}],
      configHostIP :["",Validators.required],
      configHostPort :["",Validators.required],
      configUsername :["",Validators.required],
      configPassword:["",Validators.required],
      configPasswordTrackCount:["",Validators.required],
      configPasswordExpiry:['',Validators.required],
      configLockCounter:["",Validators.required],
      configRecordPerPage:["",Validators.required],
      configCaptchaEnabled:["",Validators.required],
      configMailAddress:["",Validators.required]
    });
  }

  onSubmit(form: FormGroup) {
    this.submitted = true;
    this.configSave = form.value;
    this.configSave.configBank = {
      bankId : form.value['configBank']
    }
    if(form.invalid){
      return ;
    }
    this.service.saveConfig(this.configSave).subscribe(data => {
    })
    Swal.fire({
      imageUrl: 'assets/images/process.svg',
      text: 'Member set-up is still in progress.Once checker will approve the setupit will be done successfully.'
    })
    this.reset();
  }
  reset(){
    this.addConfigForm.reset();
    this.formInit();
    Object.keys(this.addConfigForm.controls).forEach(key => {
      this.addConfigForm.controls[key].setErrors(null);
    });
    this.submitted = false;
  }

  fetchBank() {
    this.service.fetchBankList().subscribe((res) => {
      this.bankList = res['Bank DropDown'];
    });
  }

}
