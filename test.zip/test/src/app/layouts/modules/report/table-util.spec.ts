import { TableUtil } from './table-util';

describe('TableUtil', () => {
  it('should create an instance', () => {
    expect(new TableUtil()).toBeTruthy();
  });
});
