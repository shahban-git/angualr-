import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SiCancelledAllTxnRangeReportComponent } from './si-cancelled-all-txn-range-report.component';

describe('SiCancelledAllTxnRangeReportComponent', () => {
  let component: SiCancelledAllTxnRangeReportComponent;
  let fixture: ComponentFixture<SiCancelledAllTxnRangeReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SiCancelledAllTxnRangeReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SiCancelledAllTxnRangeReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
