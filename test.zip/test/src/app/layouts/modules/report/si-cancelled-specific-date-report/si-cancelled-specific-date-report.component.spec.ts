import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SiCancelledSpecificDateReportComponent } from './si-cancelled-specific-date-report.component';

describe('SiCancelledSpecificDateReportComponent', () => {
  let component: SiCancelledSpecificDateReportComponent;
  let fixture: ComponentFixture<SiCancelledSpecificDateReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SiCancelledSpecificDateReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SiCancelledSpecificDateReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
