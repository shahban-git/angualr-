import { Component, OnInit, ViewChild } from '@angular/core';
import {FormGroup, FormControl, Validators,FormBuilder } from '@angular/forms';
import { MatTableDataSource} from '@angular/material/table';
import {MatDialog} from '@angular/material/dialog';
import {MatPaginator} from '@angular/material/paginator';
// import { SidailyRequest } from ../../src/app/layouts/modules/model/si-daily-mis-listing-requestt';
// import { SiListingRequest } from '../../src/app/layouts/modules/model/si-daily-mis-listing-request';
import { FilterModel } from 'src/app/models/filter';
import {MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS} from '@angular/material-moment-adapter';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';
import {MatDatepicker} from '@angular/material/datepicker';
import * as _moment from 'moment';
import {Moment} from 'moment';


//import * as jsPDF from 'jspdf';
//import JSPDF from 'jspdf';
import { jsPDF } from 'jspdf';
import 'jspdf-autotable'
import { DailyTableUtil} from '../Dailytable-util'
import { SiTxnListServiceService } from 'src/app/services/si-daily-mis-list-service';
import { SiTxnListingResponse } from '../../model/si-daily-mis-listing-response';
import { SiListingRequest } from '../../model/si-daily-mis-listing-request'


import { DatePipe } from '@angular/common';
import { months } from 'node_modules_old/moment/moment';


const moment =  _moment;
let currentmonth = moment().month();

export const MY_FORMATS = {
  parse: {
    dateInput: 'MM/YYYY',
  },
  display: {
    dateInput: 'MM/YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};


@Component({
  selector: 'app-si-report',
  templateUrl: './si-daily-mis-report.component.html',
  styleUrls: ['./si-daily-mis-report.component.css'],
  providers: [
    
    // `MomentDateAdapter` can be automatically provided by importing `MomentDateModule` in your
    // application's root module. We provide it at the component level here, due to limitations of
    // our example generation script.

    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },

    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
  ],
})

export class SiDailyMISReportComponent implements OnInit {  
  
  submitted = false;
  isToFutureDate = false;
  isFromFutureDate = false;
  filterModel: FilterModel = new FilterModel();
  public displayColumn: string[] = [ 
  "card",
  "fromDate",
  "toDate",
  "forMonth",
  "register_SUCCESS",
  "register_DECLINE",
  'intimation_SUCCESS',
  "intimation_DECLINE",
  "txn_SUCCESS",
  "txn_DECLINE",
  "notifi_COUNT",
  "modification_COUNT",
  "cancelation_COUNT"
];


today = new Date();
public selectedOption: string;
show: boolean = false;


  dayschemeName = [
    {value: '01', viewValue: 'daily'},
    {value: '02', viewValue: 'monthly'}
  ];

  //for changing fileds dynamicaly...................
  OnschemeChange(){
    this.show = true;
    console.log("option value: "+ this.selectedOption)
  }


// for only month selector...........
  // date = new FormControl(moment());
  // chosenYearHandler(normalizedYear: Moment) {
  //   const ctrlValue = this.date.value;
  //   ctrlValue.year(normalizedYear.year());
  //   this.date.setValue(ctrlValue);
  // }
  // chosenMonthHandler(normalizedMonth: Moment, datepicker: MatDatepicker<Moment>) {
  //   const ctrlValue = this.date.value;
  //   ctrlValue.month(normalizedMonth.month());
  //   this.date.setValue(ctrlValue);
  //   datepicker.close();
  // }






  formErrors = {

    'reportFromDate': '',
    'reportToDate': '',
    'reportMonth': '',

  }

  validationMessages = {
    'reportFromDate': { 'required': 'From Date is required' ,'lessThenProperty':'Form Date Must Be Less Than To Date'},
    'reportToDate': { 'required': 'To Date is required' },
    'reportMonth': { 'required': 'month is required' },  
  }

  siListingRequest: SiListingRequest = {
    bankId: "", dayschemeName: "", fromDate: "", toDate: "", formonth: ""
  };
  // siListingRequest: any ;

  siTxnListingResponse: SiTxnListingResponse = {  
    fromDate: "",
    toDate: "",
    forMonth: "",
    card: "",
    register_SUCCESS:"",
    register_DECLINE: "",
    intimation_SUCCESS: "",
    intimation_DECLINE: "",
    txn_SUCCESS: "",
    txn_DECLINE:"",
    notifi_COUNT: "",
    modification_COUNT:"",
    cancelation_COUNT: "",
     
                                };
  siTxnListingResponseList: Array<SiTxnListingResponse> = [];
  siTxnReportForm: FormGroup;
  dataSource: any;
  searchKey: String;
  //public displayColumn: string[] = ['scheme', 'id', 'firstAmt', 'minAmt', 'maxAmt', 'noPayment', 'paymentFre'];
  public pageSizeOptions: number[] = [5, 10, 25, 100];
  
  //@ViewChild(MatPaginator) paginator: MatPaginator;
  //@ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;

  @ViewChild('paginator') paginator: MatPaginator;

  constructor(
    private formBuilder: FormBuilder,
    private siTxnListservice: SiTxnListServiceService,
    public dialog: MatDialog,
    public datepipe: DatePipe
    //private commonService: CommonService
  ) {}

  get f() { return this.siTxnReportForm.controls;}

  logValidationErrors(group: FormGroup = this.siTxnReportForm): void {
console.log("group control data :" + group.controls)
    Object.keys(group.controls).forEach((key: string) => {

      const abstractControl = group.get(key);
      this.formErrors[key] = '';
      if (abstractControl && !abstractControl.valid && (abstractControl.touched || abstractControl.dirty)) {
        const message = this.validationMessages[key];
        for (const err in abstractControl.errors) {
          if (err) {
            this.formErrors[key] = message[err] + ' ';
          }
        }
      }
      if (abstractControl instanceof FormGroup) {
        this.logValidationErrors(abstractControl);
      }
    });
  }

  formInit(){
    console.log('local Storage -> '+JSON.stringify(localStorage));
    this.siTxnReportForm = this.formBuilder.group({
      dayschemeName:['', Validators.required],
      reportFromDate: ["", Validators.required],
      reportToDate: ["", Validators.required],
      // reportmonth: ["", Validators.required],
    })
  }

  applyFilter() {
    this.dataSource.filter = this.searchKey.trim().toLowerCase();
  }

  onSearchClear() {
    this.searchKey = '';
    this.applyFilter();
  }

  get h() { return this.siTxnReportForm.controls; }

  loadDatatable(data){
    console.log("loadDatatable is called:")
    this.dataSource = new MatTableDataSource(data);    
    setTimeout(() => this.dataSource.paginator = this.paginator);
  }

  ngOnInit() {
    this.formInit();    
    this.today = new Date();
  }


  
  onDateChange(event){
    let currentDate = this.datepipe.transform((new Date()), 'dd-mm-yyyy');
    let todaysDate;
    todaysDate = new Date();
    currentDate = todaysDate;
    console.log("todaysDate:" + this.formatting_Date(todaysDate, "dd-mm-yyyy"))
    console.log("from Date :" + this.formatting_Date(this.siTxnReportForm.controls['reportFromDate'], "ddmmyyyy"))
    console.log("to Date :" + this.formatting_Date(this.siTxnReportForm.controls['reportToDate'], "ddmmyyyy"))
    
    if (this.formatting_Date( this.siTxnReportForm.controls['reportFromDate'], "ddmmyyyy") > 
    this.formatting_Date( this.siTxnReportForm.controls['reportToDate'], "ddmmyyyy")) {
      console.log("lesssssssssssssss")
      this.siTxnReportForm.controls['reportFromDate'].setErrors({ 'lessThenProperty': true })
    }
    else {
      console.log("greateeeeeee")
      this.siTxnReportForm.controls['reportFromDate'].setErrors(null)
    }
  }
  openDatePicker(dp) {
    dp.open();
  }


  // onMonthChange(event){
  //   let month = moment().month()
  //   currentmonth = month;
  //   let currentDate = this.datepipe.transform((new Date()), 'MM-YYYY');
  //   let todaysDate;
  //   todaysDate = new Date();
  //   currentDate = todaysDate;
  //   console.log("current month:" + this.formatting_month(currentmonth, "MM-YYYY"))
  //   console.log("todaysDate:" + this.formatting_month(todaysDate, "MM-YYYY"))
  //   console.log("selected month :" + this.formatting_month(this.siTxnReportForm.controls['reportMonth'], "mmyyyy"))

    
  //   if (this.formatting_month( this.siTxnReportForm.controls['reportMonth'], "MM/YYYY") > 
  //   this.formatting_month( this.siTxnReportForm.controls['currentmonth'], "MM/YYYY")) {
  //     console.log("lesssssssssssssss")
  //     this.siTxnReportForm.controls['reportFromDate'].setErrors({ 'lessThenProperty': true })
  //   }
  //   else {
  //     console.log("greateeeeeee")
  //     this.siTxnReportForm.controls['reportFromDate'].setErrors(null)
  //   }
  // }
  // openDatePicker1(dp) {
  //   dp.open();
  // }


// onmonth change 
  date = new FormControl(moment());
  setMonthAndYear(normalizedMonthAndYear: Moment, datepicker: MatDatepicker<Moment>) {
    const ctrlValue = this.date.value!;
    ctrlValue.month(normalizedMonthAndYear.month());
    ctrlValue.year(normalizedMonthAndYear.year());
    this.date.setValue(ctrlValue);
    datepicker.close();
  }

// month formater
// formatting_month(date, format): string {
//   let month = moment().month()
//   console.log("datefromater.............start  todays:", month)
//   let eventDate;
//   if (format == "MM/YYYY") {
//     eventDate = new Date(date.value);
//   } else {
//     eventDate = date;;
//   }
//   console.log("formated date ::" + date);
//   console.log("eventDate :", eventDate)
//   let Zeroappended_month = this.appendLeadingZero1((eventDate.getMonth() + 1));
//   let Zeroappended_year = this.appendLeadingZero1(eventDate.getDate());
//   console.log("month, year value: :" + Zeroappended_month,Zeroappended_year)
//   if (format == "MM/YYYY") {
//     let newmonth =  Zeroappended_month + "-" + eventDate.getFullYear();
//     console.log("Inside for month selector formator ")
//     console.log("dateeeeeeeeee........:", newmonth)
//     console.log("month selector gormator end:", newmonth)
//     return newmonth;
//   }
// }
// appendLeadingZero1(n) {
//   if (n <= 9) {
//     return "0" + n;
//   }
//   return n
  
// }


  formatting_Date(date, format): string {
    console.log("datefromater.............start  todays:", date)
    let eventDate;
    if (format == "ddmmyyyy") {
      eventDate = new Date(date.value);
    } else {
      eventDate = date;;
    }
    console.log("formated date ::" + date);
    console.log("eventDate :", eventDate)
    let Zeroappended_month = this.appendLeadingZero((eventDate.getMonth() + 1));
    let Zeroappended_Date = this.appendLeadingZero(eventDate.getDate());
    console.log("zerooooooooo...............:",Zeroappended_month,Zeroappended_Date)
    if (format == "ddmmyyyy") {
      let newDate = Zeroappended_Date + "-" + Zeroappended_month + "-" + eventDate.getFullYear();
      console.log("dateeeeeeeeee........:",newDate)
      console.log("+++++++++++formatting_Date++++++ end:", newDate)
      return newDate;
    }
  }
  appendLeadingZero(n) {
    if (n <= 9) {
      return "0" + n;
    }
    return n
  }



// ------------------------------------------------------------
  siTxnReportFormSubmit(form: FormGroup) : void{
    console.log("siTxnReportFormSubmit...........clicked")
    this.submitted = true;
    this.siTxnListingResponseList.length = 0;
    console.log("this.siTxnListingResponseList.length = 0;" + this.siTxnListingResponseList.length);

    if(this.siTxnReportForm.invalid){

      return console.log("siTxnReportForm is invalid");
    }  else{      
      console.log("inside else siTxnReportFormSubmit block")          
        //this.siListingRequest.cardNo = is.commonService.encry(this.siTxnReportForm.value.cardNo);   
        //this.siListingRequest.accountId = this.commonService.encry(localStorage.getItem('accountId'));           
        this.siListingRequest.bankId="0001";
        this.siListingRequest.dayschemeName = this.siTxnReportForm.value.dayschemeName;   
        //this.siListingRequest.toDate = this.siTxnReportForm.value.reportToDate;   
        this.siListingRequest.fromDate = this.formatting_Date( this.siTxnReportForm.controls['reportFromDate'], "ddmmyyyy")
        this.siListingRequest.toDate = this.formatting_Date( this.siTxnReportForm.controls['reportToDate'], "ddmmyyyy")
        // this.siListingRequest.formonth = (this.siTxnReportForm.controls['reportMonth'], "mmyyyy")
        this.siListingRequest.formonth = this.formatting_Date( this.siTxnReportForm.controls['reportMonth'], "MM/YYYY")
        // this.siListingRequest.formonth = this.siTxnReportForm.value.reportMonth;   

        console.log("formatting_Date.......pass............")

    
        this.siTxnListservice.siTxnListing(this.siListingRequest).subscribe(
          (data:any) => {
            console.log("siTxnListservice.......inside............")
            console.log(JSON.stringify(data));
            if(data['body']['result'] != "F"){
              data['body'].forEach((element) => {
                this.siTxnListingResponseList.push({
            
                fromDate: element.fromDate,
                toDate: element.toDate,
                forMonth: element.forMonth,
                card: element.card,
                register_SUCCESS:element.register_SUCCESS,
                register_DECLINE: element.register_DECLINE,
                intimation_SUCCESS: element.intimation_SUCCESS,
                intimation_DECLINE: element.intimation_DECLINE,
                txn_SUCCESS: element.txn_SUCCESS,
                txn_DECLINE:element.txn_DECLINE,
                notifi_COUNT: element.notifi_COUNT,
                modification_COUNT:element.modification_COUNT,
                cancelation_COUNT: element.cancelation_COUNT,

              //  this.siTxnListingResponseList.push(this.siListingResponse);
              //  console.log("Reg ID : "+this.commonService.decrypt(element.siRegistrationID));
             });
             });
           } 
            console.log("siTxnListservice execute for records...........")
            console.log("Total Record ====:"+ this.siTxnListingResponseList.length)
            let totalRecords = this.siTxnListingResponseList.length;
            this.pageSizeOptions = [5,10,this.siTxnListingResponseList.length];
            this.loadDatatable(this.siTxnListingResponseList);            
          },
          (error:any) => {
            alert(error['message']);            
          }
        );
    } 
  }



  createPdf() {
    console.log("inside createPdf.................")
    //let doc = new JSPDF.jsPDF(); 
    var doc = new jsPDF();
    doc.setFontSize(18);
    doc.text('My Team Detail', 11, 8);
    doc.setFontSize(11);
    doc.setTextColor(100);

    (doc as any).autoTable({
      body: this.siTxnListingResponseList,
      theme: 'plain',
      didDrawCell: data => {
        console.log(data.column.index)
      }
    })
    doc.output('dataurlnewwindow')
    // below line for Download PDF document  
    doc.save('myteamdetail.pdf');
  }


  exportTable() {
    console.log("inside exportTable........................")
    console.log("Scheme 1111 :" + this.siTxnReportForm.value.dayschemeName);
    DailyTableUtil.exportTableToExcel("ExampleMaterialTable1", this.siTxnReportForm.value.dayschemeName);
  }
  
}



