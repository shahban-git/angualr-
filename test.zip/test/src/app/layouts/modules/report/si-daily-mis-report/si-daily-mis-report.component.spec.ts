import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SiDailyMISReportComponent } from './si-daily-mis-report.component';

describe('SiDailyMISReportComponent', () => {
  let component: SiDailyMISReportComponent;
  let fixture: ComponentFixture<SiDailyMISReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SiDailyMISReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SiDailyMISReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
