import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SiTransactionReportComponent } from './si-transaction-report.component';

describe('SiTransactionReportComponent', () => {
  let component: SiTransactionReportComponent;
  let fixture: ComponentFixture<SiTransactionReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SiTransactionReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SiTransactionReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
