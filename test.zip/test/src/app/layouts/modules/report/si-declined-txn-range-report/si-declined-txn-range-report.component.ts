import { Component, OnInit, ViewChild } from '@angular/core';
import {FormGroup, FormControl, Validators,FormBuilder, FormArray,FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTableDataSource} from '@angular/material/table';
import {MatDialog, MatDialogConfig, MatDialogRef} from '@angular/material/dialog';
import {MatPaginator} from '@angular/material/paginator';
import { SiListingRequest } from '../../model/si-listing-request';
//import { SiListingResponse } from '../../model/si-listing-response';
import { FilterModel } from 'src/app/models/filter';

//import * as jsPDF from 'jspdf';
//import JSPDF from 'jspdf';
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import { TableUtil } from '../table-util';
import { SiTxnListServiceService } from 'src/app/services/si-txn-list-service.service';
import { SiTxnListingResponse } from '../../model/si-txn-listing-response';
import { SiDeclinedTxnListingResponse } from '../../model/si-declined-txn-listing-response';

@Component({
  selector: 'app-si-declined-txn-range-report',
  templateUrl: './si-declined-txn-range-report.component.html',
  styleUrls: ['./si-declined-txn-range-report.component.css']
})
export class SiDeclinedTxnRangeReportComponent implements OnInit {  
  
  //linkedCards: linkedCards;

  submitted = false;
  filterModel: FilterModel = new FilterModel();
  public displayColumn: string[] = ['tranID', 'description', 
  'tranDateTime','transactionUpdatedDate'];


  schemeName = [
    {value: '01', viewValue: 'Rupay'},
    {value: '02', viewValue: 'Visa'},
    {value: '03', viewValue: 'Master'},
  ];

  head = [[ 'siRegistrationID', 
            'merchantName', 
            'issuerBin', 
            'siMinimumAmount',
            'siMaximumAmount',
            'siNoOfSITxns',
            'siPreferredInitiationDate',
            'siFrequency',
            'siStatus']]

  formErrors = {
    'userBank': '',
    'userBranch': '',
    'userDepartment': '',
    'userDesignation': '',
    'userRole': '',
    'userEmployeeId': '',
    'userName': '',
    'userFirstName': '',
    'userPhone': '',
    'userEmail': '',
    'reportFromDate': '',
    'reportToDate': '',
    'userStatus': '',
    'reportingOfficer': '',
    'userZone': '',
    'userRegion': '',


  }

  validationMessages = {
    'userBank': { 'required': 'Bank is required' },
    'userBranch': { 'required': 'Branch is required' },
    'userZone': { 'required': 'Zone is required' },
    'userRegion': { 'required': 'Region is required' },
    'userDepartment': { 'required': 'Department is required' },
    'userDesignation': { 'required': 'Designation is required' },
    'userRole': { 'required': 'Role is required' },
    'userEmployeeId': { 'required': 'Employee ID is required' },
    'userName': { 'required': 'User Name is required', 'minlength': 'Minimum Length 5 required', 'pattern': 'Special characters not allowed' },
    'userFirstName': { 'required': 'First Name is required', 'minlength': 'Minimum Length 3 required', 'pattern': 'Special characters and Digits not allowed' },
    'userPhone': { 'required': 'Mobile Number is required',
     'min': 'Phone Number is invalid', 'pattern':'Only Numbers Allowed' },
    'userEmail': { 'required': 'Email is required', 'email': 'Invalid email format' },
    'reportFromDate': { 'required': 'From Date is required' ,'lessThenProperty':'Form Date Must Be Less Than To Date'},
    'reportToDate': { 'required': 'To Date is required' },
    'userStatus': { 'required': 'User Status is required' },
    'reportingOfficer': {  'minlength': 'Minimum Length 3 required', 'pattern': 'Special characters and Digits not allowed' }
    

  }
  siListingRequest: SiListingRequest = { bankId:"", schemeName : "", fromDate : "", toDate : "" };
  siDeclinedTxnListingResponse: SiDeclinedTxnListingResponse = {  
                                                  tranID: "",
                                                  description:"",  
                                                  tranDateTime: "",
                                                  transactionUpdatedDate: "",
                                          };
  siDeclinedTxnListingResponseList: Array<SiDeclinedTxnListingResponse> = [];
  siDeclinedTxnReportForm: FormGroup;
  dataSource: any;
  searchKey: String;
  //public displayColumn: string[] = ['scheme', 'id', 'firstAmt', 'minAmt', 'maxAmt', 'noPayment', 'paymentFre'];
  public pageSizeOptions: number[] = [5, 10, 25, 100];
  
  //@ViewChild(MatPaginator) paginator: MatPaginator;
  //@ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;

  @ViewChild('paginator') paginator: MatPaginator;

  constructor(
    private formBuilder: FormBuilder,
    private siTxnListservice: SiTxnListServiceService,
    public dialog: MatDialog,
    //private commonService: CommonService
  ) {}

  get f() { return this.siDeclinedTxnReportForm.controls; }

  logValidationErrors(group: FormGroup = this.siDeclinedTxnReportForm): void {

    Object.keys(group.controls).forEach((key: string) => {

      const abstractControl = group.get(key);
      this.formErrors[key] = '';
      if (abstractControl && !abstractControl.valid && (abstractControl.touched || abstractControl.dirty)) {
        const message = this.validationMessages[key];
        for (const err in abstractControl.errors) {
          if (err) {
            this.formErrors[key] = message[err] + ' ';
          }
        }
      }
      if (abstractControl instanceof FormGroup) {
        this.logValidationErrors(abstractControl);
      }
    });
  }

  formInit(){
    console.log('local Storage -> '+JSON.stringify(localStorage));
    //this.linkedCards = JSON.parse(localStorage.getItem('linkedCards'));
    //console.log('local Storage -> '+JSON.stringify(this.linkedCards));   
    
    //this.siDeclinedTxnReportForm = this.formBuilder.group({
     // mobileNo: [localStorage.getItem('mobileNo')],
     // accountId:[localStorage.getItem('accountId')],
     // cardNo: ["", Validators.required]
    //});
    this.siDeclinedTxnReportForm = this.formBuilder.group({
      //schemeName : new FormControl()
      schemeName:['', Validators.required],
      //memberName: ["", Validators.required],
      reportFromDate: ["", Validators.required],
      reportToDate: ["", Validators.required],
      
    })
  }

  applyFilter() {
    this.dataSource.filter = this.searchKey.trim().toLowerCase();
  }

  onSearchClear() {
    this.searchKey = '';
    this.applyFilter();
  }

  get h() { return this.siDeclinedTxnReportForm.controls; }

  loadDatatable(data){
    this.dataSource = new MatTableDataSource(data);    
    setTimeout(() => this.dataSource.paginator = this.paginator);
  }

  ngOnInit() {
    this.formInit();    
  }

  onDateChange(event){
    if (this.formatting_Date( this.siDeclinedTxnReportForm.controls['reportFromDate'], "ddmmyyyy") > 
    this.formatting_Date( this.siDeclinedTxnReportForm.controls['reportToDate'], "ddmmyyyy")) {
      console.log("lesssssssssssssss")
      this.siDeclinedTxnReportForm.controls['reportFromDate'].setErrors({ 'lessThenProperty': true })

    }
    else {
      console.log("greateeeeeee")
      this.siDeclinedTxnReportForm.controls['reportFromDate'].setErrors(null)
    }
  }


  formatting_Date(date, format): string {
    let eventDate = new Date(date.value);
    console.log("dateeeeeeeeeeeee",eventDate)
    let Zeroappended_month = this.appendLeadingZero((eventDate.getMonth() + 1));
    let Zeroappended_Date = this.appendLeadingZero(eventDate.getDate());
    console.log("zerooooooooo",Zeroappended_month,Zeroappended_Date)
    if (format == "ddmmyyyy") {
      let newDate = Zeroappended_Date + "-" + Zeroappended_month + "-" + eventDate.getFullYear();
      console.log("dateeeeeeeeee",newDate)
      return newDate;
    }
    else {
      let newDate = eventDate.getFullYear() + "-" + Zeroappended_month + "-" + Zeroappended_Date;
      return newDate;
    }

  }
  appendLeadingZero(n) {
    if (n <= 9) {
      return "0" + n;
    }
    return n
  }

  siDeclinedTxnReportFormSubmit(form: FormGroup) : void{
    console.log("Hiiiiiiiiiiiiiiiiiiiiiiii")
    this.submitted = true;
    this.siDeclinedTxnListingResponseList.length = 0;
    if(this.siDeclinedTxnReportForm.invalid){
      return;
    }  else{                
        //this.siListingRequest.cardNo = is.commonService.encry(this.siDeclinedTxnReportForm.value.cardNo);   
        //this.siListingRequest.accountId = this.commonService.encry(localStorage.getItem('accountId'));           

        this.siListingRequest.bankId="0001";
        this.siListingRequest.schemeName = this.siDeclinedTxnReportForm.value.schemeName;   
        //this.siListingRequest.fromDate = this.siDeclinedTxnReportForm.value.reportFromDate;   
        //this.siListingRequest.toDate = this.siDeclinedTxnReportForm.value.reportToDate;   
        

        this.siListingRequest.fromDate = this.formatting_Date( this.siDeclinedTxnReportForm.controls['reportFromDate'], "ddmmyyyy")
        this.siListingRequest.toDate = this.formatting_Date( this.siDeclinedTxnReportForm.controls['reportToDate'], "ddmmyyyy")
        

        this.siTxnListservice.siDeclinedTxnListing(this.siListingRequest).subscribe(
          (data:any) => {
            console.log(JSON.stringify(data));
            if(data['body']['result'] != "F"){
              data['body']['declineTransactionList'].forEach( (element) => {
                this.siDeclinedTxnListingResponseList.push({
                  tranID : element.transactionId,
                  description : element.description,
                  tranDateTime: element.transactionDateTime,
                  transactionUpdatedDate: element.updatedDate,
                //siRegistrationID: element.siRegistrationID,
                //merchantId: element.merchantId,
                //cardNo: element.cardNo,
                //cardExpiryDate: element.cardExpiryDate,
                //authAmount: element.authAmount,
                
                
                
                //txnStatus: element.txnStatus,
                //reasonCode: element.reasonCode,
                
                
                
                //issuerBin: element.issuerBin,
                //siCreateDate: element.siCreateDate,
                //active: element.active,
                //siUpdateDate: element.siUpdateDate


               //this.siListingResponseList.push(this.siListingResponse);
               //console.log("Reg ID : "+this.commonService.decrypt(element.siRegistrationID));
             });
             });
           } 
            
            console.log("Total Record ===="+this.siDeclinedTxnListingResponseList.length)
            let totalRecords = this.siDeclinedTxnListingResponseList.length;
            this.pageSizeOptions = [5,10,this.siDeclinedTxnListingResponseList.length];
            this.loadDatatable(this.siDeclinedTxnListingResponseList);            
          },
          (error:any) => {
            alert(error['message']);            
          }
        );
    } 
  }

  createPdf() {

    //let doc = new JSPDF.jsPDF(); 
    var doc = new jsPDF();

    doc.setFontSize(18);
    doc.text('My Team Detail', 11, 8);
    doc.setFontSize(11);
    doc.setTextColor(100);

    (doc as any).autoTable({
      head: this.head,
      body: this.siDeclinedTxnListingResponseList,
      //body: this.dataSource,
      theme: 'plain',
      didDrawCell: data => {
        console.log(data.column.index)
      }
    })
    doc.output('dataurlnewwindow')

    // below line for Download PDF document  
    doc.save('myteamdetail.pdf');
  }

  exportTable() {
    TableUtil.exportTableToExcel("ExampleMaterialTable1",this.siDeclinedTxnReportForm.value.schemeName);
  }

  
}

 
