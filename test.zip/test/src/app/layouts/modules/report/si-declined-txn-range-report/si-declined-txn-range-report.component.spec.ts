import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SiDeclinedTxnRangeReportComponent } from './si-declined-txn-range-report.component';

describe('SiDeclinedTxnRangeReportComponent', () => {
  let component: SiDeclinedTxnRangeReportComponent;
  let fixture: ComponentFixture<SiDeclinedTxnRangeReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SiDeclinedTxnRangeReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SiDeclinedTxnRangeReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
