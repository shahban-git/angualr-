import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SiModifiedRangeReportComponent } from './si-modified-range-report.component';

describe('SiModifiedRangeReportComponent', () => {
  let component: SiModifiedRangeReportComponent;
  let fixture: ComponentFixture<SiModifiedRangeReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SiModifiedRangeReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SiModifiedRangeReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
