import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SiCancelledNextTxnRangeReportComponent } from './si-cancelled-next-txn-range-report.component';

describe('SiCancelledNextTxnRangeReportComponent', () => {
  let component: SiCancelledNextTxnRangeReportComponent;
  let fixture: ComponentFixture<SiCancelledNextTxnRangeReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SiCancelledNextTxnRangeReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SiCancelledNextTxnRangeReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
