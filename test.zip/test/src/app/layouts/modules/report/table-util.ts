import * as XLSX from "xlsx";

const getFileName = (name: string) => {
  let timeSpan = new Date().toISOString();
  //let sheetName = name || "ExportResult";
  
  if(name==="01"){
    name="Rupay"
  }
  if(name==="02"){
    name="Visa"
  }
  if(name==="03"){
    name="Master"
  }

  let sheetName = name+"_SI_Report";
  let fileName = `${sheetName}-${timeSpan}`;
  return {
    sheetName,
    fileName
  };
};
export class TableUtil {
  static exportTableToExcel(tableId: string, name?: string) {
    console.log("tableId :"+tableId+" name :"+name)
    let { sheetName, fileName } = getFileName(name);
    let targetTableElm = document.getElementById(tableId);
    
    //let wb = XLSX.utils.table_to_book(targetTableElm, <XLSX.Table2SheetOpts>{
    //  sheet: sheetName
    //});


    let wb = XLSX.utils.book_new()

    const worksheet: XLSX.WorkSheet=XLSX.utils.table_to_sheet(targetTableElm,  {raw:true});
    
    XLSX.utils.book_append_sheet(wb, worksheet,'SheetName');

    XLSX.writeFile(wb, `${fileName}.xlsx`);
  
  }

  static exportArrayToExcel(arr: any[], name?: string) {
    let { sheetName, fileName } = getFileName(name);

    var wb = XLSX.utils.book_new();
    var ws = XLSX.utils.json_to_sheet(arr);
    XLSX.utils.book_append_sheet(wb, ws, sheetName);
    XLSX.writeFile(wb, `${fileName}.xlsx`);
  }
}
