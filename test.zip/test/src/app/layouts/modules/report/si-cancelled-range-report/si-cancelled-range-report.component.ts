import { Component, OnInit, ViewChild } from '@angular/core';
import {FormGroup, FormControl, Validators,FormBuilder, FormArray,FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTableDataSource} from '@angular/material/table';
import {MatDialog, MatDialogConfig, MatDialogRef} from '@angular/material/dialog';
import {MatPaginator} from '@angular/material/paginator';
import { SiListingRequest } from '../../model/si-listing-request';
import { SiListingResponse } from '../../model/si-listing-response';
import { SiListServiceService } from 'src/app/services/si-list-service.service';
import { FilterModel } from 'src/app/models/filter';

//import * as jsPDF from 'jspdf';
//import JSPDF from 'jspdf';
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import { TableUtil } from '../table-util';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-si-cancelled-range-report',
  templateUrl: './si-cancelled-range-report.component.html',
  styleUrls: ['./si-cancelled-range-report.component.css']
})
export class SiCancelledRangeReportComponent implements OnInit {  
  
  //linkedCards: linkedCards;

  submitted = false;
  isToFutureDate = false;
  isFromFutureDate = false;
  filterModel: FilterModel = new FilterModel();
  public displayColumn: string[] = ['scheme', 'id', 'firstAmt', 'minAmt', 'maxAmt', 'noPayment', 'paymentFre'];
  

  schemeName = [
    {value: '01', viewValue: 'Rupay'},
    {value: '02', viewValue: 'Visa'},
    {value: '03', viewValue: 'Master'},
  ];

  head = [[ 'siRegistrationID', 
            'merchantName', 
            'issuerBin', 
            'siMinimumAmount',
            'siMaximumAmount',
            'siNoOfSITxns',
            'siPreferredInitiationDate',
            'siFrequency',
            'siStatus']]

  formErrors = {
    'reportFromDate': '',
    'reportToDate': '',
   }

  validationMessages = {
    'reportFromDate': { 'required': 'From Date is required' ,'lessThenProperty':'Form Date Must Be Less Than To Date'},
    'reportToDate': { 'required': 'To Date is required' },
     

  }
  siListingRequest: SiListingRequest = { bankId:"", schemeName : "", fromDate : "", toDate : "" };
  siListingResponse: SiListingResponse = {  siRegistrationID : "",
  merchantId: "",
  tid:"",
  siCreateDate: "",
  authAmt:"",
                                            merchantName : "",
                                            issuerBin : "",
                                            siMinimumAmount : "",                                            
                                            siMaximumAmount : "",
                                            siNoOfSITxns : "",
                                            siPreferredInitiationDate : "",
                                            siFrequency : "",
                                            siStatus : "",
                                          };
  siListingResponseList: Array<SiListingResponse> = [];
  siCancelledRangeReportForm: FormGroup;
  dataSource: any;
  searchKey: String;
  //public displayColumn: string[] = ['scheme', 'id', 'firstAmt', 'minAmt', 'maxAmt', 'noPayment', 'paymentFre'];
  public pageSizeOptions: number[] = [5, 10, 25, 100];
  
  //@ViewChild(MatPaginator) paginator: MatPaginator;
  //@ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;

  @ViewChild('paginator') paginator: MatPaginator;

  constructor(
    private formBuilder: FormBuilder,
    private siListservice: SiListServiceService,
    public dialog: MatDialog,
    public datepipe: DatePipe
    //private commonService: CommonService
  ) {}

  get f() { return this.siCancelledRangeReportForm.controls; }

  logValidationErrors(group: FormGroup = this.siCancelledRangeReportForm): void {

    Object.keys(group.controls).forEach((key: string) => {

      const abstractControl = group.get(key);
      this.formErrors[key] = '';
      if (abstractControl && !abstractControl.valid && (abstractControl.touched || abstractControl.dirty)) {
        const message = this.validationMessages[key];
        for (const err in abstractControl.errors) {
          if (err) {
            this.formErrors[key] = message[err] + ' ';
          }
        }
      }
      if (abstractControl instanceof FormGroup) {
        this.logValidationErrors(abstractControl);
      }
    });
  }

  formInit(){
    console.log('local Storage -> '+JSON.stringify(localStorage));
    //this.linkedCards = JSON.parse(localStorage.getItem('linkedCards'));
    //console.log('local Storage -> '+JSON.stringify(this.linkedCards));   
    
    //this.siCancelledRangeReportForm = this.formBuilder.group({
     // mobileNo: [localStorage.getItem('mobileNo')],
     // accountId:[localStorage.getItem('accountId')],
     // cardNo: ["", Validators.required]
    //});
    this.siCancelledRangeReportForm = this.formBuilder.group({
      //schemeName : new FormControl()
      schemeName:['', Validators.required],
      //memberName: ["", Validators.required],
      reportFromDate: ["", Validators.required],
      reportToDate: ["", Validators.required],
      
    })
  }

  applyFilter() {
    this.dataSource.filter = this.searchKey.trim().toLowerCase();
  }

  onSearchClear() {
    this.searchKey = '';
    this.applyFilter();
  }

  get h() { return this.siCancelledRangeReportForm.controls; }

  loadDatatable(data){
    this.dataSource = new MatTableDataSource(data);    
    setTimeout(() => this.dataSource.paginator = this.paginator);
  }

  ngOnInit() {
    this.formInit();    
  }

  onDateChange(event){

    let currentDate =this.datepipe.transform((new Date), 'ddmmyyyy');
    let todaysDate;
    todaysDate = new Date();
    console.log("currentDate:::::"+currentDate)
    console.log("Aj date :"+this.formatting_Date(todaysDate, "ddmmyyyy"))
    console.log("Todays Date :"+this.formatting_Date(new Date(), "ddmmyyyy"))

console.log("Date 2:"+this.formatting_Date(this.siCancelledRangeReportForm.controls['reportToDate'], "ddmmyyyy"))


    if (this.formatting_Date( this.siCancelledRangeReportForm.controls['reportFromDate'], "ddmmyyyy") > 
    this.formatting_Date( this.siCancelledRangeReportForm.controls['reportToDate'], "ddmmyyyy")) {
      console.log("lesssssssssssssss")
      this.siCancelledRangeReportForm.controls['reportFromDate'].setErrors({ 'lessThenProperty': true })

    }if (this.formatting_Date( this.siCancelledRangeReportForm.controls['reportFromDate'], "ddmmyyyy") > 
    currentDate) {
      console.log("From Date is future date")
      this.siCancelledRangeReportForm.controls['reportFromDate'].setErrors({ 'lessThenProperty': true })

    }if (this.formatting_Date( this.siCancelledRangeReportForm.controls['reportToDate'], "ddmmyyyy") > 
    currentDate) {
      console.log("To Date is future date")
      this.siCancelledRangeReportForm.controls['reportToDate'].setErrors({ 'lessThenProperty': true })

    }
    
    
    
    
    else {
      console.log("greateeeeeee")
      this.siCancelledRangeReportForm.controls['reportFromDate'].setErrors(null)
    }
  }


  formatting_Date(date, format): string {
    let eventDate = new Date(date.value);
    console.log("ffff Ddddaaattteee  ::"+date);
    console.log("eventDate :",eventDate)
    let Zeroappended_month = this.appendLeadingZero((eventDate.getMonth() + 1));
    let Zeroappended_Date = this.appendLeadingZero(eventDate.getDate());
    //console.log("zerooooooooo",Zeroappended_month,Zeroappended_Date)
    if (format == "ddmmyyyy") {
      let newDate = Zeroappended_Date + "-" + Zeroappended_month + "-" + eventDate.getFullYear();
      //console.log("dateeeeeeeeee",newDate)
      return newDate;
    }
    else {
      let newDate = eventDate.getFullYear() + "-" + Zeroappended_month + "-" + Zeroappended_Date;
      return newDate;
    }

  }
  appendLeadingZero(n) {
    if (n <= 9) {
      return "0" + n;
    }
    return n
  }

  siCancelledRangeReportFormSubmit(form: FormGroup) : void{


    
  this.isFromFutureDate = false;
let toFromDateValid=true;
  let currentDate =this.datepipe.transform((new Date), 'ddmmyyyy');
    let todaysDate;
    todaysDate = new Date();
    console.log("currentDate:::::"+currentDate)

  if (this.formatting_Date( this.siCancelledRangeReportForm.controls['reportFromDate'], "ddmmyyyy") > 
    currentDate) {
      console.log("From Date is future date")
      this.isFromFutureDate = true;
      toFromDateValid = false;

    }if (this.formatting_Date( this.siCancelledRangeReportForm.controls['reportToDate'], "ddmmyyyy") > 
    currentDate) {
      console.log("To Date is future date")
      this.isToFutureDate = true;
      toFromDateValid = false;
   }
   if(toFromDateValid){
    console.log("Hiiiiiiiiiiiiiiiiiiiiiiii")
    this.submitted = true;
    this.siListingResponseList.length = 0;
    if(this.siCancelledRangeReportForm.invalid){
      this.logValidationErrors();
      return;
    }  else{                
        //this.siListingRequest.cardNo = is.commonService.encry(this.siCancelledRangeReportForm.value.cardNo);   
        //this.siListingRequest.accountId = this.commonService.encry(localStorage.getItem('accountId'));           


        this.siListingRequest.bankId="0001";

        this.siListingRequest.schemeName = this.siCancelledRangeReportForm.value.schemeName;
        //this.siListingRequest.fromDate = this.siCancelledRangeReportForm.value.reportFromDate;   
        //this.siListingRequest.toDate = this.siCancelledRangeReportForm.value.reportToDate;   
        

        this.siListingRequest.fromDate = this.formatting_Date( this.siCancelledRangeReportForm.controls['reportFromDate'], "ddmmyyyy")
        this.siListingRequest.toDate = this.formatting_Date( this.siCancelledRangeReportForm.controls['reportToDate'], "ddmmyyyy")
        

        this.siListservice.siCancelledRangeListing(this.siListingRequest).subscribe(
          (data:any) => {
            console.log(JSON.stringify(data));
            if(data['body']['result'] != "F"){
              data['body']['siDetails'].forEach( (element) => {
                this.siListingResponseList.push({
                siRegistrationID : element.siRegistrationID,
                merchantId :element.merchantId,
                tid:element.tid,
                siCreateDate: element.siCreateDate,
                authAmt:element.authAmt,
                //merchantId : this.commonService.decrypt(element.merchantId),
                //merchantId : element.merchantId,
                merchantName : element.merchantName,
                issuerBin : element.issuerBin,
                siMinimumAmount : element.siMinimumAmount,
                siMaximumAmount : element.siMaximumAmount,
                siNoOfSITxns : element.siNoOfSITxns,
                siPreferredInitiationDate : element.siPreferredInitiationDate,
                siFrequency : element.siFrequency,
                siStatus : element.siStatus
                //this.siListingResponseList.push(this.siListingResponse);
                //console.log("Reg ID : "+this.commonService.decrypt(element.siRegistrationID));
              });
              });
            } 
            
            console.log("Total Record ===="+this.siListingResponseList.length)
            let totalRecords = this.siListingResponseList.length;
            this.pageSizeOptions = [5,10,this.siListingResponseList.length];
            this.loadDatatable(this.siListingResponseList);            
          },
          (error:any) => {
            alert(error['message']);            
          }
        );
    } 
  }
  }

  createPdf() {

    //let doc = new JSPDF.jsPDF(); 
    var doc = new jsPDF();

    doc.setFontSize(18);
    doc.text('My Team Detail', 11, 8);
    doc.setFontSize(11);
    doc.setTextColor(100);

    (doc as any).autoTable({
      head: this.head,
      body: this.siListingResponseList,
      //body: this.dataSource,
      theme: 'plain',
      didDrawCell: data => {
        console.log(data.column.index)
      }
    })
    doc.output('dataurlnewwindow')

    // below line for Download PDF document  
    doc.save('myteamdetail.pdf');
  }

  exportTable() {
    console.log("Scheme 1111 :"+this.siCancelledRangeReportForm.value.schemeName);
    
    TableUtil.exportTableToExcel("ExampleMaterialTable",this.siCancelledRangeReportForm.value.schemeName);
  }

  
}
