import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SiCancelledRangeReportComponent } from './si-cancelled-range-report.component';

describe('SiCancelledRangeReportComponent', () => {
  let component: SiCancelledRangeReportComponent;
  let fixture: ComponentFixture<SiCancelledRangeReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SiCancelledRangeReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SiCancelledRangeReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
