import { Component, OnInit,ViewChild} from '@angular/core';
import {FormGroup, FormControl, Validators,FormBuilder, FormArray} from '@angular/forms';
import { MatTableDataSource} from '@angular/material/table';
import {MatPaginator} from '@angular/material/paginator';
// import Swal from 'sweetalert2';

@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.css']
})
export class ReportComponent implements OnInit {
  reportForm: FormGroup;
  selected;
  submitted = false;
  ELEMENT_DATA = [
    {user_name: 'John',link_desc: 'Access Control->User Management->Change Password'},
    {user_name: 'John',link_desc: 'ISGPay Transaction->Merchant Account Funding'},
    {user_name: 'John',link_desc: 'ISGPay Transaction->Refund Transactions'},
  ];
  
  displayedColumns: string[] = ['all','Sr No.', 'User Name', 'Link Description','Action'];
  dataSource = new MatTableDataSource(this.ELEMENT_DATA);
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;

  branch = [
    {value: 'Goregaon', viewValue: 'Goregaon'},
    {value: 'Malad', viewValue: 'Malad'},
  ];

  users = [
    {value: 'johnDoe', viewValue: 'johnDoe'},
    {value: 'johnDoe01', viewValue: 'johnDoe 01'},
  ];

  reports = [
    {value: 'User_Link_Report', viewValue: 'User Link Report'},
    {value: 'User_Profile_Report', viewValue: 'User Profile Report'},
  ];

  constructor(private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.formInit();
  }
  // convenience getters for easy access to form fields
  get f() { return this.reportForm.controls; }

  formInit(){
    this.reportForm = this.formBuilder.group({
      memberName: ["", Validators.required],
      branch:['', Validators.required],
      userName:['', Validators.required],
      report:['', Validators.required]
   });
  }

 
 onSubmit(form: FormGroup) {
  this.submitted = true;
if(form.invalid){
  return ;
}
console.log("form",form.value.report);
let index = this.reports.findIndex(key => key.value === form.value.report);
this.selected = this.reports[index].viewValue;
// this.reset();
}
reset(){
this.reportForm.reset(); 
this.formInit();
Object.keys(this.reportForm.controls).forEach(key => {
  this.reportForm.controls[key].setErrors(null);
});
this.submitted = false;
 this.selected ='';
}

}
