import { DailyTableUtil } from './Dailytable-util';

describe('DailyTableUtil', () => {
  it('should create an instance', () => {
    expect(new DailyTableUtil()).toBeTruthy();
  });
});
