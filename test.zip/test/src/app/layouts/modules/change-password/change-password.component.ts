import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, ValidatorFn, Validators, FormGroupDirective } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ChangePasswordService } from 'src/app/services/changepassword/change-password.service';
import Swal from 'sweetalert2';
import { LoginService } from 'src/app/services/subscribe/login.service';
import { formatCurrency, formatDate } from '@angular/common';
import { Router } from '@angular/router';
import { Login } from 'src/app/models/user/login';


@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {
  changePasswordForm: FormGroup;
  submitted = false;
  currentPassHide = false;
  newPassHide = false;
  confPassHide = false;
  userName = "";
  showflag = false;
  today = new Date();
  timesTamp = this.today.getTime();
  @ViewChild(FormGroupDirective)
  formGroupDirective: FormGroupDirective;

  constructor(private changePassword: ChangePasswordService, public service: LoginService, private route: ActivatedRoute, private router: Router) {
    this.route.queryParams.subscribe(params => {
      this.userName = params['username'];
      let d = new Date(params['d']);
      let d1 = new Date(this.timesTamp)
     
      var myDate = new Date( params['d'] *1000);
      this.showflag = myDate > d1 ? true : false
        });
  }

  ngOnInit(): void {
    if (!this.showflag) {
      Swal.fire({
        imageUrl: 'assets/images/warning.svg',
        text: 'Password link has been expired'
      })
    }
    this.initChangePasswordForm();

  }
  initChangePasswordForm() {
    this.changePasswordForm = new FormGroup({
      currentPassword: new FormControl('', [Validators.required]),
      newPassword: new FormControl('', [Validators.required]),
      confirmPassword: new FormControl('', [
        Validators.required,
        RetypeConfirm('newPassword'),

      ]),
    });
  }
  onSubmit() {

    if (this.changePasswordForm.invalid) {
      return;
    }


    let exp = new RegExp('.{8,20}');
    let matchExp = exp.exec(this.changePasswordForm.value.newPassword.toString())

    let flag = false //represent pattern is not matching

    if (matchExp != null) {
      exp = new RegExp("[a-z]{1,}")
      matchExp = exp.exec(this.changePasswordForm.value.newPassword.toString())


      if (matchExp != null) {
        exp = new RegExp("[A-Z]{1,}")
        matchExp = exp.exec(this.changePasswordForm.value.newPassword.toString())


        if (matchExp != null) {
          exp = new RegExp("[!@#$%^]{1,}")
          matchExp = exp.exec(this.changePasswordForm.value.newPassword.toString())


          if (matchExp != null) {
            exp = new RegExp("[0-9]{1,}")
            matchExp = exp.exec(this.changePasswordForm.value.newPassword.toString())

            if (matchExp == null)
              flag = true
          } else {

            flag = true
          }
        } else {

          flag = true
        }
      } else {

        flag = true
      }
    } else {

      flag = true
    }


    if (flag) {
      //alert("New Password Does Not Match Password Policy")
      Swal.fire({
        imageUrl: 'assets/images/warning.svg',
        text: 'New Password Does Not Match Password Policy'
      })
      this.formGroupDirective.resetForm();
      return
    } else {

      this.changePassword.changePassword(this.changePasswordForm.value, this.userName).subscribe((res) => {
        console.log("", res['msg'].msg)


        //this.router.navigate(['dashboard'])

        if (res['msg'].msg.trim() == "Old Password") {
          // alert("Old password is incorrect");
          Swal.fire({
            imageUrl: 'assets/images/warning.svg',
            text: 'Old password is incorrect'
          })
          this.formGroupDirective.resetForm();
        }
        else if (res['msg']['msg'].trim() == 'Please choose different password') {
          //alert("New password must be different than the last three passwords")
          Swal.fire({
            imageUrl: 'assets/images/warning.svg',
            text: 'New password must be different than the last three passwords'
          })
          this.formGroupDirective.resetForm();
        }
        else if (res['msg']['msg'].trim() == 'Not a Valid User') {
          //alert("User is not valid ")
          Swal.fire({
            imageUrl: 'assets/images/warning.svg',
            text: 'User is not valid'
          })
          this.formGroupDirective.resetForm();
        }
        else if (res['msg']['msg'].trim() == 'Password change') {
          //alert("New password has been updated successfully")
          Swal.fire({
            imageUrl: 'assets/images/checked_icon.svg',
            text: 'New password has been updated successfully'
          })
          this.formGroupDirective.resetForm();
        };


      });
    }

  }

}

function RetypeConfirm(new_password: string): ValidatorFn {
  return (control: FormControl) => {

    if (!control || !control.parent) {
      return null;
    }
    return control.parent.get(new_password).value === control.value ? null : { mismatch: true };
  };
}
