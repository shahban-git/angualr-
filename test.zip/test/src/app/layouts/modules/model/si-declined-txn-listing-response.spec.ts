import { SiDeclinedTxnListingResponse } from './si-declined-txn-listing-response';

describe('SiDeclinedTxnListingResponse', () => {
  it('should create an instance', () => {
    expect(new SiDeclinedTxnListingResponse()).toBeTruthy();
  });
});
