export class SiListingCancelledDateRequest {
    bankId : String;
    schemeName : String;
    fromDate : String;
}

