export class SiTxnListingResponse {
    tranID : String;
    //description : String;
    siRegistrationID: String;
    merchantId: String;
    cardNo: String;
    cardExpiryDate: String;
    authAmount: String;
    tranDateTime: String;
    txnStatus: String;
    reasonCode: String;
    transactionUpdatedDate: String;
    issuerBin: String;
    siCreateDate: String;
    active: String;
    siUpdateDate: String;
}
