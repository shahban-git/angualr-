import { SiTxnListingResponse } from './si-txn-listing-response';

describe('SiTxnListingResponse', () => {
  it('should create an instance', () => {
    expect(new SiTxnListingResponse()).toBeTruthy();
  });
});
