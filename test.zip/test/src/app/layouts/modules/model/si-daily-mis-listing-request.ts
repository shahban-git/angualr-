export class SiListingRequest {
    bankId : String;
    dayschemeName  : String;
    fromDate : String;
    toDate : String;
    formonth: String

}
