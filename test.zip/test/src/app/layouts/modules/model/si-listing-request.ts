export class SiListingRequest {
    bankId : String;
    schemeName : String;
    fromDate : String;
    toDate : String; 
}
