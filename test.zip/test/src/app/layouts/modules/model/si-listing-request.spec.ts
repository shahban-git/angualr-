import { SiListingRequest } from './si-listing-request';

describe('SiListingRequest', () => {
  it('should create an instance', () => {
    expect(new SiListingRequest()).toBeTruthy();
  });
});
