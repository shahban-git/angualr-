export class SiDeclinedTxnListingResponse {

    tranID : String;
    description : String;
    
    tranDateTime: String;
    transactionUpdatedDate: String;


}
