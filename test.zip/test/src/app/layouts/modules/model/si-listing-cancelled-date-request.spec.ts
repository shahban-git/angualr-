import { SiListingCancelledDateRequest } from './si-listing-cancelled-date-request';

describe('SiListingCancelledDateRequest', () => {
  it('should create an instance', () => {
    expect(new SiListingCancelledDateRequest()).toBeTruthy();
  });
});
