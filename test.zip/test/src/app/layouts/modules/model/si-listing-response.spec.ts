import { SiListingResponse } from './si-listing-response';

describe('SiListingResponse', () => {
  it('should create an instance', () => {
    expect(new SiListingResponse()).toBeTruthy();
  });
});
