export class SiListingResponse {
    merchantId :String;
    tid:String;
    siCreateDate: String;
    authAmt:String;
    siRegistrationID : String;
    merchantName : String;
    issuerBin : String;
    siMinimumAmount : String;                                            
    siMaximumAmount : String;
    siNoOfSITxns : String;
    siPreferredInitiationDate : String;
    siFrequency : String;
    siStatus : String;
}

