export class SiTxnListingResponse {
    fromDate: String;
    toDate: String;
    forMonth: String;
    card: String;
    register_SUCCESS:String;
    register_DECLINE: String;
    intimation_SUCCESS: String;
    intimation_DECLINE: String;
    txn_SUCCESS: String;
    txn_DECLINE:String;
    notifi_COUNT: String;
    modification_COUNT:String;
    cancelation_COUNT: String;  
}

// export class SiTxnListingResponse {
//         tranID : String;
//         //description : String;
//         siRegistrationID: String;
//         merchantId: String;
//         cardNo: String;
//         cardExpiryDate: String;
//         authAmount: String;
//         tranDateTime: String;
//         txnStatus: String;
//         reasonCode: String;
//         transactionUpdatedDate: String;
//         issuerBin: String;
//         siCreateDate: String;
//         active: String;
//         siUpdateDate: String;
//     }
    
