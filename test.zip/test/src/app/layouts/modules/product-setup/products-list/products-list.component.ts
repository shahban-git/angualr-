import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder, FormArray } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { ProductService } from 'src/app/services/master/product.service';
import { MatPaginator } from '@angular/material/paginator';
// import Swal from 'sweetalert2';

import Swal from 'sweetalert2';
import { FilterModel } from 'src/app/models/filter';
import { BankView } from 'src/app/models/bank/bank-view';
import { ProductView } from 'src/app/models/product/product';
import { ActivatedRoute, Router } from '@angular/router';
import { Route } from '@angular/compiler/src/core';


@Component({
  selector: 'app-products-list',
  templateUrl: './products-list.component.html',
  styleUrls: ['./products-list.component.css']
})
export class ProductsListComponent implements OnInit {
  dynamicForm: FormGroup;
  selected;
  showErrorMes
  submitted = false;
  productSetUpMes
  viewAllProducts = true;
  productList = false;
  productSave = false;
  crudPriv: number;
  totalCount: number;
  isAdmin: Number;
  searchKey: string;
  @Output() nameEvent = new EventEmitter<any>();

  filterModel: FilterModel = new FilterModel();
  filterModel1: FilterModel = new FilterModel();
  @Input() userNameFromParent = '';
  isInterchange: Boolean;

  //   banks_data =[{member_name:'AXIS Bank',products:3},
  //   {member_name:'HDFC Bank',products:3},
  // ]

  displayedColumns_list: string[] =[ 'Product Name', 'Business Type', 'created date', 'status'];
  //dataSource_list = new MatTableDataSource(this.banks_data);
  dataSourceL: MatTableDataSource<BankView>;

  displayedColumns: string[] = [ 'Product Name', 'Sub Product Name', 'Action'];
  dataSource: MatTableDataSource<ProductView>;



  @ViewChild('paginator') paginator: MatPaginator;
  subdata: any;
  prodId: any;
  constructor(
    private formBuilder: FormBuilder, private service: ProductService, private router: Router,
    private route: ActivatedRoute
  ) {
    this.filterModel = {
      name: '',
      page: 0,
      size: 5
    };
    this.filterModel1 = {
      name: '',
      page: 0,
      size: 5
    }
  }


  formErrors = {
    'businessType': '',
    'productName': ''
  };
  validationMessages = {
    'businessType': { 'required': 'Business Type is required', 'pattern': 'Special characters and Digits not allowed' },
    'productName': { 'required': 'Product Name is required', 'pattern': 'Special characters and Digits not allowed' }
  }

  ngOnInit(): void {
    this.crudPriv = +localStorage.getItem('cdPms');
    this.isAdmin = +localStorage.getItem('vf');
    this.refreshProductList(this.filterModel);
  }


  refreshProductList(pageParams) {
    this.service.getProductList(pageParams).subscribe((data) => {
      console.log("rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr",data);
      if(data['statusCode']=="R048"){
        if(data["data"]['content'].length>0){
          this.dataSourceL = new MatTableDataSource(data["data"]['content']);
          this.totalCount = data["data"]['totalElements']
        }
        else{
          this.dataSourceL=null;
          this.productSetUpMes="No Records Found."
        }
      }
      else{
        this.dataSourceL=null;
        this.productSetUpMes=data['statusDesc']
      }
    
      //this.dataSourceL.paginator = this.paginator;
    },(error)=>{
      this.dataSourceL=null;
      this.productSetUpMes="Server Not Responding, Please Try Again Later."
    });
  }

  saveData(e, productId) {
    this.dataSourceL.filteredData.filter(ele => ele["productId"] == productId)
    console.log(this.dataSourceL.filteredData.filter(ele => ele["productId"] == productId))
    let productName = this.dataSourceL.filteredData.filter(ele => ele["productId"] == productId)[0]['productName']
    let businessType = this.dataSourceL.filteredData.filter(ele => ele["productId"] == productId)[0]['businessType']
    let subProductName = []
    for (let index = 0; index < this.dataSource.filteredData.length; index++) {
      const element = this.dataSource.filteredData[index]['subProductName'];
      subProductName.push(element);

    }
    this.prodId = productId
    e.preventDefault();
    let data = {

      "productName": productName,
      "subProductName": subProductName,
      "businessType": businessType,
    }
    this.formInit(data);
  }
  formInit(value) {
    this.productList = false;
    this.productSave = true;
    // this.dynamicForm = this.formBuilder.group({
    //   memberBank: [this.userNameFromParent],
    //   productName: [value.productName],
    // });
    // if (value.productName == 'Interchange') {
    //   this.isInterchange = true;
    //   this.router.navigate(['dashboard/product-setup/icm-page'], { queryParams: { entid: value.entityId } });
    // }
    this.dynamicForm = this.formBuilder.group({
      businessType: [value.businessType, Validators.compose([Validators.required, Validators.pattern(/^[ A-Za-z]+$/)])],
      productName: [value.productName, Validators.compose([Validators.required, Validators.pattern(/^[ A-Za-z]+$/)])],
      businessTypes: new FormArray([]),
    });
    this.subdata = value.subProductName
    this.addBusiness();
  }
  addBusiness() {
    // data.push('')

    for (let index = 0; index < this.subdata.length; index++) {
      let fg = this.formBuilder.group({
        subProductName: [this.subdata[index], Validators.required],
      });
      (<FormArray>this.dynamicForm.get('businessTypes')).push(fg);

    }




    let userIndex =
      (<FormArray>this.dynamicForm.get('businessTypes')).length - 1;
  }

  addBusiness1() {
    // data.push('')

    let fg = this.formBuilder.group({
      subProductName: ['', Validators.required],
    });
    (<FormArray>this.dynamicForm.get('businessTypes')).push(fg);

  }
  get f() {
    return this.dynamicForm.controls;
  }
  get b() {
    return this.f.businessTypes as FormArray;
  }
  logValidationErrors(group: FormGroup = this.dynamicForm): void {
    Object.keys(group.controls).forEach((key: string) => {
      const abstractControl = group.get(key);
      this.formErrors[key] = '';
      if (abstractControl && !abstractControl.valid && (abstractControl.touched || abstractControl.dirty)) {
        const message = this.validationMessages[key];
        for (const err in abstractControl.errors) {
          if (err) {
            console.log('err , key ', err, key);
            this.formErrors[key] = message[err] + ' ';
          }
        }
      }
      if (abstractControl instanceof FormGroup) {
        this.logValidationErrors(abstractControl);
      }
    });
  }

  deleteBusiness(index: number) {
    (<FormArray>this.dynamicForm.get('businessTypes')).removeAt(index);
  }
  onSubmit(form: FormGroup) {
    if (form.invalid) {
      form.markAllAsTouched()
      this.logValidationErrors();
      return;
    }

    this.submitted = true;
    let subProductName = []
    for (let index = 0; index < form.value.businessTypes.length; index++) {
      const element = form.value.businessTypes[index]["subProductName"];
      subProductName.push(element)
    }

    let data = {
      prodId: this.prodId,
      "productName": form.value.productName,
      "subProductName": subProductName,
      "businessType": form.value.businessType
    }

    this.service.updateProduct(data).subscribe((data) => {
      console.log("productsetupppppppedit",data);
      if(data['statusCode']=="R044"){
        Swal.fire({
          imageUrl: 'assets/images/checked_icon.svg',
          text: 'Product has been updated successfully.',
        })
        this.viewAllProducts = true;
        this.productList = false;
        this.productSave = false;
        this.refreshProductList(this.filterModel);
      }
      else{
        Swal.fire({
          imageUrl: 'assets/images/warning.svg',
          text: data['statusDesc']
        })
      }
    
    },(error)=>{
      Swal.fire({
        imageUrl: 'assets/images/warning.svg',
        text: "Server Not Responding, Please Try Again Later."
      })
    });
  }

  cancel() {
    this.dynamicForm.reset();
    this.dynamicForm.markAsPristine();
    this.dynamicForm.markAsUntouched();
    this.dynamicForm.updateValueAndValidity();
    this.submitted = false;
    this.viewAllProducts = true;
    this.productList = false;
    this.productSave = false;
    this.refreshProductList(this.filterModel);
  }

  passElement(e, element, e1) {
    console.log(element)
    this.userNameFromParent = e1;
    e.preventDefault();
    this.viewAllProducts = false;
    this.productList = true;
    this.getProductView(element, this.filterModel1);
  }
  srcData;
  getProductView(bankName, pageParams) {
    this.service.viewSubListProduct(bankName, pageParams).subscribe(
      data => {
        console.log("PPP  ", data);
        if(data['statusCode']=="R044"){
          this.srcData=data["data"]
          this.dataSource = new MatTableDataSource(data["data"]);
          this.totalCount = data["data"].length;
        }
        else{
          this.dataSource=null;
          this.showErrorMes="No Records Found."
        }
      
        //this.dataSource.paginator = this.paginator;
      },(errror)=>{
        this.dataSource=null;
          this.showErrorMes="Server Not Responding, Please Try Again Later."
      }
    )
  }
  paginatorClick(pageNum: Number) {
    this.filterModel.page = pageNum['pageIndex'];
    this.filterModel.size = pageNum['pageSize'];
    this.refreshProductList(this.filterModel);

  }
  paginatorSubClick(pageNum: Number) {
    // this.filterModel1.page = pageNum['pageIndex'];
    // this.filterModel1.size = pageNum['pageSize'];
    // this.getProductView(this.userNameFromParent, this.filterModel1);

  }
  back() {
    this.viewAllProducts = true;
    this.productList = false;
    this.productSave = false;
    this.refreshProductList(this.filterModel);
  }

  onSearch(event: Event) {
    this.paginator.firstPage();
    this.filterModel.name = (event.target as HTMLInputElement).value
    this.filterModel.page = 0;
    this.filterModel.size = 5;
    this.refreshProductList(this.filterModel);

  }

  applyFilter() {
    // this.dataSource.filter = this.searchKey.trim().toLowerCase();
    if(this.searchKey==""){
      this.dataSource=this.srcData
    }
    else{
    console.log("uuuuuuuuu",this.dataSource)

      if(this.dataSource!=null){
        // if(this.dataSource.filter!=""){
          this.dataSource.filter = this.searchKey.trim().toLowerCase();
          if(this.dataSource.filteredData){
          if(this.dataSource.filteredData.length==0){
            this.dataSource=null;
            this.showErrorMes="No Records Found."
          }
        }
          else if(this.dataSource.filter!=""){
            this.dataSource=null;
            this.showErrorMes="No Records Found."
          }
        // }
      
        }
    }
    
  }

  onSearchClear() {
    this.searchKey = '';
    this.applyFilter();
  }
}
