import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import {
  FormGroup,
  FormControl,
  Validators,
  FormBuilder,
  FormArray,
} from '@angular/forms';
import { Router } from '@angular/router';
import { ProductService } from 'src/app/services/master/product.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {
  dynamicForm: FormGroup;
  submitted = false;
  count = 0;
  @Output() nameEvent = new EventEmitter<any>();
  formErrors = {
    'businessType': '',
    'productName': ''
  };
  validationMessages = {
    'businessType': { 'required': 'Business Type is required', 'pattern': 'Special characters and Digits not allowed' },
    'productName': { 'required': 'Product Name is required', 'pattern': 'Special characters and Digits not allowed' }
  }

  constructor(private formBuilder: FormBuilder, private service: ProductService, private router: Router) { }
  
  ngOnInit(): void {
    this.formInit();
    this.dynamicForm.valueChanges.subscribe(data => {
      this.logValidationErrors(this.dynamicForm);
    })
  }

  formInit() {
    this.dynamicForm = this.formBuilder.group({
      businessType: ['', Validators.compose([Validators.required, Validators.pattern(/^[ A-Za-z]+$/)])],
      productName: ['', Validators.compose([Validators.required, Validators.pattern(/^[ A-Za-z]+$/)])],
      businessTypes: new FormArray([]),
    });
    this.addBusiness();
  }
  // convenience getters for easy access to form fields
  get f() {
    return this.dynamicForm.controls;
  }
  get b() {
    return this.f.businessTypes as FormArray;
  }
 

  addBusiness() {
    let fg = this.formBuilder.group({
      subProductName: ['', Validators.required],
    });
    (<FormArray>this.dynamicForm.get('businessTypes')).push(fg);
    let userIndex =
      (<FormArray>this.dynamicForm.get('businessTypes')).length - 1;
  }

  logValidationErrors(group: FormGroup = this.dynamicForm): void {
    Object.keys(group.controls).forEach((key: string) => {
      const abstractControl = group.get(key);
      this.formErrors[key] = '';
      if (abstractControl && !abstractControl.valid && (abstractControl.touched || abstractControl.dirty)) {
        const message = this.validationMessages[key];
        for (const err in abstractControl.errors) {
          if (err) {
            console.log('err , key ', err, key);
            this.formErrors[key] = message[err] + ' ';
          }
        }
      }
      if (abstractControl instanceof FormGroup) {
        this.logValidationErrors(abstractControl);
      }
    });
  }

  deleteBusiness(index: number) {
    (<FormArray>this.dynamicForm.get('businessTypes')).removeAt(index);
  }

  onSubmit(form: FormGroup) {
    if (form.invalid) {
      form.markAllAsTouched()
      this.logValidationErrors();
      return;
    }

    this.submitted = true;
    let subProductName = []
    for (let index = 0; index < form.value.businessTypes.length; index++) {
      const element = form.value.businessTypes[index]["subProductName"];
      subProductName.push(element)
    }

    let data = {
      "productName": form.value.productName,
      "subProductName": subProductName,
      "businessType": form.value.businessType
    }
   
    this.service.saveProduct(data).subscribe((data) => {
      console.log("onsubmitttttaddd",data);
      if(data['statusCode']=="R041"){
        Swal.fire({
          imageUrl: 'assets/images/checked_icon.svg',
          text: 'Product has been saved successfully.',
        })
        this.router.navigate(['dashboard/product-setup'])
      }
      else{
        Swal.fire({
          imageUrl: 'assets/images/warning.svg',
          text: data['statusDesc']
        })

      }
     
    },(error)=>{
      Swal.fire({
        imageUrl: 'assets/images/warning.svg',
        text: "Server Not Responding, Please Try Again Later."
      })
    });
  }

  reset() {
    this.dynamicForm.reset();
    this.dynamicForm.markAsPristine();
    this.dynamicForm.markAsUntouched();
    this.dynamicForm.updateValueAndValidity();
    this.submitted = false;
  }

}


