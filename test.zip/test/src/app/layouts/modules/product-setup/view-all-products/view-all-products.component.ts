import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-all-products',
  templateUrl: './view-all-products.component.html',
  styleUrls: ['./view-all-products.component.css']
})
export class ViewAllProductsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
