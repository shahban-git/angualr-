import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder, FormArray } from '@angular/forms';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { ZoneCreate } from 'src/app/models/zone/zone-create';
import { ZoneService } from 'src/app/services/master/zone.service';

@Component({
  selector: 'app-add-zone',
  templateUrl: './add-zone.component.html',
  styleUrls: ['./add-zone.component.css']
})
export class AddZoneComponent implements OnInit {

  addZoneForm: FormGroup;
  zoneCreate: ZoneCreate;
  submitted = false;
  bankList;
  countryList;
  entityId;
  zone: ZoneCreate = new ZoneCreate()
  constructor(private formBuilder: FormBuilder, private service: ZoneService, private router: Router) { }

  ngOnInit(): void {
    this.entityId = localStorage.getItem('entityId');
    this.formInit();
    this.fetchBank();
    this.fetchCountry();
  }
  formInit() {
    this.addZoneForm = this.formBuilder.group({
      bank: ["", Validators.required],
      zoneName: ['', Validators.required],
      zoneEntity: [{ entityId: this.entityId }],
      country: ['', Validators.required],

    });
  }
  // convenience getters for easy access to form fields
  get f() { return this.addZoneForm.controls; }

  onSubmit(form: FormGroup) {
    //--------------------
    this.submitted = true;
    this.zone = form.value
    // this.zone.bank = {
    //   bankId: form.value['bank']
    // }
    let data = {
      bank: { bankId: form.value.bank },
      zoneEntity: { entityId: this.entityId },
      country: { cntId: form.value.country },
      zoneName: form.value.zoneName
    }
    if (form.invalid) {
      return
    }
    else {
      this.service.createZone(data).subscribe(res => {

        console.log("resulttttttttttttttttttt",res);
        if(res['statusCode']=="R089"){
          Swal.fire({
            imageUrl: 'assets/images/checked_icon.svg',
            text: 'Zone has been saved successfully'
          })

          this.router.navigate(['dashboard'])
        }
        else{
          Swal.fire({
            imageUrl: 'assets/images/warning.svg',
            text: res['statusDesc']
          })
        }
        // if (res['Save Zone'] ==undefined) {
        //   Swal.fire({
        //     imageUrl: 'assets/images/warning.svg',
        //     text: res['msg']['msg']
        //   })

        // } else {
        //   Swal.fire({
        //     imageUrl: 'assets/images/checked_icon.svg',
        //     text: 'Zone has been saved successfully'
        //   })

        //   this.router.navigate(['dashboard'])
        // }
        // form.reset();
      },
      (error)=>{
        Swal.fire({
          imageUrl: 'assets/images/warning.svg',
          text: "Server Not Responding, Please Try Again Later."
        })
      });
    }
    //-------------------
  }
  reset() {
    this.addZoneForm.reset();
    this.addZoneForm.markAsPristine();
    this.addZoneForm.markAsUntouched();
    this.addZoneForm.updateValueAndValidity();
    this.submitted = false;
  }

  fetchBank() {
    this.service.fetchBankList().subscribe((res) => {
      // this.bankList = res['Bank DropDown'];
      if(res['statusCode']=="R112"){
        this.bankList = res['data'];
      }
    });
  }

  fetchCountry() {
    this.service.fetchCountryList().subscribe((res) => {
      // this.countryList = res['Country DropDown'];
      if(res['statusCode']=="R128"){

      } this.countryList = res['data'];
   
    });
  }

}
