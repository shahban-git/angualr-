import {
  Component,
  OnInit,
  ViewChild,
  Output,
  EventEmitter,
} from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { Router } from '@angular/router';
import { FilterModel } from 'src/app/models/filter';
import { ZoneService } from 'src/app/services/master/zone.service';
import { ZoneView } from 'src/app/models/zone/zone-view';

@Component({
  selector: 'app-view-zone',
  templateUrl: './view-zone.component.html',
  styleUrls: ['./view-zone.component.css']
})
export class ViewZoneComponent implements OnInit {

  @Output() nameEvent = new EventEmitter<any>();
  crudPriv: number;
  viewZoneMes;
  displayedColumns: string[] = [
    
    'member name',
    'zones',
    'create date',
    'status'
  ];
  filterModel: FilterModel = new FilterModel();
  totalCount: number;
  dataSource: MatTableDataSource<ZoneView>;
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;

  constructor(private router: Router, private service: ZoneService) {
    this.filterModel = {
      name: '',
      page: 0,
      size: 5
    }
  }

  ngOnInit(): void {
    this.crudPriv = +localStorage.getItem('cdPms');
    this.refreshBranchList(this.filterModel);
  }

  passName(e, element, type) {
    e.preventDefault();
    this.nameEvent.emit({ name: element, type: type, category: 'zone' });
  }

  refreshBranchList(pageParams) {
    this.service.getZoneList(pageParams).subscribe((data) => {
      console.log(data);
      if(data['statusCode']=="R088"){
        if(data['data']['content'].length>0){
          this.dataSource = new MatTableDataSource(data["data"]["content"]);
          this.totalCount = data["data"]['totalElements'];
        }
        else{
          this.dataSource=null;
          this.viewZoneMes="No Records Found"
        }
      }
      else{
        this.dataSource=null;
        this.viewZoneMes=data['statusDesc']
      }
     
    },(error)=>{
      this.dataSource=null;
      this.viewZoneMes="Server Not Responding, Please Try Again Later."
    });
  }

  paginatorClick(pageNum: Number) {
    this.filterModel.page = pageNum['pageIndex'];
    this.filterModel.size = pageNum['pageSize'];
    this.refreshBranchList(this.filterModel);
  }

  onSearch(event: Event) {
    this.paginator.firstPage();
    this.filterModel.name = (event.target as HTMLInputElement).value
    this.filterModel.page = 0;
    this.filterModel.size = 5;
    this.refreshBranchList(this.filterModel);
  }
}

