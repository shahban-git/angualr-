import { Component, OnInit ,Input,ViewChild, Output, EventEmitter} from '@angular/core';
import { MatTableDataSource} from '@angular/material/table';
import {MatPaginator} from '@angular/material/paginator';
import { DepartmentView } from 'src/app/models/department/department-view';
import { FilterModel } from 'src/app/models/filter';
import { ZoneService } from 'src/app/services/master/zone.service';


@Component({
  selector: 'app-bank-zone',
  templateUrl: './bank-zone.component.html',
  styleUrls: ['./bank-zone.component.css']
})
export class BankZoneComponent implements OnInit {
  @Output() nameEvent = new EventEmitter<any>();
  @Input() userNameFromParent;
  crudPriv : number;
  bankZoneMes

  displayedColumns: string[] = [ 'member name', 'Zones', 'create date','status','action'];
  dataSource :  MatTableDataSource<DepartmentView>;
  totalCount: number;
  filterModel: FilterModel = new FilterModel();
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  constructor(private service : ZoneService) {
    this.filterModel = {
      name : '',
      page: 0,
      size: 5
    };
  }

  ngOnInit(): void {
    this.crudPriv = +localStorage.getItem('cdPms');
    this.userNameFromParent = JSON.parse(this.userNameFromParent);
    this.getZoneView(this.userNameFromParent, this.filterModel);

  }
  back(){
    this.nameEvent.emit({name:"",type:"",category:'zone'});
  }

  getZoneView(bankName : string, pageParams)
  {
    this.service.viewSubListZone(bankName.trim(), pageParams).subscribe(
      data => {
      console.log("sssssssssssssss",data);
      if(data['statusCode']=="R097"){
        if(data['data']['content'].length>0){
          this.dataSource = new MatTableDataSource(data["data"]['content']);
          this.totalCount = data["data"]['totalElements'];
        }
        else{
          this.dataSource=null;
          this.bankZoneMes="No Record Found."
        }
      }
      else{
        this.dataSource=null;
        this.bankZoneMes=data['statusDesc']
      }
       
        //this.dataSource.paginator = this.paginator;
      },(error)=>{
        this.dataSource=null;
        this.bankZoneMes="Server Not Responding, Please Try Again Later."
      }
    )
  }
  paginatorClick(pageNum: Number) {
    this.filterModel.page = pageNum['pageIndex'];
    this.filterModel.size = pageNum['pageSize'];
    this.getZoneView(this.userNameFromParent, this.filterModel);

  }

  onSearch(event: Event) {
    this.paginator.firstPage();
    this.filterModel.name = (event.target as HTMLInputElement).value
    this.filterModel.page = 0;
    this.filterModel.size = 5;
    this.getZoneView(this.userNameFromParent, this.filterModel);
  }

  passName(e, element, type) {
    e.preventDefault();
    this.nameEvent.emit({ name: element, type: type, category: 'zone' });
  }
}
