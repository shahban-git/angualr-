import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BankZoneComponent } from './bank-zone.component';

describe('BankZoneComponent', () => {
  let component: BankZoneComponent;
  let fixture: ComponentFixture<BankZoneComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BankZoneComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BankZoneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
