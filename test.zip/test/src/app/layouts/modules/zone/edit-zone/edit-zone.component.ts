import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder, FormArray } from '@angular/forms';
import { Router } from '@angular/router';
import { ZoneCreate } from 'src/app/models/zone/zone-create';
import { ZoneService } from 'src/app/services/master/zone.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-edit-zone',
  templateUrl: './edit-zone.component.html',
  styleUrls: ['./edit-zone.component.css']
})
export class EditZoneComponent implements OnInit {
  @Output() cancelEvent = new EventEmitter<any>();
  @Input() userNameFromParent: string;
  addZoneForm: FormGroup;
  zoneCreate: ZoneCreate;
  submitted = false;
  bankList;
  countryList;
  entityId;
  zone: ZoneCreate = new ZoneCreate()
  constructor(private formBuilder: FormBuilder, private service: ZoneService, private router: Router) { }

  ngOnInit(): void {
    console.log(this.userNameFromParent)
    this.entityId = localStorage.getItem('entityId');
    this.formInit();
    this.fetchBank();
    this.fetchCountry();
    this.getZoneId();
  }
  formInit() {
    this.addZoneForm = this.formBuilder.group({
      bank: ["", Validators.required],
      zoneName: ['', Validators.required],
      zoneEntity: [{ entityId: this.entityId }],
      country: ['', Validators.required],

    });
  }
  // convenience getters for easy access to form fields
  get f() { return this.addZoneForm.controls; }

  onSubmit(form: FormGroup) {
    //--------------------
    this.submitted = true;
    this.zone = form.value
    // this.zone.bank = {
    //   bankId: form.value['bank']
    // }
    let data = {
      bank: { bankId: form.value.bank },
      zoneEntity: { entityId: this.entityId },
      country: { cntId: form.value.country },
      zoneName: form.value.zoneName,
      zoneId:this.userNameFromParent
    }
    if (form.invalid) {
      return
    }
    else {
      this.service.updateZone(data).subscribe(res => {
        if(res['statusCode']=="R090"){
          Swal.fire({
            imageUrl: 'assets/images/checked_icon.svg',
            text: 'Zone has been updated successfully'
          })

          this.router.navigate(['dashboard'])
        }
        else{
          Swal.fire({
            imageUrl: 'assets/images/warning.svg',
            text: res['statusDesc']
          })
        }
        
      },(error)=>{
        Swal.fire({
          imageUrl: 'assets/images/warning.svg',
          text:"Server Not Responding, Please Try Again Later."
        })
      });
    }
    //-------------------
  }
  cancel(){
    this.cancelEvent.emit({name:" ",type:"cancel",category:'zone'});
  }


  fetchBank() {
    this.service.fetchBankList().subscribe((res) => {
        if(res['statusCode']=="R112"){
          this.bankList = res['data'];
        }
    });
  }

  fetchCountry() {
    this.service.fetchCountryList().subscribe((res) => {
  
        if(res['statusCode']=="R128"){

        } this.countryList = res['data'];
     
    });
  }

  getZoneId() {
    this.service.getZoneId(this.userNameFromParent).subscribe((res) => {
      console.log("zonebyidsdddddddddddd",res)
      if(res['statusCode']=="R092"){
        res['data']["body"];
        this.addZoneForm.patchValue({
          bank:res['data']["body"]['bank']['bankId'] ,
          zoneName:res['data']["body"]['zoneName'],
          zoneEntity: [{ entityId: res['data']["body"]['bank']['bankEntity']['entityId'] }],
          country: res['data']["body"]['country']['cntId'],
        })
      }
   
    });
  }

}
