import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CertificationViewComponent } from './certification-view.component';

describe('CertificationViewComponent', () => {
  let component: CertificationViewComponent;
  let fixture: ComponentFixture<CertificationViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CertificationViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CertificationViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
