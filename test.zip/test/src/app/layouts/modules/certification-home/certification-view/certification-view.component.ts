import { Component, OnInit,ViewChild } from '@angular/core';

@Component({
  selector: 'app-certification-view',
  templateUrl: './certification-view.component.html',
  styleUrls: ['./certification-view.component.css']
})
export class CertificationViewComponent implements OnInit {

   certiDetail=true;certiView= false;
   certiApprove=false;
   member;
   view;
  constructor() { }

  ngOnInit(): void {
    this.view =+localStorage.getItem('vf');
    if(this.view==1){
    this.certiView=true;this.certiDetail=false;this.certiApprove=false;
    this.member=JSON.stringify(localStorage.getItem('bank'));
    }
  }

   nameEventHander($event: any) {
	   console.log("nameEventHander",$event)
	  this.member = JSON.stringify($event.name);
	   console.log("nameEventHander",this.member)
	   if($event.type == 'showDetail'){

		   this.certiView = true;this.certiDetail=false;this.certiApprove=false;
	   }
	   else if($event.type == 'showApprove'){
		   this.certiView = false;this.certiDetail=false;this.certiApprove=true;
	   }else{
      this.certiView = false;this.certiDetail=true;this.certiApprove=false;
     }
   }

}
