import { Component, OnInit,Input,Output, EventEmitter, ViewChild} from '@angular/core';
import { MatTableDataSource} from '@angular/material/table';
import {MatPaginator} from '@angular/material/paginator';
import {FormGroup, FormControl, Validators,FormBuilder} from '@angular/forms';
import {SelectionModel} from '@angular/cdk/collections';
import Swal from 'sweetalert2';
import {MatMenuTrigger} from  '@angular/material/menu';
import { CertificationView } from 'src/app/models/certification/certification-view';
import { CertificationService } from 'src/app/services/certification/certification-service';
import { FilterModel } from 'src/app/models/filter';
import { Location } from '@angular/common';
@Component({
  selector: 'app-certification',
  templateUrl: './certification.component.html',
  styleUrls: ['./certification.component.css']
})
export class CertificationComponent implements OnInit {
 @ViewChild(MatMenuTrigger) trigger: MatMenuTrigger;
  isEmpty = false;
  submitted = false;
  @Input() userNameFromParent;
  @Output() nameEvent = new EventEmitter<any>();
  
  displayedColumns: string[] = ['Member Name', 'Master Name', 'Maker Name','Maker Date','Maker Remark','Previous State','Current State','Checker Date','Checker Remark','action'];
  dataSource : MatTableDataSource<CertificationView>;
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  selection = new SelectionModel<any>(true, []);
  form: FormGroup;
  dataUser;
  totalCount: number;
  crudPriv : number;
  filterModel: FilterModel = new FilterModel();
  // apiUrl = 'https://jsonplaceholder.typicode.com/todos';
  constructor(private service : CertificationService,private location: Location) { 
    this.filterModel = {
      name : '',
      page: 0,
      size: 5
    };
  }

 ngOnInit():void {
   console.log("%%%%%%%%%%%%%%%%%%")
   this.userNameFromParent=JSON.parse(this.userNameFromParent);
  this.crudPriv = +localStorage.getItem('cdPms');
  this.getCertView(this.userNameFromParent, this.filterModel);

  }
  getCertView (bankName : string, pageParams)
  {
    console.log("responseeeeeeeeeee")
    this.service.viewSubListCert(bankName.trim(), pageParams).subscribe(
      data => {
        console.log("dataaaaaaaaaaaaaa",data)
        this.dataSource = new MatTableDataSource(data["data"]['content']);
        this.totalCount = data["data"]['totalElements'];
        //this.dataSource.paginator = this.paginator;
      }
    )
  }
  onSubmit(form:FormGroup){

  }

   /** Whether the number of selected elements matches the total number of rows. */
   isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
        this.selection.clear() :
        this.dataSource.data.forEach(row => this.selection.select(row));
  }

  close(){

      this.trigger.closeMenu();

  }
  logSelection() {
    console.log("selected element",this.selection.selected.length);
    this.selection.selected.forEach(s => console.log(s.member_name));
    if(this.selection.selected.length > 0 && this.selection.selected.length <=1){
      Swal.fire({
        imageUrl:'assets/images/rejected.svg',
        input: 'text',
        inputAttributes: {
          autocapitalize: 'off',
          placeholder:'Reason for reject application',
          confirmButtonText:'save'
        },
        customClass:{
          popup: 'custom-popup'
        },
        preConfirm:(value) => {
          if(!value){
            Swal.showValidationMessage(
              `Reason for reject application is required`
            )
          }
        }
      }).then((result) => {
        /* Read more about handling dismissals below */
        if (result.isConfirmed) {
          console.log('confirmed')
          console.log(result);
        }
      });
    }else if(this.selection.selected.length > 1){
      Swal.fire({
        imageUrl:'assets/images/warning.svg',
        text:'You cannot delete multiple certifications at a time.Please select ONLY ONE certification.',

      })
    }
  }
   passName($event,value){
    console.log('On certify icon ' + value)
	  $event.preventDefault();
	  this.nameEvent.emit({name:value,type:'showApprove'});
  }
  back(){
    this.nameEvent.emit({name:this.userNameFromParent,type:''});
  }
  // returnToPrevious(){
  //   // this.router.navigate()
  //   this.location.back();

  // }

  //delete data
  deleteData(e,value){
    e.preventDefault();
    Swal.fire({
      imageUrl:'assets/images/question_mark.svg',
      text:'Are you sure you want to delete '+value+' ?',
      showCancelButton: true,
      confirmButtonText:'Yes',
      cancelButtonText:'No'
    }).then((result) => {
      if(result.isConfirmed) {
        Swal.fire({
          imageUrl:'assets/images/checked_icon.svg',
          text:value +'has been deleted successfully.'
        })
      }
    });
  }

  paginatorClick(pageNum: Number) {
    this.filterModel.page = pageNum['pageIndex'];
    this.filterModel.size = pageNum['pageSize'];
    this.getCertView(this.userNameFromParent, this.filterModel);

  }
}
