import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CertificationApproveComponent } from './certification-approve.component';

describe('CertificationApproveComponent', () => {
  let component: CertificationApproveComponent;
  let fixture: ComponentFixture<CertificationApproveComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CertificationApproveComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CertificationApproveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
