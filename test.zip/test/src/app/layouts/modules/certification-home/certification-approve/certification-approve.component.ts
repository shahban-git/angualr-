import {
  Component,
  OnInit,
  Output,
  EventEmitter,
  Input,
  ViewChildren,
  QueryList,
  ElementRef,
} from '@angular/core';
import {
  FormGroup,
  FormControl,
  Validators,
  FormBuilder,
  FormArray,
} from '@angular/forms';
import { Certify } from 'src/app/models/certification/certify';
import { CertificationService } from 'src/app/services/certification/certification-service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-certification-approve',
  templateUrl: './certification-approve.component.html',
  styleUrls: ['./certification-approve.component.css']
})
export class CertificationApproveComponent implements OnInit {
selectedUser: any;
  users: any;
  @ViewChildren('filterInput') filterInput: QueryList<ElementRef>;
  dynamicForm: FormGroup;
  @Input() userNameFromParent;
  @Output() nameEvent = new EventEmitter<any>();
  masterName;
  submitted=false;
  certify : Certify[] = [] ;
  constructor(
    private formBuilder: FormBuilder, private service : CertificationService

  ) {}


  ngOnInit(): void {
	   this.formInit();
  }
   formInit() {
     this.userNameFromParent =JSON.parse(this.userNameFromParent);
    //console.log("userNameFromParent ",JSON.parse(this.userNameFromParent));
    this.masterName = this.userNameFromParent['bankName'];
    if(this.masterName == 'Role Master'){
      this.dynamicForm = this.formBuilder.group({
        memberBank: [this.userNameFromParent['bankName']],
        roles: new FormArray([]),
      });

      this.getRoleNumber(1);
    }
    else{
      this.dynamicForm = this.formBuilder.group({
        memberBank: [this.userNameFromParent['bankName']],
        designation: ['developer'],
      });
    }

  }

  get f() {
    return this.dynamicForm.controls;
  }

  get t() {
    return this.f.roles as FormArray;
  }

   onOpen() {
    this.filterInput.changes.subscribe((res) => {
      this.filterInput.first.nativeElement.focus();
    });
  }
  customSearchFn(term: string, item: any) {
    console.log('term', term);
    console.log('item', item);
    term = term.toLocaleLowerCase();
    return item.toLocaleLowerCase().indexOf(term) > -1;

  }

   getRoleNumber(e) {
    //console.log("function",this.t);
    const numberOfProducts = e || 0;
    if (this.t.length < numberOfProducts) {
      for (let i = this.t.length; i < numberOfProducts; i++) {
        this.t.push(
          this.formBuilder.group({
            roleName: ["", Validators.required],
            selectedUser: ['', Validators.required],
            rolePrivWrite: new FormControl(false),
            rolePrivRead: new FormControl(false),
            rolePrivDelete: new FormControl(false),
            rolePrivEdit: new FormControl(false),
          })
        );
      }
    } else {
      for (let i = this.t.length; i >= numberOfProducts; i--) {
        this.t.removeAt(i);
      }
    }
  }
cancel(){
  this.nameEvent.emit({name:this.userNameFromParent['bankName'],type:'showDetail'});
}
onSubmit(form){
  console.log("aprroveeeeeeeeeee")
  this.nameEvent.emit({name:this.userNameFromParent['bankName'],type:'showDetail'});
  
  var cert = new Certify();
  cert.accept = 1
  cert.trailId = this.userNameFromParent['trailId']
  cert.remarks = "Approved"
  cert.masterName = this.userNameFromParent['masterProdcutName']
  console.log("Cert  " , cert)
  this.certify.push(cert)
  //console.log("To Certify ", this.userNameFromParent['masterProdcutName'])
  this.service.doCertify(this.certify);
  Swal.fire({
    imageUrl: 'assets/images/checked_icon.svg',
      text:this.masterName +' has been certified successfully.',
    })
    // this.ngOnInit()
    // .then((result) => {
    //   if(result.isConfirmed) {
    //     this.nameEvent.emit({name:this.userNameFromParent['member_name'],type:'showDetail'});
    //   }
    // });
}

reject(){
  Swal.fire({
    imageUrl:'assets/images/rejected.svg',
    input: 'text',
    inputAttributes: {
      autocapitalize: 'off',
      placeholder:'Reason for reject application',
      confirmButtonText:'save'
    },
    customClass:{
      popup: 'custom-popup'
    },
    preConfirm:(value) => {
      if(!value){
        Swal.showValidationMessage(
          `Reason for reject application is required`
        )
      }
    }
  }).then((result) => {
    /* Read more about handling dismissals below */
    if (result.isConfirmed) {
      console.log('confirmed')
      console.log(result);
      this.nameEvent.emit({name:this.userNameFromParent['bankName'],type:'showDetail'});
    }
  });
}

}
