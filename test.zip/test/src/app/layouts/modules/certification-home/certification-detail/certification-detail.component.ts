import { Component, OnInit,ViewChild,Output, EventEmitter } from '@angular/core';
import { MatTableDataSource} from '@angular/material/table';
import {MatPaginator} from '@angular/material/paginator';
import {MatMenuTrigger} from  '@angular/material/menu';
import { BankView } from 'src/app/models/bank/bank-view';
import { FilterModel } from 'src/app/models/filter';
import { CertificationService } from 'src/app/services/certification/certification-service';

@Component({
  selector: 'app-certification-detail',
  templateUrl: './certification-detail.component.html',
  styleUrls: ['./certification-detail.component.css']
})
export class CertificationDetailComponent implements OnInit {
	@ViewChild(MatMenuTrigger) trigger: MatMenuTrigger;
	@Output() nameEvent = new EventEmitter<any>();
  productSave=false;
  crudPriv: number;
  totalCount: number;
  certificateMes;
  filterModel: FilterModel = new FilterModel();
  displayedColumns: string[] = ['Member Name', 'pending requests'];
  dataSource :  MatTableDataSource<BankView>;
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  constructor(private service : CertificationService) { 
    this.filterModel = {
      name : '',
      page: 0,
      size: 5
    };
  }

  ngOnInit(): void {
    this.crudPriv = +localStorage.getItem('cdPms');
    this.refreshCertList(this.filterModel);
  }
  passName($event,value){
	  $event.preventDefault();
	  this.nameEvent.emit({name:value,type:'showDetail'});
  }

  refreshCertList(pageParams)
  {
    this.service.getCertList(pageParams).subscribe((data) => {

      console.log("certificateeeeeeeeeeeee",data);
      if(data['statusCode']=="R0525"){
        if(data["data"]['content'].length > 0){
          this.dataSource = new MatTableDataSource(data["data"]['content']);
          this.totalCount = data["data"]['totalElements'];
        }
        else{
          this.dataSource = null;
          this.certificateMes = "No Records Found";
        }
      }
      else{
        this.dataSource = null;
        this.certificateMes = data['statusDesc'];
      }
   
      
      //this.dataSource.paginator = this.paginator;
    },(error)=>{
      this.dataSource = null;
      this.certificateMes ="Server Not Responding Please Try Again Later.";
    });
  }
  paginatorClick(pageNum: Number) {
    this.filterModel.page = pageNum['pageIndex'];
    this.filterModel.size = pageNum['pageSize'];
    this.refreshCertList(this.filterModel);

  }
  onSearch(event: Event) {
    this.paginator.firstPage();
    this.filterModel.name = (event.target as HTMLInputElement).value
    this.filterModel.page = 0;
    this.filterModel.size = 5;
    this.refreshCertList(this.filterModel);
  
  }

}
