import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder, FormArray } from '@angular/forms';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { RegionService } from 'src/app/services/master/region.service';
import { RegionCreate } from 'src/app/models/region/region-create';

@Component({
  selector: 'app-add-region',
  templateUrl: './add-region.component.html',
  styleUrls: ['./add-region.component.css']
})
export class AddRegionComponent implements OnInit {

  addRegionForm: FormGroup;
  regionCreate: RegionCreate;
  submitted = false;
  bankList;
  @Output() nameEvent = new EventEmitter<any>();
  zoneList;
  countryList;
  entityId;
  region: RegionCreate = new RegionCreate()
  constructor(private formBuilder: FormBuilder, private service: RegionService, private router: Router) { }

  ngOnInit(): void {
    this.entityId = localStorage.getItem('entityId');
    this.formInit();
    this.fetchBank();
    this.fetchCountry();
  }
  formInit() {
    this.addRegionForm = this.formBuilder.group({
      bank: ["", Validators.required],
      zone: ['', Validators.required],
      regionName: ['', Validators.required],
      regionEntity: [{ entityId: this.entityId }],
      country: ['', Validators.required],

    });
  }
  // convenience getters for easy access to form fields
  get f() { return this.addRegionForm.controls; }

  onSubmit(form: FormGroup) {
    //--------------------
    this.submitted = true;
    this.region = form.value
    // this.zone.bank = {
    //   bankId: form.value['bank']
    // }
    let data = {
      bank: { bankId: form.value.bank },
      regionEntity: { entityId: this.entityId },
      zone:{ zoneId: form.value.zone },
      country: { cntId: form.value.country },
      regionName: form.value.regionName
    }
    if (form.invalid) {
      return
    }
    else {
      this.service.createRegion(data).subscribe(res => {
        console.log("00000000000",res)
        if(res['statusCode']=="R077"){
          Swal.fire({
            imageUrl: 'assets/images/checked_icon.svg',
            text: 'Region has been saved successfully'
          })
          this.nameEvent.emit({name:"",type:"",category:'region'});

          this.router.navigate(['dashboard'])
        }
        else {
          Swal.fire({
            imageUrl: 'assets/images/warning.svg',
            text: res['statusDesc']
          })
        }
        // form.reset();
      },(error)=>{
        Swal.fire({
          imageUrl: 'assets/images/warning.svg',
          text:"Server Not Responding, Please Try Again Later."
        })
      });
    }
    //-------------------
  }
  reset() {
    this.addRegionForm.reset();
    this.addRegionForm.markAsPristine();
    this.addRegionForm.markAsUntouched();
    this.addRegionForm.updateValueAndValidity();
    this.submitted = false;
  }

  fetchBank() {
    this.service.fetchBankList().subscribe((res) => {
     
      if(res['statusCode']=="R112"){
        this.bankList = res['data'];
      }
    });
  }

  fetchZone(bankId) { 
    this.service.fetchZoneList(bankId).subscribe((res) => {
      console.log("fetchhhhzoneeeeeee",res)
        if(res['statusCode']=="R096"){
          this.zoneList = res['data'];
        }
     
    });
  }

  fetchCountry() {
    this.service.fetchCountryList().subscribe((res) => {
      if(res['statusCode']=="R128"){
        this.countryList = res['data'];
      }
      
    });
  }

}
