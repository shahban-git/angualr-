import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder, FormArray } from '@angular/forms';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { RegionService } from 'src/app/services/master/region.service';
import { RegionCreate } from 'src/app/models/region/region-create';

@Component({
  selector: 'app-edit-region',
  templateUrl: './edit-region.component.html',
  styleUrls: ['./edit-region.component.css']
})
export class EditRegionComponent implements OnInit {
  @Output() cancelEvent = new EventEmitter<any>();
  @Input() userNameFromParent: string;

  addRegionForm: FormGroup;
  regionCreate: RegionCreate;
  submitted = false;
  bankList;
  zoneList;
  countryList;
  entityId;
  region: RegionCreate = new RegionCreate()
  zonename: any;
  constructor(private formBuilder: FormBuilder, private service: RegionService, private router: Router) { }

  ngOnInit(): void {
    this.entityId = localStorage.getItem('entityId');
    this.formInit();
    this.fetchBank();
    this.fetchCountry();
    this.getRegionId();
  }
  formInit() {
    this.addRegionForm = this.formBuilder.group({
      bank: ["", Validators.required],
      zone: ['', Validators.required],
      regionName: ['', Validators.required],
      regionEntity: [{ entityId: this.entityId }],
      country: ['', Validators.required],

    });
  }
  // convenience getters for easy access to form fields
  get f() { return this.addRegionForm.controls; }

  onSubmit(form: FormGroup) {
    //--------------------
    this.submitted = true;
    this.region = form.value
    // this.zone.bank = {
    //   bankId: form.value['bank']
    // }
    let data = {
      bank: { bankId: form.value.bank },
      regionEntity: { entityId: this.entityId },
      zone:{ zoneId: form.value.zone },
      country: { cntId: form.value.country },
      regionName: form.value.regionName,
      regionId:this.userNameFromParent
    }
    if (form.invalid) {
      return
    }
    else {
      this.service.updteRegion(data).subscribe(res => {
        console.log("submittttttttttt",res)
        if(res["statusCode"]=="R078"){
          Swal.fire({
            imageUrl: 'assets/images/checked_icon.svg',
            text: 'Region has been updated successfully'
          })

          this.router.navigate(['dashboard'])
        }
       else{
        Swal.fire({
          imageUrl: 'assets/images/warning.svg',
          text: res['statusDesc']
        })
       }
      },(error)=>{
        Swal.fire({
          imageUrl: 'assets/images/warning.svg',
          text: "Server Not Responding, Please Try Again Later."
        })
      });
    }
    //-------------------
  }
  cancel(){
    this.cancelEvent.emit({name:" ",type:"cancel",category:'region'});
  }


  fetchBank() {
    this.service.fetchBankList().subscribe((res) => {
      
      if(res['statusCode']=="R112"){
        this.bankList = res['data'];
      }
    });
  }

  fetchZone(bankId) { 
    this.service.fetchZoneList(bankId).subscribe((res) => {
      if(res['statusCode']=="R096"){
        this.zoneList = res['data'];
        this.addRegionForm.patchValue({
          zone:this.zonename,
  
        })
      }
     
    });
  }

  fetchCountry() {
    this.service.fetchCountryList().subscribe((res) => {
      if(res['statusCode']=="R128"){
        this.countryList = res['data'];

      }
    });
  }

  getRegionId() {
    this.service.getRegionId(this.userNameFromParent).subscribe((res) => {
      if(res['statusCode']=="R080"){
        this.fetchZone(res['data']["body"]['bank']['bankId'])
        this.zonename=res['data']["body"]['zone']['zoneId']
        this.addRegionForm.patchValue({
          bank:res['data']["body"]['bank']['bankId'] ,
          regionName:res['data']["body"]['regionName'],
          regionEntity: [{ entityId: res['data']["body"]['bank']['bankEntity']['entityId'] }],
          country: res['data']["body"]['country']['cntId'],
        })
      }
     
    });
  }

}
