import {
  Component,
  OnInit,
  ViewChild,
  Output,
  EventEmitter,
} from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { Router } from '@angular/router';
import { FilterModel } from 'src/app/models/filter';
import { RegionService } from 'src/app/services/master/region.service';
import { RegionView } from 'src/app/models/region/region-view';

@Component({
  selector: 'app-region-view',
  templateUrl: './region-view.component.html',
  styleUrls: ['./region-view.component.css']
})
export class RegionViewComponent implements OnInit {

  @Output() nameEvent = new EventEmitter<any>();
  crudPriv: number;
  regionViewMes
  displayedColumns: string[] = [
  
    'member name',
    'regions',
    'create date',
    'status'
  ];  filterModel: FilterModel = new FilterModel();
  totalCount: number;
  dataSource: MatTableDataSource<RegionView>;
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;

  constructor(private router: Router, private service: RegionService) {
    this.filterModel = {
      name: '',
      page: 0,
      size: 5
    }
  }

  ngOnInit(): void {
    this.crudPriv = +localStorage.getItem('cdPms');
    this.refreshBranchList(this.filterModel);
  }

  passName(e, element, type) {
    e.preventDefault();
    this.nameEvent.emit({ name: element, type: type, category: 'region' });
  }

  refreshBranchList(pageParams) {
    this.service.getRegionList(pageParams).subscribe((data) => {
      console.log("regionnnnnnnnnnnnn",data);
        if(data['statusCode']=="R076"){
          if(data['data']['content'].length>0){
            this.dataSource = new MatTableDataSource(data["data"]["content"]);
            this.totalCount = data["data"]['totalElements'];
          }
          else{
            this.dataSource=null;
            this.regionViewMes="No Record Found."
          }
        }
        else{
          this.dataSource=null;
          this.regionViewMes=data['statusDesc']
        }
     
    },(error)=>{
      this.dataSource=null;
      this.regionViewMes="Server Not Responding, Please Try Again Later."
    });
  }

  paginatorClick(pageNum: Number) {
    this.filterModel.page = pageNum['pageIndex'];
    this.filterModel.size = pageNum['pageSize'];
    this.refreshBranchList(this.filterModel);
  }

  onSearch(event: Event) {
    this.paginator.firstPage();
    this.filterModel.name = (event.target as HTMLInputElement).value
    this.filterModel.page = 0;
    this.filterModel.size = 5;
    this.refreshBranchList(this.filterModel);
  }
}


