import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BankRegionComponent } from './bank-region.component';

describe('BankRegionComponent', () => {
  let component: BankRegionComponent;
  let fixture: ComponentFixture<BankRegionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BankRegionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BankRegionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
