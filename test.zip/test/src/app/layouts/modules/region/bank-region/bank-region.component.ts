import { Component, OnInit ,Input,ViewChild, Output, EventEmitter} from '@angular/core';
import { MatTableDataSource} from '@angular/material/table';
import {MatPaginator} from '@angular/material/paginator';
import { FilterModel } from 'src/app/models/filter';
import { RegionService } from 'src/app/services/master/region.service';

@Component({
  selector: 'app-bank-region',
  templateUrl: './bank-region.component.html',
  styleUrls: ['./bank-region.component.css']
})
export class BankRegionComponent implements OnInit {
  @Output() nameEvent = new EventEmitter<any>();
  @Input() userNameFromParent;
  crudPriv : number;
  bankRegionMes

  displayedColumns: string[] = [ 'member name','zones', 'regions', 'create date','status','action'];
  dataSource :  MatTableDataSource<any>;
  totalCount: number;
  filterModel: FilterModel = new FilterModel();
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  constructor(private service : RegionService) {
    this.filterModel = {
      name : '',
      page: 0,
      size: 5
    };
  }

  ngOnInit(): void {
    this.crudPriv = +localStorage.getItem('cdPms');
    this.userNameFromParent = JSON.parse(this.userNameFromParent);
    this.getRegionView(this.userNameFromParent, this.filterModel);

  }
  back(){
    this.nameEvent.emit({name:"",type:"",category:'region'});
  }

  getRegionView(bankName : string, pageParams)
  {
    this.service.viewSubListRegion(bankName.trim(), pageParams).subscribe(
      data => {
        console.log("regionbankkkkkkkkkk",data);
        if(data['statusCode']=="R086"){
          if(data["data"]['content'].length>0){
            this.dataSource = new MatTableDataSource(data["data"]['content']);
            this.totalCount = data["data"]['totalElements'];
          }
          else{
            this.dataSource=null;
            this.bankRegionMes="No Records Found."
          }
        }
        else{
          this.dataSource=null;
          this.bankRegionMes=data['statusDesc']
        }
        
        //this.dataSource.paginator = this.paginator;
      },(error)=>{
        this.dataSource=null;
        this.bankRegionMes="Server Not Responding, Please Try Again Later."
      }
    )
  }
  paginatorClick(pageNum: Number) {
    this.filterModel.page = pageNum['pageIndex'];
    this.filterModel.size = pageNum['pageSize'];
    this.getRegionView(this.userNameFromParent, this.filterModel);

  }

  onSearch(event: Event) {
    this.paginator.firstPage();
    this.filterModel.name = (event.target as HTMLInputElement).value
    this.filterModel.page = 0;
    this.filterModel.size = 5;
    this.getRegionView(this.userNameFromParent, this.filterModel);
  }

  passName(e, element, type) {
    e.preventDefault();
    this.nameEvent.emit({ name: element, type: type, category: 'region' });
  }
}
