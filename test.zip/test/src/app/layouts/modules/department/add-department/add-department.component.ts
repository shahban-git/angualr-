import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import {FormGroup, FormControl, Validators,FormBuilder, FormArray} from '@angular/forms';
import { DeptDesigDTO } from 'src/app/models/department/DeptDesigDTO';
import { DepartmentService } from 'src/app/services/master/dept.service';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-add-department',
  templateUrl: './add-department.component.html',
  styleUrls: ['./add-department.component.css']
})
export class AddDepartmentComponent implements OnInit {
  dynamicForm: FormGroup;
  @Output() nameEvent = new EventEmitter<any>();
  deptDesig : DeptDesigDTO;

  bankList;
  validationErrorMes:boolean=false;
  

  entityId;

  submitted = false;
  constructor(private formBuilder: FormBuilder, private service : DepartmentService, private router : Router) { }

  ngOnInit(): void {
    this.entityId = localStorage.getItem('entityId');
    this.formInit();
    this.fetchBank();
  }
  formInit(){
    this.dynamicForm = this.formBuilder.group({
      deptDesigBank : ['', Validators.required],
      designationList : new FormArray([]),
      departmentList : new FormArray([])
   });
   this.addMoreDept(1);
   this.addMoreDesgn(1);
  }
  // convenience getters for easy access to form fields
  get f() { return this.dynamicForm.controls; }

  get t() { return this.f.departmentList as FormArray; }

  get d() { return this.f.designationList as FormArray; }

//   getProductNumber(e) {
//     //console.log("function",this.t);
//     const numberOfProducts = e || 0;
//     if (this.t.length < numberOfProducts) {
//         for (let i = this.t.length; i < numberOfProducts; i++) {
//             this.t.push(this.formBuilder.group({
//               // name: ['', Validators.required],
//               deptName: ['', Validators.required],
//             }));
//         }
//     } else {
//         for (let i = this.t.length; i >= numberOfProducts; i--) {
//             this.t.removeAt(i);
//         }
//     }
// }
addMoreDept(number){
  this.t.push(this.formBuilder.group({
    // name: ['', Validators.required],
    //deptBank : [{bankId : 1316}],
    deptEntity : [{entityId : this.entityId}],
    deptName: ['', Validators.required],
  }));
}
addMoreDesgn(number){
  this.d.push(this.formBuilder.group({
    // name: ['', Validators.required],
    //bank : [{bankId : 1316}],
    entityBean : [{entityId : this.entityId}],
    desigName: ['', Validators.required],
  }));
}


removeDept(i) {
  // this.addresses.removeAt(i);
  this.t.removeAt(i)
}
removeDesignation(i){
  this.d.removeAt(i)
}

fetchBank() {
  this.service.fetchBankList().subscribe((res) => {
 
      if(res['statusCode']=="R112"){
        this.bankList = res['data'];
      }
    console.log("departmentttttt",res)
    
  });
}
onSubmit(form: FormGroup) {
  

  if (form.invalid) {
    form.markAllAsTouched()
    this.validationErrorMes=true;
    this.submitted = true;
    //this.logValidationErrors();
    return;
  }
  this.submitted = false;
  this.validationErrorMes=false;
  this.deptDesig = this.dynamicForm.value
  this.deptDesig.deptDesigBank = {
    bankId : form.value['deptDesigBank']
  }
  

  this.service.createDeptDesig(this.deptDesig).subscribe(res => {
    if(res['statusCode']=="R062"){
      
      Swal.fire({
        imageUrl : 'assets/images/checked_icon.svg',
        text: 'Department/Designation has been saved successfully'
      })
      setTimeout(() => {
        console.log("66666666666",this.deptDesig);
       
        },2000)
      this.router.navigate(['dashboard'])
    }
    else{
      Swal.fire({
        imageUrl: 'assets/images/warning.svg',
        text: res['statusDesc']
      })
    }
   
  },(error)=>{
    Swal.fire({
      imageUrl: 'assets/images/warning.svg',
      text: "Server Not Responding, Please Try Again Later."
    })
  });
}
reset(){
  this.dynamicForm.reset();
  this.formInit();
}



}
