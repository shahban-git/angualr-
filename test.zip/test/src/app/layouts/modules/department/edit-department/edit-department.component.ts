import { Component, OnInit ,Input,Output, EventEmitter} from '@angular/core';
import {FormGroup, FormControl, Validators,FormBuilder, FormArray} from '@angular/forms';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-edit-department',
  templateUrl: './edit-department.component.html',
  styleUrls: ['./edit-department.component.css']
})
export class EditDepartmentComponent implements OnInit {
  @Output() cancelEvent = new EventEmitter<any>();
  @Input() userNameFromParent: string;
  dynamicForm: FormGroup;

  submitted = false;

  constructor(private formBuilder: FormBuilder) { }


  ngOnInit(): void {
    console.log("yyyyyyyyyyyyyyyyyyyyy",this.userNameFromParent)
    this.dynamicForm = this.formBuilder.group({
      memberName: [this.userNameFromParent, Validators.required],
      products: new FormArray([])
   });
   this.getProductNumber(4);
  }

   // convenience getters for easy access to form fields
   get f() { return this.dynamicForm.controls; }
   
   get t() { return this.f.products as FormArray; }

   getProductNumber(e) {
    //console.log("function",this.t);
    const numberOfProducts = e || 0;
    if (this.t.length < numberOfProducts) {
        for (let i = this.t.length; i < numberOfProducts; i++) {
            this.t.push(this.formBuilder.group({
              // name: ['', Validators.required],
              deptName: ['', Validators.required],
            }));
        }
    } else {
        for (let i = this.t.length; i >= numberOfProducts; i--) {
            this.t.removeAt(i);
        }
    }
}
addMore(number){
  this.t.push(this.formBuilder.group({
    // name: ['', Validators.required],
    deptName: ['', Validators.required],
  }));
}
onSubmit(form: FormGroup) {
  this.submitted = true;
    if(form.invalid){
      return ;
    }
    Swal.fire({
      imageUrl: 'assets/images/checked_icon.svg',
      text: 'Department data has been saved successfully.'
    })
}
cancel(){
  this.cancelEvent.emit({name:" ",type:"cancel",category:'department'});
}
}
