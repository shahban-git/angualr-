import { Component, OnInit ,Input,ViewChild, Output, EventEmitter} from '@angular/core';
import { MatTableDataSource} from '@angular/material/table';
import {MatPaginator} from '@angular/material/paginator';
import { DepartmentService } from 'src/app/services/master/dept.service';
import { DepartmentView } from 'src/app/models/department/department-view';
import { FilterModel } from 'src/app/models/filter';

@Component({
  selector: 'app-bank-department',
  templateUrl: './bank-department.component.html',
  styleUrls: ['./bank-department.component.css']
})
export class BankDepartmentComponent implements OnInit {
  @Output() nameEvent = new EventEmitter<any>();
  @Input() userNameFromParent;
  crudPriv : number;
  sublinksMes

  displayedColumns: string[] = [ 'member name', 'departments', 'create date','status'];
  dataSource :  MatTableDataSource<DepartmentView>;
  totalCount: number;
  filterModel: FilterModel = new FilterModel();
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  constructor(private service : DepartmentService) {
    this.filterModel = {
      name : '',
      page: 0,
      size: 5
    };
  }

  ngOnInit(): void {
    this.crudPriv = +localStorage.getItem('cdPms');
    this.userNameFromParent = JSON.parse(this.userNameFromParent);
    this.getDeptView(this.userNameFromParent, this.filterModel);

  }
  back(){
    this.nameEvent.emit({name:"",type:"",category:'department'});
  }

  getDeptView(bankName : string, pageParams)
  {
    this.service.viewSubListDept(bankName.trim(), pageParams).subscribe(
      data => {
      console.log("sublinkssssssss",data)
      statusCode: ""
      statusDesc: "Department Sub-List"
      if(data['statusCode']=="R061"){
        if(data['data']['content'].length>0){
          this.dataSource = new MatTableDataSource(data["data"]['content']);
          this.totalCount = data["data"]['totalElements'];
        }
        else{
          this.dataSource=null;
          this.sublinksMes="No Records Found"
        }
      }
      else{
        this.dataSource=null;
        this.sublinksMes=data['statusDesc']
      }
     
        //this.dataSource.paginator = this.paginator;
      },(error)=>{
        this.dataSource=null;
        this.sublinksMes="Server Not Responding, Please Try Again Later."
      }
    )
  }
  paginatorClick(pageNum: Number) {
    this.filterModel.page = pageNum['pageIndex'];
    this.filterModel.size = pageNum['pageSize'];
    this.getDeptView(this.userNameFromParent, this.filterModel);

  }

  onSearch(event: Event) {
    this.paginator.firstPage();
    this.filterModel.name = (event.target as HTMLInputElement).value
    this.filterModel.page = 0;
    this.filterModel.size = 5;
    this.getDeptView(this.userNameFromParent, this.filterModel);
  }
}
