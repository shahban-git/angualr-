import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BankDepartmentComponent } from './bank-department.component';

describe('BankDepartmentComponent', () => {
  let component: BankDepartmentComponent;
  let fixture: ComponentFixture<BankDepartmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BankDepartmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BankDepartmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
