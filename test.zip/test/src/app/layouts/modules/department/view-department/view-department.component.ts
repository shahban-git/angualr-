import {
  Component,
  OnInit,
  ViewChild,
  Output,
  EventEmitter,
} from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { BankView } from 'src/app/models/bank/bank-view';
import { DepartmentService } from 'src/app/services/master/dept.service';
import { FilterModel } from 'src/app/models/filter';

@Component({
  selector: 'app-view-department',
  templateUrl: './view-department.component.html',
  styleUrls: ['./view-department.component.css'],
})
export class ViewDepartmentComponent implements OnInit {
  @Output() nameEvent = new EventEmitter<any>();
  crudPriv: number;
  viewDepartmentMes
  displayedColumns: string[] = [
    // 'all',
    'member name',
    'departments',
    'create date',
    'status',
    'action',
  ];
  dataSource: MatTableDataSource<BankView>;
  totalCount: number;
  filterModel: FilterModel = new FilterModel();
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;

  constructor(private service: DepartmentService) {
    this.filterModel = {
      name : '',
      page: 0,
      size: 5
    };
  }

  ngOnInit(): void {
    this.crudPriv = +localStorage.getItem('cdPms');
    this.refreshDeptList(this.filterModel);
  }
  passName(e, element, type) {
    e.preventDefault();
    console.log("llllllllllllllllllllllll",element,type)
    this.nameEvent.emit({ name: element,
       type: type, category: 'department' });
  }
  refreshDeptList(pageParams) {
    this.service.getDeptList(pageParams).subscribe((data) => {
      
      if(data['statusCode']=="R053"){
        if(data["data"]['content'].length>0){
          this.dataSource = new MatTableDataSource(data["data"]['content']);
          this.totalCount = data["data"]['totalElements']
        }
        else{
          this.dataSource = null;
          this.viewDepartmentMes="No Records Found"
        }
       

      }
      else{
        this.dataSource = null;
        this.viewDepartmentMes= data['statusDesc']
      }
     
      //this.dataSource.paginator = this.paginator;
    },(error)=>{
      this.dataSource = null;
      this.viewDepartmentMes="Server Not Responding, Please Try Again Later."
    });
  }
  paginatorClick(pageNum: Number) {
    this.filterModel.page = pageNum['pageIndex'];
    this.filterModel.size = pageNum['pageSize'];
    this.refreshDeptList(this.filterModel);

  }
  onSearch(event: Event) {
    this.paginator.firstPage();
    this.filterModel.name = (event.target as HTMLInputElement).value
    this.filterModel.page = 0;
    this.filterModel.size = 5;
    this.refreshDeptList(this.filterModel);
  
  }
}
