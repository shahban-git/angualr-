import { Component, OnInit, Output, EventEmitter, ViewChild } from '@angular/core';
import {
  FormGroup, 
  FormControl,
  Validators,
  FormBuilder,
  FormGroupDirective,
} from '@angular/forms';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { Login } from 'src/app/models/user/login';
// import { HttpDataServiceService } from 'src/app/services/common/http-data-service.service';
import { LoginService } from 'src/app/services/subscribe/login.service';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;

  @Output() loginEvent = new EventEmitter<any>();
  @ViewChild(FormGroupDirective)
  formGroupDirective : FormGroupDirective;

  private loggedinUser = false;

  submitted = false;
  showHide = true;
  private unsubscribe: Subject<void> = new Subject();
  private intervalId: any;
  login: Login;

  viewList: number[];

  crudPerms: number;
  err="Server Not Responding, Please Try Again Later."
  isAdmin : number;
  entityId : number;
  constructor(
    private formBuilder: FormBuilder,
    public service: LoginService,
    public router: Router,
  ) {
    this.login = new Login();
  }

  ngOnInit(): void {
    
    this.loginForm = this.formBuilder.group({
      userName: ['', [Validators.required]],
      password: ['', [Validators.required]],
    });
    if(this.service.isUserLoggedIn())
    {
      this.router.navigate(['dashboard']);
    }
    else{

    }
  }
  get f() {
    return this.loginForm.controls;
  }
  onSubmit() {
    this.submitted = true;
    if (this.loginForm.invalid) {
      return;
    }
this.service.onLogin(this.loginForm.value).subscribe((res) => {
    if (res.statusCode == "R001") {
     console.log("jjjjjjjjjjjjjjj")
    this.loggedinUser = true;
    localStorage.setItem('currentUser', 'loggedin');
    let tokenStr = res.data.token;
    let tokenRecieved = {
      token: tokenStr,
    };
    this.service.startTimer();
    this.service.storeDataInSession( res.data);
    this.service.afterLoginView(tokenRecieved).subscribe((res) => {
      console.log("ttttttttttttttttttt",res)
      this.viewList = res.data.linkValues;
      this.crudPerms = res.data.crudPriv;
      this.isAdmin = res.data.isAdmin;
      this.entityId = res.data.entityId;
  let bankName = res.data.bankName;
      localStorage.setItem('entityId', this.entityId.toString());
      localStorage.setItem('linkValues', this.viewList.toString());
      localStorage.setItem('cdPms', this.crudPerms.toString());
      localStorage.setItem('vf',this.isAdmin.toString());
      localStorage.setItem('bank',bankName.toString());
      this.router.navigate(['dashboard']);
    });
  } 
  else  {
    console.log("eroooooooooooooo")
    Swal.fire({
      imageUrl: 'assets/images/warning.svg',
      text: res['statusDesc']
    })
  }

}
,(error)=>{
  console.log("eeeeeeeeee")
  Swal.fire({
    imageUrl: 'assets/images/warning.svg',
    text: "Server Not Responding, Please Try Again Later."
  })
}
);
  }




  forgotPassword(){
    console.log('link');
    
    this.loginForm.reset()
    this.showHide = false;
    this.loginForm.setControl('userName', new FormControl('',[Validators.required]));
    this.loginForm.setControl('password', new FormControl(''));
  }
  onForgotPassword(){
    
    if (this.loginForm.invalid) {
      return;
    }
    else{
    this.service.forgot_password(this.loginForm.value).subscribe(res => {
          this.formGroupDirective.resetForm();      
      if(res['msg'].msgType=="ERROR"){

        Swal.fire({
          imageUrl : 'assets/images/warning.svg',
          text: res["msg"].msg,
        })
      }else{

        Swal.fire({
          imageUrl : 'assets/images/checked_icon.svg',
          text: 'User password link has been sent to register email'
        })
      }
      
    }, (error) => {
      alert("Server Not Responding, Please Try Again Later.");
    })
  }
  }

  loginCheck() {
    this.loginForm.reset()
    this.showHide = true;
    this.loginForm.setControl('userName', new FormControl('',[Validators.required]));
    this.loginForm.setControl('password', new FormControl('',[Validators.required]));

  }
}
