import {
  Component,
  OnInit,
  Output,
  EventEmitter,
  Input,
  ViewChildren,
  QueryList,
  ElementRef,
} from '@angular/core';
import {
  FormGroup,
  FormControl,
  Validators,
  FormBuilder,
  FormArray,
} from '@angular/forms';
import { requireCheckboxesToBeCheckedValidator } from './../require-checkboxes-to-be-checked.validator';
import Swal from 'sweetalert2';
import { RoleNew } from 'src/app/models/roles/role-new';
import {RoleView} from 'src/app/models/roles/role-view'
import { RoleServiceService } from 'src/app/services/role/role-service.service';

@Component({
  selector: 'app-edit-role',
  templateUrl: './edit-role.component.html',
  styleUrls: ['./edit-role.component.css'],
})
export class EditRoleComponent implements OnInit {
  @Output() cancelEvent = new EventEmitter<any>();
  @Input() userNameFromParent: string;

  selectedUser: any;
  users : any;
  @ViewChildren('filterInput') filterInput: QueryList<ElementRef>;
  dynamicForm: FormGroup;
  bankEditForm: FormGroup;
  roleList: RoleNew = new RoleNew();
  roles = [
    {
      rights: [{ create: true, read: false, delete: false, edit: false }],
      roleName: ['adam', 'nicole', 'alba'],
    },
    {
      rights: [{ create: true, read: true, delete: false, edit: false }],
      roleName: ['adam', 'nicole'],
    },
  ];
  submitted = false;

  dropdownList = [];
  selectedItems = [];
  dropdownSettings = {};

  constructor(private formBuilder: FormBuilder,private service: RoleServiceService) {}

  // search dropdown

  onOpen() {
    this.filterInput.changes.subscribe((res) => {
      this.filterInput.first.nativeElement.focus();
    });
  }
  customSearchFn(term: string, item: any) {
    term = term.toLocaleLowerCase();
    return item.toLocaleLowerCase().indexOf(term) > -1;
    //return this.users.indexOf(term) > -1
  }
  ngOnInit(): void {
    this.roleList = JSON.parse(this.userNameFromParent);
    console.log('In NGINIT ',this.roleList);

    this.dynamicForm = this.formBuilder.group({
      bankName: [this.roleList.roleBank, Validators.required],
      roles: new FormArray([]),
    });
    this.fetchLinks();
    this.getRoleNumber(this.roleList.roles);
    //this.selectedUser =[this.users[0].id]
  }

  // convenience getters for easy access to form fields
  get f() {
    return this.dynamicForm.controls;
  }

  get t() {
    return this.f.roles as FormArray;
  }
  onSubmit(form: FormGroup) {
    this.submitted = true;
    if (form.invalid) {
      return;
    }
    Swal.fire({
      imageUrl: 'assets/images/checked_icon.svg',
      text: 'Role data has been saved successfully.',
    });
  }
  getRoleNumber(roles) {
    const roleCount = this.roleList.roles.length;
    if (this.t.length < roleCount) {
      for (let i = this.t.length; i < roleCount; i++) {
        console.log('edit', roles[i].rolePrivEdit);
        this.t.push(
          this.formBuilder.group({
            role: [roles[i].roleName, Validators.required],
            selectedUser: [roles[i].roleName, Validators.required],
            myCheckboxGroup: new FormGroup(
              {
                create: new FormControl(roles[i].rolePrivWrite),
                read: new FormControl(roles[i].rolePrivRead),
                delete: new FormControl(roles[i].rolePrivDelete),
                edit: new FormControl(roles[i].rolePrivEdit),
              },
              requireCheckboxesToBeCheckedValidator()
            ),
          })
        );
      }
    } else {
      for (let i = this.t.length; i >= roleCount; i--) {
        this.t.removeAt(i);
      }
    }
  }
  addMore(number) {
    this.t.push(
      this.formBuilder.group({
        role: ['', Validators.required],
        selectedUser: ['', Validators.required],
        myCheckboxGroup: new FormGroup(
          {
            create: new FormControl(false),
            read: new FormControl(false),
            delete: new FormControl(false),
            edit: new FormControl(false),
          },
          requireCheckboxesToBeCheckedValidator()
        ),
      })
    );
  }
  cancel() {
    this.cancelEvent.emit({ name: ' ', type: 'cancel', category: 'role' });
  }

  fetchLinks() {
    this.service.fetchLinkList().subscribe((res) => {
      if(res['statusCode']=="R033")
      this.users = res['data'];
    });
  }
}
