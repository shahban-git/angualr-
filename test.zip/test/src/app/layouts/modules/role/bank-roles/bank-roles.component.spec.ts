import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BankRolesComponent } from './bank-roles.component';

describe('BankRolesComponent', () => {
  let component: BankRolesComponent;
  let fixture: ComponentFixture<BankRolesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BankRolesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BankRolesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
