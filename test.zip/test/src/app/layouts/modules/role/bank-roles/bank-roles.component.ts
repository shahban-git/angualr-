import { Component, OnInit ,Input,ViewChild, Output, EventEmitter} from '@angular/core';
import { MatTableDataSource} from '@angular/material/table';
import {MatPaginator} from '@angular/material/paginator';
import { RoleView } from 'src/app/models/roles/role-view';
import { RoleServiceService } from 'src/app/services/role/role-service.service';
import { FilterModel } from 'src/app/models/filter';

@Component({
  selector: 'app-bank-roles',
  templateUrl: './bank-roles.component.html',
  styleUrls: ['./bank-roles.component.css']
})
export class BankRolesComponent implements OnInit {
  @Output() nameEvent = new EventEmitter<any>();
  @Input() userNameFromParent = '';
  totalCount : Number;
  filterModel: FilterModel = new FilterModel();
  bankName;
  isAdmin;
  userDetailMes;
  displayedColumns: string[] = [ 'member name', 'Role Name', 'date','status'];
  dataSource : MatTableDataSource<RoleView[]>;
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;

  constructor(private service : RoleServiceService) {
    this.filterModel = {
      name : '',
      page: 0,
      size: 5
    }
   }

  ngOnInit(): void {
    this.isAdmin = +localStorage.getItem('vf');
    this.bankName = JSON.parse(this.userNameFromParent);
    if(this.isAdmin == 1)
    {
      this.roleList(this.bankName, this.filterModel);
    }
    else
    {
      this.roleList(this.bankName, this.filterModel);
    }
  }
  passName(e,element){
    e.preventDefault();
    this.nameEvent.emit(element);
  }

  passElement(e,element,type){
    e.preventDefault();
    this.nameEvent.emit({name:element,type:type,category:'role'});
  }
  back(){
    this.nameEvent.emit({name:"",type:"",category:'role'});
  }

  roleList(bankName, pageParams) {
    this.service.viewSubListRoles(bankName, pageParams).subscribe(data => {
      console.log("roleedetailll",data);
      if(data['statusCode']=="R030"){
        if(data['data']["content"].length>0){
          this.dataSource = new MatTableDataSource(data['data']["content"]);
          this.totalCount = data["data"]['totalElements']
        }
        else{
          this.dataSource=null;
          this.userDetailMes="No Records Found."
        }
        
      }
      else{
        this.dataSource=null;
        this.userDetailMes=data['statusDesc']
      }
    
      //this.dataSource.paginator = this.paginator;
    },(error)=>{
      this.dataSource=null;
      this.userDetailMes="Server Not Responding, Please Try Again Later."
    });
  }

  paginatorClick(pageNum: Number) {
    this.filterModel.page = pageNum['pageIndex'];
    this.filterModel.size = pageNum['pageSize'];
    this.roleList(this.bankName,this.filterModel);

  }

  onSearch(event: Event) {
    this.paginator.firstPage();
    this.filterModel.name = (event.target as HTMLInputElement).value
    this.filterModel.page = 0;
    this.filterModel.size = 5;
    this.roleList(this.bankName, this.filterModel);
  
  }

}
