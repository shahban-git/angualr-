import {
  Component,
  OnInit,
  ViewChild,
  Output,
  EventEmitter,
} from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { Router } from '@angular/router';
import { RoleView } from 'src/app/models/roles/role-view';
import { RoleServiceService } from 'src/app/services/role/role-service.service';
import { RoleCreate } from 'src/app/models/roles/role-create';
import { RoleNew } from 'src/app/models/roles/role-new';
import { LoginService } from 'src/app/services/subscribe/login.service';
import { FilterModel } from 'src/app/models/filter';

@Component({
  selector: 'app-view-role',
  templateUrl: './view-role.component.html',
  styleUrls: ['./view-role.component.css'],
})
export class ViewRoleComponent implements OnInit {
  @Output() nameEvent = new EventEmitter<any>();
  role: RoleNew;
  filterModel: FilterModel = new FilterModel();
  displayedColumns: string[] = [
   
    'member name',
    'roles',
    'date',
    'status',
    'action',
  ];
  crudPriv : number;
  roleMes;
  dataSource: MatTableDataSource<RoleView[]>;
  totalCount : Number;
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  constructor(private router: Router, private service: RoleServiceService, private loginService : LoginService) {
    this.filterModel = {
      name : '',
      page: 0,
      size: 5
    }
  }

  ngOnInit(): void {
    this.crudPriv =  +localStorage.getItem('cdPms');
    this.roleList(this.filterModel);
  }
  passName(e, element, type) {
    console.log("elemetttttt",element,type)
    e.preventDefault();
    //this.fetchRole(element);
    setTimeout(() => {
      this.nameEvent.emit({ name: element.bankName, type: type, category: 'role' });
    }, 100);
  }

  roleList(pageParams) {
    this.service.viewListRole(pageParams).subscribe((data) => {
      console.log("roleeeeeeeeeeeeeeeeeeeeeeee",data);
      if(data['statusCode']=="R029"){
        if(data["data"]["content"].length>0){
          this.dataSource = new MatTableDataSource(data["data"]["content"]);
          this.totalCount = data["data"]['totalElements']
        }
        else{
          this.dataSource=null;
          this.roleMes="No Records Found."
        }
      }
      else{
        this.dataSource=null;
        this.roleMes=data['statusDesc']
      }
     
    },(error)=>{
      this.dataSource=null;
      this.roleMes="Server Not Responding, Please Try Again Later."
    });
  }

  fetchRole(element) {
    this.service.getRoleById(element.bankId).subscribe((data) => {
      this.role = data['Role by Id'];
      this.role.roleBank = element.bankName;
    });
  }

  paginatorClick(pageNum: Number) {
    this.filterModel.page = pageNum['pageIndex'];
    this.filterModel.size = pageNum['pageSize'];
    this.roleList(this.filterModel);

  }
  onSearch(event: Event) {
    this.paginator.firstPage();
    this.filterModel.name = (event.target as HTMLInputElement).value
    this.filterModel.page = 0;
    this.filterModel.size = 5;
    this.roleList(this.filterModel);
  
  }
}
