import {
  Component,
  OnInit,
  Output,
  EventEmitter,
  Input,
  ViewChildren,
  QueryList,
  ElementRef,
} from '@angular/core';
import {
  FormGroup,
  FormControl,
  Validators,
  FormBuilder,
  FormArray,
} from '@angular/forms';
import { Router } from '@angular/router';
import { RoleCreate } from 'src/app/models/roles/role-create';
import { RoleNew } from 'src/app/models/roles/role-new';
import { RoleServiceService } from 'src/app/services/role/role-service.service';
import Swal from 'sweetalert2';
import { requireCheckboxesToBeCheckedValidator } from './../require-checkboxes-to-be-checked.validator';

@Component({
  selector: 'app-add-role',
  templateUrl: './add-role.component.html',
  styleUrls: ['./add-role.component.css'],
})
export class AddRoleComponent implements OnInit {
  selectedUser: any;
  users: any;
  @ViewChildren('filterInput') filterInput: QueryList<ElementRef>;
  dynamicForm: FormGroup;
  bankEditForm: FormGroup;
  bankList;
  role: RoleCreate = new RoleCreate();
  roleNew: RoleNew = new RoleNew();
  submitted = false;

  dropdownList = [];
  selectedItems = [];
  dropdownSettings = {};

  constructor(
    private formBuilder: FormBuilder,
    private service: RoleServiceService,
    private router : Router
  ) {}

  onOpen() {
    this.filterInput.changes.subscribe((res) => {
      this.filterInput.first.nativeElement.focus();
    });
  }
  customSearchFn(term: string, item: any) {
    console.log('term', term);
    console.log('item', item);
    term = term.toLocaleLowerCase();
    return item.toLocaleLowerCase().indexOf(term) > -1;

  }

  ngOnInit(): void {
    this.formInit();
    this.fetchBank();
    this.fetchLinks();
  }
  formInit() {
    this.dynamicForm = this.formBuilder.group({
      roleBank: [this.role.roleBank, Validators.required],
      roles: new FormArray([]),
    });

    this.getRoleNumber(1);
  }
  // convenience getters for easy access to form fields
  get f() {
    return this.dynamicForm.controls;
  }

  get t() {
    return this.f.roles as FormArray;
  }

  onSubmit(form: FormGroup) {
    console.log('form controls', form);
    this.submitted = true;
    if (form.invalid) {
      return;
    }
    this.roleNew = form.value;
    this.roleNew.roleBank = {
      bankId: form.value['roleBank'],
    };
    if (this.roleNew.roles.length > 0) {
      this.roleNew.roles.forEach((rl) => {
        rl.rolePrivDelete = rl.rolePrivDelete ? 1 : 0;
        rl.rolePrivEdit = rl.rolePrivEdit ? 1 : 0;
        rl.rolePrivRead = rl.rolePrivRead ? 1 : 0;
        rl.rolePrivWrite = rl.rolePrivWrite ? 1 : 0;
      });
    }
    if(form.invalid)
    {
      return
    }
    else{
    this.service.createRole(this.roleNew).subscribe((res) => {
      console.log("eeeeeeee",res);
      if(res['statusCode']=="R031"){
        Swal.fire({
          imageUrl : 'assets/images/checked_icon.svg',
          text: 'Role has been saved successfully'
        })
  
        this.router.navigate(['dashboard'])
      }
      else{
        Swal.fire({
          imageUrl: 'assets/images/warning.svg',
          text: res['statusDesc']
        })
      }
     
      // form.reset();
    },(error)=>{
      Swal.fire({
        imageUrl: 'assets/images/warning.svg',
        text: "Server Not Responding, Please Try Again Later."
      })
    });
  }
    this.reset();
  }

  getRoleNumber(e) {
    //console.log("function",this.t);
    const numberOfProducts = e || 0;
    if (this.t.length < numberOfProducts) {
      for (let i = this.t.length; i < numberOfProducts; i++) {
        this.t.push(
          this.formBuilder.group({
            roleName: [this.role.roleName, Validators.required],
            selectedUser: ['', Validators.required],
            // create:["", Validators.required],
            // read:["", Validators.required],
            // delete:["", Validators.required],
            // edit:["", Validators.required],
            rolePrivWrite: new FormControl(false),
            rolePrivRead: new FormControl(false),
            rolePrivDelete: new FormControl(false),
            rolePrivEdit: new FormControl(false),
          })
        );
      }
    } else {
      for (let i = this.t.length; i >= numberOfProducts; i--) {
        this.t.removeAt(i);
      }
    }
  }
  addMore(number) {
    this.t.push(
      this.formBuilder.group({
        roleName: [this.role.roleName, Validators.required],
        selectedUser: ['', Validators.required],
        // create:[""],
        // read:["", Validators.required],
        // delete:["", Validators.required],
        // edit:["", Validators.required]
        rolePrivWrite: new FormControl(false),
        rolePrivRead: new FormControl(false),
        rolePrivDelete: new FormControl(false),
        rolePrivEdit: new FormControl(false),
      })
    );
  }
  reset() {
    this.dynamicForm.reset();
    this.formInit();
    Object.keys(this.dynamicForm.controls).forEach((key) => {
      this.dynamicForm.controls[key].setErrors(null);
    });
    this.submitted = false;
  }

  fetchBank() {
    this.service.fetchBankList().subscribe((res) => {
      // this.bankList = res['Bank DropDown'];
      console.log("memberrrrrrrrrr",res)
      if(res['statusCode']=="R112"){
        this.bankList = res['data'];
  
        }
    });
  }

  fetchLinks() {
    this.service.fetchLinkList().subscribe((res) => {
      console.log("roleeeeeeeee link drop down",res)
      if(res['statusCode'] =="R033")
      this.users = res['data'];
    });
  }
}
