import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import {
  FormGroup,
  FormControl,
  Validators,
  FormBuilder,
  FormArray,
} from '@angular/forms';
import { Router } from '@angular/router';
import { LinkService } from 'src/app/services/master/link.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-link',
  templateUrl: './add-link.component.html',
  styleUrls: ['./add-link.component.css']
})
export class AddLinkComponent implements OnInit {
  dynamicForm: FormGroup;
  submitted = false;
  count = 0;
  @Output() nameEvent = new EventEmitter<any>();
  formErrors = {
    'productName': '',
    'SubproductName':'',
    'linkName':'',
    'linkDescription':''
  };
  validationMessages = {
    'productName': { 'required': 'Product Name is required', 'pattern': 'Special characters and Digits not allowed' },
    'SubproductName': { 'required': 'Sub Product Name is required', 'pattern': 'Special characters and Digits not allowed' },
    'linkName': { 'required': 'Link Name is required', 'pattern': 'Special characters and Digits not allowed' },
    'linkDescription': { 'required': 'Description is required', 'pattern': 'Special characters and Digits not allowed' },
  }
  ProductList: any;
  SubProductList:any;

  constructor(private formBuilder: FormBuilder, private service: LinkService, private router: Router) { }
  
  ngOnInit(): void {
    this.formInit();
    this.fetchProduct();
    this.dynamicForm.valueChanges.subscribe(data => {
      this.logValidationErrors(this.dynamicForm);
    })
  }

  formInit() {
    this.dynamicForm = this.formBuilder.group({
      productName: ['', Validators.compose([Validators.required])],
      SubproductName: ['', Validators.compose([Validators.required])],
      linkName:['', Validators.compose([Validators.required])],
      linkDescription:['', Validators.compose([Validators.required])],
      businessTypes: new FormArray([]),
    });
    this.addBusiness();
  }
  // convenience getters for easy access to form fields
  get f() {
    return this.dynamicForm.controls;
  }
  get b() {
    return this.f.businessTypes as FormArray;
  }
 

  addBusiness() {
    let fg = this.formBuilder.group({
      subProductName: ['', Validators.required],
    });
    (<FormArray>this.dynamicForm.get('businessTypes')).push(fg);
    let userIndex =
      (<FormArray>this.dynamicForm.get('businessTypes')).length - 1;
  }

  logValidationErrors(group: FormGroup = this.dynamicForm): void {
    Object.keys(group.controls).forEach((key: string) => {
      const abstractControl = group.get(key);
      this.formErrors[key] = '';
      if (abstractControl && !abstractControl.valid && (abstractControl.touched || abstractControl.dirty)) {
        const message = this.validationMessages[key];
        for (const err in abstractControl.errors) {
          if (err) {
            console.log('err , key ', err, key);
            this.formErrors[key] = message[err] + ' ';
          }
        }
      }
      if (abstractControl instanceof FormGroup) {
        this.logValidationErrors(abstractControl);
      }
    });
  }

  deleteBusiness(index: number) {
    (<FormArray>this.dynamicForm.get('businessTypes')).removeAt(index);
  }

  onSubmit(form: FormGroup) {
    if (form.invalid) {
      form.markAllAsTouched()
      this.logValidationErrors();
      return;
    }
    console.log(form.value)
    this.submitted = true;
    let subProductName = []
    for (let index = 0; index < form.value.businessTypes.length; index++) {
      const element = form.value.businessTypes[index]["subProductName"];
      subProductName.push(element)
    }

    // let data = {
    //   "productName": form.value.productName,
    //   "subProductName": subProductName,
    //   "businessType": form.value.businessType
    // }

    let data = {
      "productId": form.value.productName,
      "subProdId": form.value.productName,
      'linkName': form.value.linkName,
      "sublinkName": subProductName,
      'linkDescription':form.value.linkDescription
    }
   console.log(data)
    this.service.saveLink(data).subscribe((data) => {
      console.log("saveproducttttttttttttt",data);
      if(data['statusCode']=="R035"){
        Swal.fire({
          imageUrl: 'assets/images/checked_icon.svg',
          text: 'Link has been saved successfully.',
        })
        this.router.navigate(['dashboard/product-menu-setup'])
      }
      else{
        Swal.fire({
          imageUrl: 'assets/images/warning.svg',
          text:data['statusDesc']
        })
      }
     
    },(error)=>{
      Swal.fire({
        imageUrl: 'assets/images/warning.svg',
        text:"Server Not Responding, Please Try Again Later."
      })
    });
  }

  reset() {
    this.dynamicForm.reset();
    this.dynamicForm.markAsPristine();
    this.dynamicForm.markAsUntouched();
    this.dynamicForm.updateValueAndValidity();
    this.submitted = false;
  }

  fetchProduct() {
   // this.addBranchForm.controls['branchZone'].reset();
    //this.addBranchForm.controls['branchRegion'].reset();
    this.service.fetchProductList().subscribe((res) => {
      if(res['statusCode']=="R043"){
        this.ProductList = res['data'];

      }
    });

}


fetchSubProductList(id) {
   this.service.fetchSubProductList(id).subscribe((res) => {
     console.log("44444444444444",res)
     if(res['statusCode']=="R044"){
      this.SubProductList = res['data'];

     }
   });

}}