import { Component, OnInit } from '@angular/core';
import { MatTabChangeEvent } from '@angular/material/tabs';
import { Router, ActivatedRoute } from '@angular/router';
import { LoginService } from 'src/app/services/subscribe/login.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-dashboard-view',
  templateUrl: './dashboard-view.component.html',
  styleUrls: ['./dashboard-view.component.css']
})
export class DashboardViewComponent implements OnInit {
  public userName: any;
  // for breadcrumbs
  public selectedTabNames = ['Member', 'Department', 'Designation', 'Role', 'Zone', 'Region', 'Branch', 'Configuration', 'Users'];
  public selectedTab = this.selectedTabNames[0];

  crudPriv: number;

  // bank handlers
  bankview = true; bankproductview = false; bankedit = false; bankAdd = false;
  // department handlers
  deptview = false; bankDeptview = false; deptedit = false; deptAdd = false;
  // designation handlers
  desgView = false; bankDesgDeview = false; desgEdit = false; desgAdd = false;
  // role handlers
  roleView = false; bankRoleview = false; roleEdit = false; roleAdd = false;
  // zone handlers
  zoneView = false; bankZoneview = false; zoneEdit = false; zoneAdd = false;
  // zone handlers
  regionView = false; bankRegionview = false; regionEdit = false; regionAdd = false;
  // branch handlers
  branchView = false; branchDetailview = false; branchEdit = false; branchAdd = false;
  // User handlers
  userView = false; userDetailview = false; userEdit = false; userAdd = false;
  // config handlers
  configView = false; configEdit = false; configDetail = false; configAdd = false;
  selectedIndex = 0;
  deleteAllField = false;
  isAdmin;
  view;
  setAllFalse() {

  }
  member: string;
  constructor(private route: ActivatedRoute, private router: Router, private loginService: LoginService) {
    this.crudPriv = this.loginService.crudPerms;
    let index = this.route.snapshot.params.index;

    let admin = this.route.snapshot.params.admin;

  }
  trueData;
  

  ngOnInit(): void {
    this.view = localStorage.getItem('vf');
    let tabInd=parseInt(localStorage.getItem("tabInd"))
    this.trueData = localStorage.getItem("viewData");

    if(tabInd!=null &&this.trueData!=null ){
    console.log("cccccccccccccccccc",tabInd,this.trueData)
        this.afterAddFunction(tabInd,this.trueData);
    }
    if (this.view == 1) {
      this.bankview = false; this.bankproductview = true;
      this.userName = JSON.stringify(localStorage.getItem('bank'));
     
    }

  }
 
  deleteAll() {
    // this.selectedIndex = 6;
    // let index = this.route.snapshot.params.index;

    Swal.fire({
      imageUrl: 'assets/images/delete_icon.svg',
      customClass: {
        content: 'text-left',
        container: 'mr-0',
        confirmButton: 'confirm-button',
        cancelButton: 'cancel-button'
      },
      showCancelButton: true,
      confirmButtonText: 'Yes',
      cancelButtonText: 'Cancel',
      html: '<p>You are about to delete this member and related all the masters/data.</p>' +
        '<p>To delete this member please follow below steps:</p>' +
        '<ul>' +
        '<li>1) First you need to delete the <b>"Users"</b> of this member.</li>' +
        '<li>2) After deleting the Users delete Configuration, Branch,Role, Designation, Department and Member.</li>' +
        '<li>3) Follow the sequence of deleting masters given in <b>Step - 2</b></li>' +
        '</ul>' +
        '<p><b>Note:</b> Each master delete process requires certification. You can not proceed further unless earlier master  has not been certified.</p>'
      ,
    }).then((result) => {
      if (result.isConfirmed) {
        this.deleteAllField = true;
        this.selectedIndex = 8;
        console.log("bbbbbbbbbbbbb",this.userName)
        this.router.navigate(['/dashboard/', { index: 8, setDelete: true, user: this.userName }]);
      }
    });
  }
  selectedTabEvent(event) {

    if (event === false) {
      this.deleteAllField = false;
      this.selectedIndex = 0;
      this.bankview = true; this.bankproductview = false; this.bankedit = false; this.bankAdd = false
    } else {
      this.selectedIndex = event;
    }

    // this.router.navigate(['/dashboard/',{index:event,setDelete:true,user:this.userName}]);
  }

  
afterAddFunction(tabInd,trueData){
  
  if(trueData=="member"){
    this.selectedTab = this.selectedTabNames[tabInd];
  this.selectedIndex =tabInd
    this.bankview = true; this.bankproductview = false; 
    this.bankedit = false; this.bankAdd = false;
    this.deptview = false; this.bankDeptview = false; this.deptedit = false;
     this.deptAdd = false;
    this.desgView = false; this.bankDesgDeview = false; this.desgEdit = false; 
    this.desgAdd = false;
    this.roleView = false; this.bankRoleview = false; 
    this.roleEdit = false; this.roleAdd = false;
    this.zoneView = false; this.bankZoneview = false;
     this.zoneEdit = false; this.zoneAdd = false;
    this.regionView = false; this.bankRegionview = false; 
    this.regionEdit = false; this.regionAdd = false;
    this.branchView = false; this.branchDetailview = false; 
    this.branchEdit = false; this.branchAdd = false;
    this.userView = false; this.userDetailview = false; 
    this.userEdit = false; this.userAdd = false;
    this.configView = false; this.configEdit = false; 
    this.configDetail = false; this.configAdd = false;
  }
  else if(trueData=="department/designation"){
    this.selectedTab = this.selectedTabNames[1];
  this.selectedIndex =1
    this.bankview = false; this.bankproductview = false; 
    this.bankedit = false; this.bankAdd = false;
    this.deptview = true; this.bankDeptview = false; this.deptedit = false;
     this.deptAdd = false;
    this.desgView = false; this.bankDesgDeview = false; this.desgEdit = false; 
    this.desgAdd = false;
    this.roleView = false; this.bankRoleview = false; 
    this.roleEdit = false; this.roleAdd = false;
    this.zoneView = false; this.bankZoneview = false;
     this.zoneEdit = false; this.zoneAdd = false;
    this.regionView = false; this.bankRegionview = false; 
    this.regionEdit = false; this.regionAdd = false;
    this.branchView = false; this.branchDetailview = false; 
    this.branchEdit = false; this.branchAdd = false;
    this.userView = false; this.userDetailview = false; 
    this.userEdit = false; this.userAdd = false;
    this.configView = false; this.configEdit = false; 
    this.configDetail = false; this.configAdd = false;
    
  }
  else if(trueData=="role"){
    this.selectedTab = this.selectedTabNames[3];
  this.selectedIndex =3
    this.bankview = false; this.bankproductview = false; 
    this.bankedit = false; this.bankAdd = false;
    this.deptview = false; this.bankDeptview = false; this.deptedit = false;
     this.deptAdd = false;
    this.desgView = false; this.bankDesgDeview = false; this.desgEdit = false; 
    this.desgAdd = false;
    this.roleView = true; this.bankRoleview = false; 
    this.roleEdit = false; this.roleAdd = false;
    this.zoneView = false; this.bankZoneview = false;
     this.zoneEdit = false; this.zoneAdd = false;
    this.regionView = false; this.bankRegionview = false; 
    this.regionEdit = false; this.regionAdd = false;
    this.branchView = false; this.branchDetailview = false; 
    this.branchEdit = false; this.branchAdd = false;
    this.userView = false; this.userDetailview = false; 
    this.userEdit = false; this.userAdd = false;
    this.configView = false; this.configEdit = false; 
    this.configDetail = false; this.configAdd = false;
  }
  else if(trueData=="zone"){
    this.selectedTab = this.selectedTabNames[4];
  this.selectedIndex =4
    this.bankview = false; this.bankproductview = false; 
    this.bankedit = false; this.bankAdd = false;
    this.deptview = false; this.bankDeptview = false; this.deptedit = false;
     this.deptAdd = false;
    this.desgView = false; this.bankDesgDeview = false; this.desgEdit = false; 
    this.desgAdd = false;
    this.roleView = false; this.bankRoleview = false; 
    this.roleEdit = false; this.roleAdd = false;
    this.zoneView = true; this.bankZoneview = false;
     this.zoneEdit = false; this.zoneAdd = false;
    this.regionView = false; this.bankRegionview = false; 
    this.regionEdit = false; this.regionAdd = false;
    this.branchView = false; this.branchDetailview = false; 
    this.branchEdit = false; this.branchAdd = false;
    this.userView = false; this.userDetailview = false; 
    this.userEdit = false; this.userAdd = false;
    this.configView = false; this.configEdit = false; 
    this.configDetail = false; this.configAdd = false;
  }
  else if(trueData=="region"){
    console.log("regiooooooooooonnnnn")
    this.selectedTab = this.selectedTabNames[5];
  this.selectedIndex =5
    this.bankview = false; this.bankproductview = false; 
    this.bankedit = false; this.bankAdd = false;
    this.deptview = false; this.bankDeptview = false; this.deptedit = false;
     this.deptAdd = false;
    this.desgView = false; this.bankDesgDeview = false; this.desgEdit = false; 
    this.desgAdd = false;
    this.roleView = false; this.bankRoleview = false; 
    this.roleEdit = false; this.roleAdd = false;
    this.zoneView = false; this.bankZoneview = false;
     this.zoneEdit = false; this.zoneAdd = false;
    this.regionView = true; this.bankRegionview = false; 
    this.regionEdit = false; this.regionAdd = false;
    this.branchView = false; this.branchDetailview = false; 
    this.branchEdit = false; this.branchAdd = false;
    this.userView = false; this.userDetailview = false; 
    this.userEdit = false; this.userAdd = false;
    this.configView = false; this.configEdit = false; 
    this.configDetail = false; this.configAdd = false;
  }
  else if(trueData=="branch"){
    this.selectedTab = this.selectedTabNames[6];
  this.selectedIndex = 6
    this.bankview = false; this.bankproductview = false; 
    this.bankedit = false; this.bankAdd = false;
    this.deptview = false; this.bankDeptview = false; this.deptedit = false;
     this.deptAdd = false;
    this.desgView = false; this.bankDesgDeview = false; this.desgEdit = false; 
    this.desgAdd = false;
    this.roleView = false; this.bankRoleview = false; 
    this.roleEdit = false; this.roleAdd = false;
    this.zoneView = false; this.bankZoneview = false;
     this.zoneEdit = false; this.zoneAdd = false;
    this.regionView = false; this.bankRegionview = false; 
    this.regionEdit = false; this.regionAdd = false;
    this.branchView = true; this.branchDetailview = false; 
    this.branchEdit = false; this.branchAdd = false;
    this.userView = false; this.userDetailview = false; 
    this.userEdit = false; this.userAdd = false;
    this.configView = false; this.configEdit = false; 
    this.configDetail = false; this.configAdd = false;
  }
  else if(trueData=="configuration"){
    this.selectedTab = this.selectedTabNames[7];
  this.selectedIndex =7
    this.bankview = false; this.bankproductview = false; 
    this.bankedit = false; this.bankAdd = false;
    this.deptview = false; this.bankDeptview = false; this.deptedit = false;
     this.deptAdd = false;
    this.desgView = false; this.bankDesgDeview = false; this.desgEdit = false; 
    this.desgAdd = false;
    this.roleView = false; this.bankRoleview = false; 
    this.roleEdit = false; this.roleAdd = false;
    this.zoneView = false; this.bankZoneview = false;
     this.zoneEdit = false; this.zoneAdd = false;
    this.regionView = false; this.bankRegionview = false; 
    this.regionEdit = false; this.regionAdd = false;
    this.branchView = false; this.branchDetailview = false; 
    this.branchEdit = false; this.branchAdd = false;
    this.userView = false; this.userDetailview = false; 
    this.userEdit = false; this.userAdd = false;
    this.configView = true; this.configEdit = false; 
    this.configDetail = false; this.configAdd = false;
  }
}

  /*---------- bank view hadlar ---------------------*/
  nameEventHander($event: any) {
    console.log("dddddddddddddddddddddddddddd",$event)
    //this.userName  = JSON.stringify($event.name);
    if ($event.type === 'deleteBank') {
      this.userName = JSON.stringify({ parameters: $event.name, type: 'delete' })
    } else {
      this.userName = JSON.stringify($event.name);
    }

    switch ($event.category) {
      case 'bank': {
        if ($event.type === 'viewbank') {
          this.bankview = false; this.bankproductview = true; this.bankedit = false; this.bankAdd = false;
        }
        else if ($event.type === 'editbank') {
          this.bankview = false; this.bankproductview = false; this.bankedit = true; this.bankAdd = false;
        }
        else if ($event.type === 'addbank') {
          this.bankview = false; this.bankproductview = false; this.bankedit = false; this.bankAdd = true;
        }
        else if ($event.type === 'deleteBank') {
          this.bankview = false; this.bankproductview = false; this.bankedit = true; this.bankAdd = false;
        }
        else {
          this.bankview = true; this.bankproductview = false; this.bankedit = false; this.bankAdd = false;
        }
        break;
      }
      case 'department': {
        if ($event.type === 'viewDept') {
          this.deptview = false; this.bankDeptview = true; this.deptedit = false; this.deptAdd = false;
        }
        else if ($event.type === 'editDept') {
          this.deptview = false; this.bankDeptview = false; this.deptedit = true; this.deptAdd = false;
        }
        else if ($event.type === 'addDept') {
          this.deptview = false; this.bankDeptview = false; this.deptedit = false; this.deptAdd = true;
        }
        else {
          this.deptview = true; this.bankDeptview = false; this.deptedit = false; this.deptAdd = false;
        }
        break;
      }
      case 'zone': {
        if ($event.type === 'viewZone') {
          this.zoneView = false; this.bankZoneview = true; this.zoneEdit = false; this.zoneAdd = false;
        }
        else if ($event.type === 'editZone') {
          this.zoneView = false; this.bankZoneview = false; this.zoneEdit = true; this.zoneAdd = false;
        }
        else if ($event.type === 'addZone') {
          this.zoneView = false; this.bankZoneview = false; this.zoneEdit = false; this.zoneAdd = true;
        }
        else {
          this.zoneView = true; this.bankZoneview = false; this.zoneEdit = false; this.zoneAdd = false;

        }
        break;
      }
      case 'region': {
        if ($event.type === 'viewRegion') {
          this.regionView = false; this.bankRegionview = true; this.regionEdit = false; this.regionAdd = false;
        }
        else if ($event.type === 'editRegion') {
          this.regionView = false; this.bankRegionview = false; this.regionEdit = true; this.regionAdd = false;
        }
        else if ($event.type === 'addRegion') {
          this.regionView = false; this.bankRegionview = false; this.regionEdit = false; this.regionAdd = true;
        }
        else {
          this.regionView = true; this.bankRegionview = false; this.regionEdit = false; this.regionAdd = false;

        }
        break;
      }
      case 'designation': {
        if ($event.type === 'viewDesg') {
          this.desgView = false; this.bankDesgDeview = true; this.desgEdit = false; this.desgAdd = false;
        }
        else if ($event.type === 'editDesg') {
          this.desgView = false; this.bankDesgDeview = false; this.desgEdit = true; this.desgAdd = false;
        }
        else if ($event.type === 'addDesg') {
          this.desgView = false; this.bankDesgDeview = false; this.desgEdit = false; this.desgAdd = true;
        }
        else {
          this.desgView = true; this.bankDesgDeview = false; this.desgEdit = false; this.desgAdd = false;
        }
        break;
      }
      case 'role': {
        if ($event.type === 'viewRole') {
          this.roleView = false; this.bankRoleview = true; this.roleEdit = false; this.roleAdd = false;
        }
        else if ($event.type === 'editRole') {
          this.roleView = false; this.bankRoleview = false; this.roleEdit = true; this.roleAdd = false;
        }
        else if ($event.type === 'addRole') {
          this.roleView = false; this.bankRoleview = false; this.roleEdit = false; this.roleAdd = true;
        }
        else {
          this.roleView = true; this.bankRoleview = false; this.roleEdit = false; this.roleAdd = false;
        }
        break;
      }
      case 'branch': {
        if ($event.type === 'viewBranch') {
          this.branchView = false; this.branchDetailview = true; this.branchEdit = false; this.branchAdd = false;
        }
        else if ($event.type === 'editBranch') {
          this.branchView = false; 
          this.branchDetailview = false; this.branchEdit = true; this.branchAdd = false;
        }
        else if ($event.type === 'addBranch') {
          this.branchView = false; this.branchDetailview = false; this.branchEdit = false; this.branchAdd = true;
        }
        else if ($event.type === 'cancel') {
          this.branchView = false; this.branchDetailview = true; this.branchEdit = false; this.branchAdd = false;
        }
        else {
          this.branchView = true; this.branchDetailview = false; this.branchEdit = false;
        }
        break;
      }
      case 'config': {
        if ($event.type === 'configEdit') {
          this.configView = false; this.configEdit = true;
        } else {
          this.configView = true; this.configEdit = false;
        }
      }
      case 'user': {
        if ($event.type === 'viewUser') {
          this.userView = false; this.userDetailview = true; this.userEdit = false; this.userAdd = false;
        }
        else if ($event.type === 'editUser') {
          this.userView = false; this.userDetailview = false; this.userEdit = true; this.userAdd = false;
        }
        else if ($event.type === 'addUser') {
          this.userView = false; this.userDetailview = false; this.userEdit = false; this.userAdd = true;
        }
        else if ($event.type === 'cancel') {
          this.userView = false; this.userDetailview = true; this.userEdit = false; this.userAdd = false;
        }
        else {
          this.userView = true; this.userDetailview = false; this.userEdit = false; this.userAdd = false;
        }
        break;
      }
      default: {
        //statements;
        break;
      }
    }

  }

  onTabChanged(event: MatTabChangeEvent) {
    console.log("tabbbchangeeeeeeeeeeeeeeeeee")
    this.selectedTab = this.selectedTabNames[event.index];
    this.selectedIndex = event.index;
    // bank tab change event
    if (event.index === 0 && this.deleteAllField == false && this.view == 0) {
      // this.bankview = true;this.bankproductview = false;this.bankedit = false;
      this.bankview = true; this.bankproductview = false; this.bankedit = false; this.bankAdd = false;
    }
    else if (event.index === 0 && this.deleteAllField == false && this.view == 1) {
      this.bankview = false; this.bankproductview = true; this.bankedit = false; this.bankAdd = false;
    }
    else if (event.index === 0 && this.deleteAllField == true) {
      this.bankview = false; this.bankproductview = false; this.bankedit = true; this.bankAdd = false;
    }
    else {
      //this.bankview = false;this.bankproductview = false;this.bankedit = false;
      this.bankview = false; this.bankproductview = false; this.bankedit = false; this.bankAdd = false;
    }


    // department tab change event
    if (event.index === 1 && this.deleteAllField == false && this.view == 0) {
      this.deptview = true; this.bankDeptview = false; this.deptedit = false; this.deptAdd = false;
    }
    else if (event.index === 1 && this.deleteAllField == false && this.view == 1) {
      this.deptview = false; this.bankDeptview = true; this.deptedit = false; this.deptAdd = false;
    }
    else if (event.index === 1 && this.deleteAllField == true) {
      this.deptview = false; this.bankDeptview = false; this.deptedit = true; this.deptAdd = false;
    }
    else {
      this.deptview = false; this.bankDeptview = false; this.deptedit = false; this.deptAdd = false;
    }


    //designation tab changed event
    if (event.index === 2 && this.deleteAllField == false && this.view == 0) {
      this.desgView = true; this.bankDesgDeview = false; this.desgEdit = false; this.desgAdd = false;
    }
    else if (event.index === 2 && this.deleteAllField == false && this.view == 1) {
      this.desgView = false; this.bankDesgDeview = true; this.desgEdit = false; this.desgAdd = false;
    }
    else if (event.index === 2 && this.deleteAllField == true) {
      this.desgView = false; this.bankDesgDeview = false; this.desgEdit = true; this.desgAdd = false;
    }
    else {
      this.desgView = false; this.bankDesgDeview = false; this.desgEdit = false; this.desgAdd = false;
    }

    if (event.index === 3 && this.deleteAllField == false && this.view == 0) {
      this.roleView = true; this.bankRoleview = false; this.roleEdit = false; this.roleAdd = false;
    }
    else if (event.index === 3 && this.deleteAllField == false && this.view == 1) {
      this.roleView = false; this.bankRoleview = true; this.roleEdit = false; this.roleAdd = false;
    }
    else if (event.index === 3 && this.deleteAllField == true) {
      this.roleView = false; this.bankRoleview = false; this.roleEdit = true; this.roleAdd = false;
    }
    else {
      this.roleView = false; this.bankRoleview = false; this.roleEdit = false; this.roleAdd = false;
    }

    if (event.index === 4 && this.deleteAllField == false && this.view == 0) {
      this.zoneView = true; this.bankZoneview = false; this.zoneEdit = false; this.zoneAdd = false;
    }
    else if (event.index === 4 && this.deleteAllField == false && this.view == 1) {
      this.zoneView = false; this.bankZoneview = true; this.zoneEdit = false; this.zoneAdd = false;

    }
    else if (event.index === 4 && this.deleteAllField == true) {
      this.zoneView = false; this.bankZoneview = false; this.zoneEdit = true; this.zoneAdd = false;

    }
    else {
      this.zoneView = false; this.bankZoneview = false; this.zoneEdit = false; this.zoneAdd = false;

    }

    if (event.index === 5 && this.deleteAllField == false && this.view == 0) {
      this.regionView = true; this.bankRegionview = false; this.regionEdit = false; this.regionAdd = false;
    }
    else if (event.index === 5 && this.deleteAllField == false && this.view == 1) {
      this.regionView = false; this.bankRegionview = true; this.regionEdit = false; this.regionAdd = false;

    }
    else if (event.index === 5 && this.deleteAllField == true) {
      this.regionView = false; this.bankRegionview = false; this.regionEdit = true; this.regionAdd = false;

    }
    else {
      this.regionView = false; this.bankRegionview = false; this.regionEdit = false; this.regionAdd = false;

    }

    if (event.index === 6 && this.deleteAllField == false && this.view == 0) {
      this.branchView = true; this.branchDetailview = false; this.branchEdit = false; this.branchAdd = false;
    }
    else if (event.index === 6 && this.deleteAllField == false && this.view == 1) {
      this.branchView = false; this.branchDetailview = true; this.branchEdit = false; this.branchAdd = false;
    }
    else if (event.index === 6 && this.deleteAllField == true) {
      this.branchView = false; this.branchDetailview = true; this.branchEdit = false; this.branchAdd = false;
    }
    else {
      this.branchView = false; this.branchDetailview = false; this.branchEdit = false; this.branchAdd = false;
    }



    if (event.index === 7 && this.deleteAllField == false && this.view == 0) {
      this.configView = true; this.configDetail = false; this.configEdit = false; this.configAdd = false;
    }
    else if (event.index === 7 && this.deleteAllField == false && this.view == 1) {
      this.configView = false; this.configDetail = true; this.configEdit = false; this.configAdd = false;
    }
    else if (event.index === 7 && this.deleteAllField == true) {
      this.configView = false; this.configDetail = false; this.configEdit = true; this.configAdd = false;
    }
    else {
      this.configView = false; this.configDetail = false; this.configEdit = false; this.configAdd = false;
    }


    if (event.index === 8 && this.deleteAllField == false && this.view == 0) {
      this.userView = true; this.userDetailview = false; this.userEdit = false; this.userAdd = false;
    }
    else if (event.index === 8 && this.deleteAllField == false && this.view == 1) {
      this.userView = false; this.userDetailview = true; this.userEdit = false; this.userAdd = false;
    }
    else if (event.index === 8 && this.deleteAllField == true) {
      this.userView = false; this.userDetailview = false; this.userEdit = true; this.userAdd = false;
    }
    else {
      this.userView = false; this.userDetailview = false; this.userEdit = false; this.userAdd = false;
    }
  }

  onTabClick(event) {
    //console.log("tab event",event);
  }

  selectNextTab(event) {

    if (event == '5') {
      this.userName = JSON.parse(this.userName).bankName;
      console.log("aaaaaaaaa",this.userName)

      // this.userName = this.userName.bankName;

    }
    this.selectedIndex = event;
  }
}
