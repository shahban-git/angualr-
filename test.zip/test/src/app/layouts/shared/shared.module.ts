import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
// for dd/mm/yyyy format
import { MAT_DATE_LOCALE } from '@angular/material/core';
/*--------------------material modules ---------------------*/
import { NgSelectModule } from '@ng-select/ng-select';
import { MatCardModule } from '@angular/material/card';
import { MatDividerModule } from '@angular/material/divider';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatMenuModule } from '@angular/material/menu';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { CdkTableModule } from '@angular/cdk/table';
import { MatTabsModule } from '@angular/material/tabs';
import { MatListModule } from "@angular/material/list";
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatRadioModule } from '@angular/material/radio';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatSidenavModule } from '@angular/material/sidenav';
/*--------------- component -----------------------------------------------------*/
import { LoginComponent } from 'src/app/layouts/modules/login/login.component';
import { HeaderComponent } from './header/header.component';
import { ChangePasswordComponent } from 'src/app/layouts/modules/change-password/change-password.component';

import { SidebarComponent } from './sidebar/sidebar.component';
import { MenuListItemComponent } from './menu-list-item/menu-list-item.component';
import { DashboardComponent } from 'src/app/layouts/dashboard/dashboard.component';
import { DashboardViewComponent } from 'src/app/layouts/modules/dashboard-view/dashboard-view.component';
import { ViewBankComponent } from 'src/app/layouts/modules/bank/view-bank/view-bank.component';
import { EditBankComponent } from 'src/app/layouts/modules/bank/edit-bank/edit-bank.component';
import { AddBankComponent } from 'src/app/layouts/modules/bank/add-bank/add-bank.component';
import { BankProductsComponent } from 'src/app/layouts/modules/bank/bank-products/bank-products.component';
import { MasterSetupComponent } from 'src/app/layouts/modules/master-setup/master-setup.component';
import { ViewDepartmentComponent } from 'src/app/layouts/modules/department/view-department/view-department.component';
import { EditDepartmentComponent } from 'src/app/layouts/modules/department/edit-department/edit-department.component';
import { BankDepartmentComponent } from 'src/app/layouts/modules/department/bank-department/bank-department.component';
import { ViewDesignationComponent } from 'src/app/layouts/modules/designation/view-designation/view-designation.component';
import { EditDesignationComponent } from 'src/app/layouts/modules/designation/edit-designation/edit-designation.component';
import { BankDesignationComponent } from 'src/app/layouts/modules/designation/bank-designation/bank-designation.component';
import { AddRoleComponent } from 'src/app/layouts/modules/role/add-role/add-role.component';
import { ViewRoleComponent } from 'src/app/layouts/modules/role/view-role/view-role.component';
import { EditRoleComponent } from 'src/app/layouts/modules/role/edit-role/edit-role.component';
import { BankRolesComponent } from 'src/app/layouts/modules/role/bank-roles/bank-roles.component';
import { AddBranchComponent } from 'src/app/layouts/modules/branch/add-branch/add-branch.component';
import { EditBranchComponent } from 'src/app/layouts/modules/branch/edit-branch/edit-branch.component';
import { ViewBranchComponent } from 'src/app/layouts/modules/branch/view-branch/view-branch.component';
import { BankBranchsComponent } from 'src/app/layouts/modules/branch/bank-branchs/bank-branchs.component';
import { ViewUserComponent } from 'src/app/layouts/modules/users/view-user/view-user.component';
import { BankUserDetailComponent } from 'src/app/layouts/modules/users/bank-user-detail/bank-user-detail.component';
import { AddUserComponent } from 'src/app/layouts/modules/users/add-user/add-user.component';
import { EditUserComponent } from 'src/app/layouts/modules/users/edit-user/edit-user.component';
import { ViewConfigComponent } from 'src/app/layouts/modules/configuaration/view-config/view-config.component';
import { EditConfigComponent } from 'src/app/layouts/modules/configuaration/edit-config/edit-config.component';
import { AddConfigComponent } from 'src/app/layouts/modules/configuaration/add-config/add-config.component';
import { AddDepartmentComponent } from 'src/app/layouts/modules/department/add-department/add-department.component';
import { ReportComponent } from 'src/app/layouts/modules/report/report.component';
import { SiReportComponent } from 'src/app/layouts/modules/report/si-report/si-report.component';
import { BasicAuthInterceptorService } from 'src/app/services/subscribe/basic-auth-interceptor.service';
import { CertificationDetailComponent } from '../modules/certification-home/certification-detail/certification-detail.component';
import { CertificationApproveComponent } from '../modules/certification-home/certification-approve/certification-approve.component';
import { CertificationViewComponent } from '../modules/certification-home/certification-view/certification-view.component';
import { CertificationComponent } from '../modules/certification-home/certification/certification.component';
import { ProductsListComponent } from '../modules/product-setup/products-list/products-list.component';
import { AddProductComponent } from '../modules/product-setup/add-product/add-product.component';
import { PrdComponent } from 'src/app/prd/prd.component';
import { AcqbinComponent } from 'src/app/acqbin/acqbin.component';
import { IcmComponent } from 'src/app/icm/icm.component';
import { IcmgenComponent } from 'src/app/icmgen/icmgen.component';
import { IssbinComponent } from 'src/app/issbin/issbin.component';
import { ViewZoneComponent } from '../modules/zone/view-zone/view-zone.component';
import { AddZoneComponent } from '../modules/zone/add-zone/add-zone.component';
import { AddRegionComponent } from '../modules/region/add-region/add-region.component';
import { RegionViewComponent } from '../modules/region/region-view/region-view.component';
import { BankZoneComponent } from '../modules/zone/bank-zone/bank-zone.component';
import { EditZoneComponent } from '../modules/zone/edit-zone/edit-zone.component';
import { BankRegionComponent } from '../modules/region/bank-region/bank-region.component';
import { EditRegionComponent } from '../modules/region/edit-region/edit-region.component';
import { AddLinkComponent } from '../modules/product-menu-setup/add-link/add-link.component';
import { LinkListComponent } from '../modules/product-menu-setup/link-list/link-list.component';
// import { SiTransactionReportComponent } from '../modules/report/si-daily-mis-report/si-daily-mis-report.component';
import  {SiTransactionReportComponent} from "../modules/report/si-transaction-report/si-transaction-report.component"
import { SiCancelledRangeReportComponent } from '../modules/report/si-cancelled-range-report/si-cancelled-range-report.component';
import { SiCancelledSpecificDateReportComponent } from '../modules/report/si-cancelled-specific-date-report/si-cancelled-specific-date-report.component';
import { SiModifiedRangeReportComponent } from '../modules/report/si-modified-range-report/si-modified-range-report.component';
import { SiDeclinedTxnRangeReportComponent } from '../modules/report/si-declined-txn-range-report/si-declined-txn-range-report.component';
import { SiCancelledAllTxnRangeReportComponent } from '../modules/report/si-cancelled-all-txn-range-report/si-cancelled-all-txn-range-report.component';
import { SiCancelledNextTxnRangeReportComponent } from '../modules/report/si-cancelled-next-txn-range-report/si-cancelled-next-txn-range-report.component';
import { SiDailyMISReportComponent } from '../modules/report/si-daily-mis-report/si-daily-mis-report.component';


@NgModule({
  declarations: [
    LoginComponent,
    HeaderComponent,
    SidebarComponent,
    MenuListItemComponent,
    DashboardComponent,
    DashboardViewComponent,
    ChangePasswordComponent,
    // bank component
    ViewBankComponent,
    EditBankComponent,
    AddBankComponent,
    BankProductsComponent,
    // department
    ViewDepartmentComponent,
    EditDepartmentComponent,
    BankDepartmentComponent,

    // designation
    ViewDesignationComponent,
    EditDesignationComponent,
    BankDesignationComponent,

    // role
    AddRoleComponent,
    ViewRoleComponent,
    EditRoleComponent,
    BankRolesComponent,
    //region
    RegionViewComponent,
    AddRegionComponent,
    BankRegionComponent,
    EditRegionComponent,
    //zone
    ViewZoneComponent,
    AddZoneComponent,
    BankZoneComponent,
    EditZoneComponent,
    //branch
    AddBranchComponent,
    EditBranchComponent,
    ViewBranchComponent,
    BankBranchsComponent,
    // users
    ViewUserComponent,
    BankUserDetailComponent,
    AddUserComponent,
    EditUserComponent,
    // configuaration
    ViewConfigComponent,
    EditConfigComponent,
    AddConfigComponent,
    // add department/designation
    AddDepartmentComponent,
    // master setup
    MasterSetupComponent,
    ReportComponent,
    SiReportComponent,
    SiTransactionReportComponent,
    SiCancelledRangeReportComponent,
    SiCancelledSpecificDateReportComponent,
    SiModifiedRangeReportComponent,
    SiDeclinedTxnRangeReportComponent,
    SiCancelledAllTxnRangeReportComponent,
    SiCancelledNextTxnRangeReportComponent,
    SiDailyMISReportComponent,
    CertificationComponent,
    CertificationViewComponent,
    CertificationApproveComponent,
    CertificationDetailComponent,
    ProductsListComponent,
    AddProductComponent,
    AddLinkComponent,
    LinkListComponent,

    // // ICM 
    AcqbinComponent,
    IcmComponent,
    IcmgenComponent,
    IssbinComponent,
    PrdComponent
    

  ],
  imports: [
    RouterModule,
    CommonModule,
    NgSelectModule,
    FormsModule,
    ReactiveFormsModule,
    MatCardModule,
    MatDividerModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatMenuModule,
    MatToolbarModule,
    MatGridListModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSelectModule,
    MatTableModule,
    MatPaginatorModule,
    MatTabsModule,
    MatListModule,
    MatSnackBarModule,
    MatCheckboxModule,
    MatRadioModule,
    MatAutocompleteModule,
    //CdkTableModule
    MatSidenavModule

  ],
  exports: [
    LoginComponent,
    DashboardComponent,
    ChangePasswordComponent,
    DashboardViewComponent,
    // bank component
    ViewBankComponent,
    EditBankComponent,
    AddBankComponent,
    BankProductsComponent,
    // department
    ViewDepartmentComponent,
    EditDepartmentComponent,
    BankDepartmentComponent,
    // designation
    ViewDesignationComponent,
    EditDesignationComponent,
    BankDesignationComponent,
    // role
    AddRoleComponent,
    ViewRoleComponent,
    EditRoleComponent,
    BankRolesComponent,
    //region
    RegionViewComponent,
    AddRegionComponent,
    BankRegionComponent,
    EditRegionComponent,
    //zone
    ViewZoneComponent,
    AddZoneComponent,
    BankZoneComponent,
    EditZoneComponent,
    //branch
    AddBranchComponent,
    EditBranchComponent,
    ViewBranchComponent,
    BankBranchsComponent,
    // users
    ViewUserComponent,
    BankUserDetailComponent,
    AddUserComponent,
    EditUserComponent,
    // configuaration
    ViewConfigComponent,
    EditConfigComponent,
    AddConfigComponent,
    // master setup
    MasterSetupComponent,
    // add department/designation
    AddDepartmentComponent,
    ReportComponent,
    CertificationComponent,
    ProductsListComponent,
    AddProductComponent,
    AddLinkComponent,
    LinkListComponent,

    // // ICM 
    AcqbinComponent,
    IcmComponent,
    IcmgenComponent,
    IssbinComponent,
    PrdComponent
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  // for dd/mm/yyyy format
  providers: [
    { provide: MAT_DATE_LOCALE, useValue: 'en-GB' },

  ]
})
export class SharedModule { }
