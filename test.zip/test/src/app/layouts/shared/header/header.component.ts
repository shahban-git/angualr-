import { Route } from '@angular/compiler/src/core';
import { AfterViewInit, Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/services/subscribe/login.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit, AfterViewInit {
  @Output() toggleSidenav = new EventEmitter<any>();
  constructor(public router :  Router, public service : LoginService) { }
  username : String;
  login;
  lastLoginTime;
  entityId;
  ngOnInit(): void {
    this.login = this.service.isUserLoggedIn();
  }

  ngAfterViewInit(): void {
    if (this.login){
      this.getCurrentUser();
    }
   // this.changeDetectorR.detectChanges();
  }

  logout(){
   
    this.service.logout().subscribe((res) => {
      sessionStorage.clear();
      localStorage.removeItem('currentUser');
      localStorage.removeItem('linkValues');
      localStorage.removeItem('cdPms');
      localStorage.removeItem('entityId');
      sessionStorage.removeItem('Token');
      sessionStorage.removeItem('rt');
      localStorage.removeItem('viewData');
      localStorage.removeItem('tabInd')
      if (!location.pathname.includes('auth')) {
        //location.reload();
        this.service.stopTimer();
        this.router.navigate(['login']);

      }
      this.service.stopTimer();
      this.router.navigate(['login']);

  }, error => {

  })
  }
  toggleDrawer(){
    this.toggleSidenav.emit('toggle');
  }

   homeDashboard()  
  { 
  this.router.navigate(['dashboard']);
  }
   /**
   * Gets the las login time from the jwt token.
   */
  public getCurrentUser(){
    this.service.getCurrentUser().subscribe(response => {
      console.log("usernaeeeeeeeeeeeeeeeeee",response)
      this.username = response.data['User Name'];
      this.lastLoginTime =  response.data['Last Login'] + '';
      this.entityId = response.data['Entity Name'];
    });
  }

}
