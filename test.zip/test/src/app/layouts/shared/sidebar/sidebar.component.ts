import { Component, OnInit, Input } from '@angular/core';
import { SideBarModel } from 'src/app/models/side-bar-menu/side-bar-menu';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css'],
})
export class SidebarComponent implements OnInit {
  @Input() linkValues: number[];
  displayFields: SideBarModel[] = [
    /*{
      menuId: 1,
      displayName: 'Dashboard',
      iconName: 'feedback',
      iconUrl: 'assets/images/dashboardImg.svg',
      iconUrlActive: 'assets/images/dashboard_color.svg',
      route: 'dashboard',
    },*/
    {
      menuId: 2,
      displayName: 'Master setup',
      iconName: 'feedback',
      iconUrl: 'assets/images/settings_menu.svg',
      iconUrlActive: 'assets/images/settings_menu_color.svg',
      route: 'dashboard/master',
    },
    {
      menuId: 3,
      displayName: 'users',
      iconName: 'feedback',
      iconUrl: 'assets/images/user.svg',
      iconUrlActive: 'assets/images/users_color.svg',
      route: 'dashboard/user',
    },
    {
      menuId: 4,
      displayName: 'certification',
      iconName: 'feedback',
      iconUrl: 'assets/images/award.svg',
      iconUrlActive: 'assets/images/award_color.svg',
      route: 'dashboard/certification',
    },
    {
      menuId: 5,
      displayName: 'reports',
      iconName: 'feedback',
      iconUrl: 'assets/images/google-docs.svg',
      iconUrlActive: 'assets/images/dashboardImg.svg',
      route: 'dashboard/report',
    },
    {
      menuId: 4,
      displayName: 'product setup',
      iconName: 'feedback',
      iconUrl: 'assets/images/open-box.svg',
      iconUrlActive: 'assets/images/open-box-color.svg',
      route: 'dashboard/product-setup',
    },
    {
      menuId: 4,
      displayName: 'product menu setup',
      iconName: 'feedback',
      iconUrl: 'assets/images/open-box.svg',
      iconUrlActive: 'assets/images/open-box-color.svg',
      route: 'dashboard/product-menu-setup',
    },

    {
      menuId: 4,
      displayName: 'reports',
      iconName: 'feedback',
      iconUrl: 'assets/images/google-docs.svg',
      iconUrlActive: 'assets/images/dashboardImg.svg',
      route: 'dashboard/report',
    },

    {
      menuId: 10,
      displayName: 'si Registration',
      iconName: 'feedback',
      iconUrl: 'assets/images/google-docs.svg',
      iconUrlActive: 'assets/images/dashboardImg.svg',
      route: 'dashboard/si_report',
    },{
      menuId: 10,
      displayName: 'si cancelled report',
      iconName: 'feedback',
      iconUrl: 'assets/images/google-docs.svg',
      iconUrlActive: 'assets/images/dashboardImg.svg',
      route: 'dashboard/si_cancelled_range_report',
    },
    /*{
      menuId: 10,
      displayName: 'si cancelled specific date report',
      iconName: 'feedback',
      iconUrl: 'assets/images/google-docs.svg',
      iconUrlActive: 'assets/images/dashboardImg.svg',
      route: 'dashboard/si_cancelled_specific_date_report',
    }
    */,{
      menuId: 10,
      displayName: 'SI modified report',
      iconName: 'feedback',
      iconUrl: 'assets/images/google-docs.svg',
      iconUrlActive: 'assets/images/dashboardImg.svg',
      route: 'dashboard/si_modified_range_report',
    },{
      menuId: 10,
      displayName: 'si transaction report',
      iconName: 'feedback',
      iconUrl: 'assets/images/google-docs.svg',
      iconUrlActive: 'assets/images/dashboardImg.svg',
      route: 'dashboard/si_transaction_report',
    },{
      menuId: 10,
      displayName: 'si declined txn report',
      iconName: 'feedback',
      iconUrl: 'assets/images/google-docs.svg',
      iconUrlActive: 'assets/images/dashboardImg.svg',
      route: 'dashboard/si_declined_txn_range_report',
    },{
      menuId: 10,
      displayName: 'si cancelled all txn report',
      iconName: 'feedback',
      iconUrl: 'assets/images/google-docs.svg',
      iconUrlActive: 'assets/images/dashboardImg.svg',
      route: 'dashboard/si_cancelled_all_txn_range_report',
    },{
      menuId: 10,
      displayName: 'si cancelled next txn report',
      iconName: 'feedback',
      iconUrl: 'assets/images/google-docs.svg',
      iconUrlActive: 'assets/images/dashboardImg.svg',
      route: 'dashboard/si_cancelled_next_txn_range_report',
    }
    ,{
      menuId: 10,
      displayName: 'si daily mis report',
      iconName: 'feedback',
      iconUrl: 'assets/images/google-docs.svg',
      iconUrlActive: 'assets/images/dashboardImg.svg',
      route: 'dashboard/si_daily_mis_report',
    }
  ];

  navItems = [
    {
      displayName: 'access control',
      iconName: '',
      children: [],
    },
  ];
  constructor() {}

  ngOnInit(): void {
console.log(localStorage.getItem('linkValues'))
    if (!this.linkValues) {
      this.linkValues = localStorage
        .getItem('linkValues')
        .split(',')
        .map((x) => +x);
    }
    const navMenu = [];

    this.displayFields.forEach((disp) => {
      console.log("displayyyyyyyyy",disp)
      if (this.linkValues.indexOf(disp.menuId) > -1) {
        console.log("display1",disp)
        if(disp.menuId < 9){
          console.log("First menu",disp)
          navMenu.push(disp);  
        }
        
      }
      
    });
    const navMenus = [];
    this.displayFields.forEach((disps) => {
      console.log("display 22",disps)
      //if (this.linkValues.indexOf(disps.menuId) > -1) {
        if(disps.menuId > 9){
        console.log("display2",disps)
          navMenus.push(disps); 
        }
        
      //}
      
    });

    this.navItems = [
      {
        displayName: 'access control',
        iconName: '',
        children: navMenu,
      },
      {
        displayName: 'SI Reports',
        iconName: '',
        children: navMenus,
      },
    ];
    console.log("naccccccccc",navMenu)
    console.log("naccccccccc 2",navMenus)
  }
}
