import { Component, OnInit } from '@angular/core';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import {IcmgenComponent} from '../icmgen/icmgen.component'
import { NgForm,FormGroup,FormControl,Validators } from '@angular/forms';
import { AcqBinModel } from './acqbin-model';
import {MatTableDataSource} from '@angular/material/table';
import { map } from 'rxjs/operators';
import Swal from 'sweetalert2'; 
@Component({
  selector: 'app-acqbin',
  templateUrl: './acqbin.component.html',
  styleUrls: ['./acqbin.component.css']
})
export class AcqbinComponent implements OnInit {

  
  isEnable:boolean=false;
  dynamicForm: FormGroup;
  acqBinList=[];
  acqBinId = '';
  acqProdTyp= '';
  acqSetlBin= '';
  acqSetlCurr= '';
  enId= ''
  ica= '';
  orgId= '';
  pid='';
  procBin='';
  productId='';
  userId='';
  

  
  mode='';
  index=0;
  signupForm: FormGroup;
  displayedColumns: string[] = ['Bin Id', 'PID','ICA', 'Settlement Bin','Proc Bin','Action'];
  dataSource:MatTableDataSource<AcqBinModel>;
  productTypes: string[] =['POS','ECOM','ATM'];

  constructor(private modalService: NgbModal,public icmgenservice: IcmgenComponent) { }

  ngOnInit(): void {
    
    this.acqBinList=this.icmgenservice.getAcqBinList();
    this.dataSource= new MatTableDataSource(this.acqBinList);
    if(this.icmgenservice.mode=='view')
    {
      this.isEnable=true;
    }
    this.productId = this.icmgenservice.prddetail.productId;
  }

  open(content) {

    if(this.icmgenservice.prddetail.bussinessType==='ISSUER')
    {
      Swal.fire('Error', 'This option is not applicatable for the selected business type', 'error');
      return false;
    }

    this.modalService.open(content, {
      centered: true,
      backdrop: 'static'
     });

     let numericRegex = /^[a-zA-Z0-9]+$/;
    this.dynamicForm = new FormGroup({
     
      productId : new FormControl(this.productId),
      acqBinId : new FormControl(null,[Validators.required,Validators.pattern(numericRegex),Validators.minLength(6),Validators.maxLength(9)]),
      
      
      acqSetlBin : new FormControl(null,[Validators.pattern(numericRegex),Validators.minLength(8),Validators.maxLength(8)]),
      acqSetlCurr : new FormControl(null,[Validators.required,Validators.pattern(numericRegex),Validators.minLength(3),Validators.maxLength(3)]),
      //issSetlTyp : new FormControl(null,[Validators.required]),
      pid : new FormControl(null),
      procBin : new FormControl(null),
      ica : new FormControl(null),
      productid : new FormControl(null) ,
      acqProdTyp : new FormControl(null)

    }

    )
      
      this.acqBinId='';
      
      this.acqSetlBin='';
      this.acqSetlCurr='';
      this.procBin='';
  
      this.pid='';
      
      this.ica='';
      this.acqProdTyp='';

      this.mode='add';
   
  }

  openModalNew(targetModal, acqBin,i) {
    this.modalService.open(targetModal, {
     centered: true,
     backdrop: 'static'
    });

    let numericRegex = /^[a-zA-Z0-9]+$/;
    this.dynamicForm = new FormGroup({
     
      productId : new FormControl(this.productId),
      acqBinId : new FormControl(null,[Validators.required,Validators.pattern(numericRegex),Validators.minLength(6),Validators.maxLength(9)]),
      
      
      acqSetlBin : new FormControl(null,[Validators.pattern(numericRegex),Validators.minLength(8),Validators.maxLength(8)]),
      acqSetlCurr : new FormControl(null,[Validators.required,Validators.pattern(numericRegex),Validators.minLength(3),Validators.maxLength(3)]),
      //issSetlTyp : new FormControl(null,[Validators.required]),
      pid : new FormControl(null),
      procBin : new FormControl(null),
      ica : new FormControl(null),
      productid : new FormControl(null) ,
      acqProdTyp : new FormControl(null)

    }

    );
    let prdType = typeof acqBin.acqProdTyp=== "string" ? acqBin.acqProdTyp.split(',') : acqBin.acqProdTyp;
    this.dynamicForm.patchValue({
      
      'acqBinId' : acqBin.acqBinId,
      
      'acqSetlBin': acqBin.acqSetlBin,
      'acqSetlCurr' : acqBin.acqSetlCurr,
      'acqSetlTyp' : acqBin.acqSetlTyp,
      'procBin' : acqBin.procBin,
      'pid' : acqBin.pid,
      'ica' : acqBin.ica,
      'acqProdTyp' : prdType
      
      
    });

    
   
    
   
      
      this.acqBinId=acqBin.acqBinId;
      this.ica=acqBin.ica;
      this.procBin=acqBin.procBin;

      this.pid=acqBin.pid;
      this.acqSetlBin=acqBin.acqSetlBin;
      this.acqSetlCurr=acqBin.acqSetlCurr;
      this.ica=acqBin.ica;
      this.acqProdTyp=acqBin.acqProdTyp;
      this.mode='edit';
      this.index=i;

      
    
   }


   getAcqBinDetails()
{
  //alert("Get Details Called...");
  //alert("Get Details Called..."+this.dynamicForm.get('issBinHigh').value);
  this.icmgenservice.getAcqBinDtls(this.icmgenservice.prddetail.schemeType,this.dynamicForm.get('acqBinId').value).
  subscribe(
    response=>{
      

      console.log('Response is :::::::::::::'+response);
      try{
      if(response==undefined)
      {
        alert('Bin Details not Present in the System. ');
            
      }
      {
      this.dynamicForm.patchValue({
       
        
        'ica': response[0][0]
       

      });
    }
  }catch(e)
  {
    alert('Bin Details not Present in the System. ');
  }

    },
    error=>{
      
      console.log('Response is :::::::::::::'+error);
    }

  )
}

   onSubmit(signupForm: FormGroup){
    this.signupForm=signupForm;
    console.log("adding form values "+signupForm.value.binId);
    if(this.mode=='add'){
      
      this.icmgenservice.addAcqBin(signupForm);
    }
    else{
      this.icmgenservice.acqBinList.splice(0, this.icmgenservice.acqBinList.length);

      this.icmgenservice.updateAcqBin(signupForm,this.index).subscribe(
        response=>{
          //console.log('response after adding '+response);
          //alert(response.status);
          this.icmgenservice.getAsynAcqBinList().pipe(
            map((responsedata:{[key:number]:AcqBinModel})=>{
              for(const key in responsedata)
              {
                this.icmgenservice.acqBinList.push(responsedata[key]);
              }
              console.log('ssss'+this.icmgenservice.issBinList.length);
                this.acqBinList = this.icmgenservice.getAcqBinList();
                this.dataSource= new MatTableDataSource(this.icmgenservice.acqBinList);
            }
  
            )
  
        )
        .subscribe(
          result =>{
            console.log(result);
            //this.result1 = result;
          }
        
        );
        }
      )

    }

    this.dataSource= new MatTableDataSource(this.acqBinList);
    this.modalService.dismissAll();
    
}

  closeWindow(){

    this.modalService.dismissAll();
    
  }
  remove(i,acqid)
  {
    //this.acqBinList.splice(i);
    this.icmgenservice.acqBinList.splice(0, this.icmgenservice.acqBinList.length);
    console.log('acqid:::::::::::::::::::'+acqid);
    this.icmgenservice.deleteAcqBin(acqid).subscribe(
      response=>{
        console.log('response after adding '+response);
        this.icmgenservice.getAsynAcqBinList().pipe(
          map((responsedata:{[key:number]:AcqBinModel})=>{
            for(const key in responsedata)
            {
              this.icmgenservice.acqBinList.push(responsedata[key]);
            }
            console.log('ssss'+this.icmgenservice.issBinList.length);
              this.acqBinList = this.icmgenservice.getAcqBinList();
              this.dataSource= new MatTableDataSource(this.icmgenservice.acqBinList);
          }

          )

      )
      .subscribe(
        result =>{
          console.log(result);
          //this.result1 = result;
        }
      
      );
      }
    )
  
    //this.dataSource= new MatTableDataSource(this.acqBinList);
  }

}
