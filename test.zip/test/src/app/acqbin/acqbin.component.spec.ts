import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AcqbinComponent } from './acqbin.component';

describe('AcqbinComponent', () => {
  let component: AcqbinComponent;
  let fixture: ComponentFixture<AcqbinComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AcqbinComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AcqbinComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
