import { Injectable } from '@angular/core';
@Injectable({
    providedIn: 'root'
  })
export class AcqBinModel{

    acqBinId: string;
    acqProdTyp: string;
    acqSetlBin: string;
    acqSetlCurr: string;
    enId: string;
    ica: string;
    orgId: string;
    pid: string;
    procBin: string;
    productId: string;
    userId: string;
    

}